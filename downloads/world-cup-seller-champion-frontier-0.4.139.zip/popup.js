let currentGame = null;
let currentState = null;
let mySeatInput = "";
let selectedMySeats = [];
let packagePrices = {};
let selectedPerformanceId = null;
let selectedGameKey = null;
let activeTabPerformanceId = null;
let selectedInsightCategory = "__all__";
let listPages = {};
let loadInFlight = false;
let lastFullRenderKey = "";
let lastProgressRenderKey = "";
let lastStreamingFullRenderAt = 0;
let refreshTimer = null;
let lastUserScrollAt = 0;
let lastUserInputAt = 0;
let scrollRestoreInFlight = false;
let gameIndexOpenState = {
  stored: null,
  discovered: null
};

const SELLER_INVENTORY_STORAGE_KEY = "sellerInventoryByPerformance";
const APP_VERSION = "0.4.139";
const BUYER_FEE_RATE = 0.15;
const SELLER_FEE_RATE = 0.15;
const hasRuntimeApi = typeof chrome !== "undefined" && !!chrome.runtime?.sendMessage;
const hasChromeApi = hasRuntimeApi && !!chrome.tabs?.query;
const PREVIEW_CROWD_SHARE_KEY = "wcscPreviewCrowdShareEnabled";
const CROWD_PROMPT_DISMISSED_KEY = "wcscCrowdPromptDismissed";

function money(value) {
  if (value == null || Number.isNaN(Number(value))) return "-";
  const number = Number(value);
  const sign = number < 0 ? "-" : "";
  return `${sign}$${Math.abs(number).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

function compactMoney(value) {
  if (value == null || Number.isNaN(Number(value))) return "-";
  const number = Number(value);
  const sign = number < 0 ? "-" : "";
  const abs = Math.abs(number);
  if (abs < 1000) return `${sign}$${abs.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  const compact = (abs / 1000).toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  });
  return `${sign}$${compact}K`;
}

function statusText(text) {
  const status = document.getElementById("status");
  if (status) status.textContent = text;
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}

async function getCrowdSettings() {
  if (!hasRuntimeApi) {
    return {
      enabled: localStorage.getItem(PREVIEW_CROWD_SHARE_KEY) === "true",
      lastSync: null,
      preview: true
    };
  }
  return chrome.runtime.sendMessage({ type: "FIFA_SELLER_SCOUT_GET_CROWD_SETTINGS" });
}

async function setCrowdSharing(enabled) {
  if (!hasRuntimeApi) {
    localStorage.setItem(PREVIEW_CROWD_SHARE_KEY, enabled ? "true" : "false");
    return { ok: true, enabled, preview: true };
  }
  return chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_SET_CROWD_SHARING",
    enabled
  });
}

function crowdStatusText(settings) {
  if (!settings?.enabled) return "Off";
  if (settings.preview) return "On in preview";
  const sync = settings.lastSync;
  if (!sync?.syncedAt) return "On";
  const time = new Date(sync.syncedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (!sync.ok) return `Not shared ${time}`;
  const count = Number(sync.seatCount || sync.result?.result?.liveSupply || 0);
  return count ? `Shared ${count} seats ${time}` : `Shared ${time}`;
}

function contributorPassFromSettings(settings) {
  return settings?.contributorPass || settings?.lastSync?.result?.contributorPass || null;
}

function renderContributorPass(settings) {
  const pass = contributorPassFromSettings(settings);
  if (!settings?.enabled || !pass?.code) return "";
  const expires = pass.expiresAt
    ? new Date(pass.expiresAt).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })
    : "soon";
  return `
    <div class="contributor-pass">
      <span>Seller insights pass</span>
      <strong>${escapeHtml(pass.code)}</strong>
      <em>Good until ${escapeHtml(expires)}</em>
      <a href="https://wc26champion.com/insights" target="_blank" rel="noreferrer">Open Insights <sup>LAB</sup></a>
    </div>
  `;
}

function hasShareableScan(game, seats) {
  if (!game || !Array.isArray(seats) || !seats.length) return false;
  const progress = game.scanProgress || {};
  return progress.status === "done" || !!game.snapshots?.length;
}

async function getCrowdPromptDismissed() {
  if (!hasRuntimeApi) return localStorage.getItem(CROWD_PROMPT_DISMISSED_KEY) === "true";
  const data = await storageGet([CROWD_PROMPT_DISMISSED_KEY]);
  return data?.[CROWD_PROMPT_DISMISSED_KEY] === true;
}

async function setCrowdPromptDismissed(dismissed) {
  if (!hasRuntimeApi) {
    localStorage.setItem(CROWD_PROMPT_DISMISSED_KEY, dismissed ? "true" : "false");
    return;
  }
  await storageSet({ [CROWD_PROMPT_DISMISSED_KEY]: dismissed === true });
}

function renderCrowdPrompt(settings, dismissed, game, seats) {
  if (settings?.enabled || dismissed || !hasShareableScan(game, seats)) return "";
  return `
    <div class="crowd-prompt">
      <strong>Help other fans see better prices?</strong>
      <span>Share public ticket listings from scans. We do not send your name, email, account, payment, IP address, purchase cost, target price, or seats you type as yours.</span>
      <div>
        <button class="ghost crowd-prompt-accept" id="crowdPromptAccept">Share scans</button>
        <button class="ghost crowd-prompt-dismiss" id="crowdPromptDismiss">Not now</button>
      </div>
    </div>
  `;
}

function renderCrowdPreScanPrompt() {
  return `
    <div class="crowd-prompt crowd-prompt-prescan">
      <strong>Want better Insights?</strong>
      <span>Turn on sharing before you check prices. We only send public ticket listings. No PII, account, payment, IP address, purchase cost, target price, or seats you type as yours.</span>
      <div>
        <button class="ghost crowd-prompt-accept" id="crowdPromptAccept">Share scans</button>
        <button class="ghost crowd-prompt-dismiss" id="crowdPromptDismiss">Not now</button>
      </div>
    </div>
  `;
}

async function refreshCrowdSharingUi() {
  const checkbox = document.getElementById("crowdShare");
  const topCheckbox = document.getElementById("topCrowdShare");
  const status = document.getElementById("crowdStatus");
  const topStatus = document.getElementById("topCrowdStatus");
  const pass = document.getElementById("contributorPass");
  const topPass = document.getElementById("topContributorPass");
  if ((!checkbox && !topCheckbox) || (!status && !topStatus)) return;
  const settings = await getCrowdSettings();
  const passHtml = renderContributorPass(settings);
  if (checkbox) checkbox.checked = settings?.enabled === true;
  if (topCheckbox) topCheckbox.checked = settings?.enabled === true;
  if (status) status.textContent = crowdStatusText(settings);
  if (topStatus) topStatus.textContent = crowdStatusText(settings);
  if (pass) pass.innerHTML = passHtml;
  if (topPass) topPass.innerHTML = passHtml;
}

async function refreshCrowdPrompt(game = currentGame, seats = latestSeatRows(currentGame)) {
  const prompt = document.getElementById("crowdPrompt");
  if (!prompt) return;
  const settings = await getCrowdSettings();
  const dismissed = await getCrowdPromptDismissed();
  const html = renderCrowdPrompt(settings, dismissed, game, seats);
  const passHtml = renderContributorPass(settings);
  prompt.innerHTML = html;
  const section = prompt.closest(".crowd-consent");
  if (section) section.hidden = !html && !passHtml;
}

async function remindCrowdSharingBeforeScan() {
  const prompt = document.getElementById("crowdPrompt");
  if (!prompt) return false;
  const settings = await getCrowdSettings();
  if (settings?.enabled) return false;
  prompt.innerHTML = renderCrowdPreScanPrompt();
  const section = prompt.closest(".crowd-consent");
  if (section) section.hidden = false;
  return true;
}

async function loadSellerInventory(performanceId) {
  if (!hasChromeApi || !performanceId) return { seats: [], packagePrices: {} };
  const data = await storageGet([SELLER_INVENTORY_STORAGE_KEY]);
  const saved = data?.[SELLER_INVENTORY_STORAGE_KEY]?.[performanceId] || {};
  return {
    seats: Array.isArray(saved.seats) ? saved.seats : [],
    packagePrices: saved.packagePrices && typeof saved.packagePrices === "object" ? saved.packagePrices : {}
  };
}

async function saveSellerInventory() {
  if (!hasChromeApi || !currentGame?.performanceId) return;
  const data = await storageGet([SELLER_INVENTORY_STORAGE_KEY]);
  const all = data?.[SELLER_INVENTORY_STORAGE_KEY] || {};
  all[currentGame.performanceId] = {
    seats: selectedMySeats,
    packagePrices,
    updatedAt: new Date().toISOString()
  };
  await storageSet({ [SELLER_INVENTORY_STORAGE_KEY]: all });
}

async function deleteSellerInventory(performanceId = currentGame?.performanceId) {
  if (!hasChromeApi || !performanceId) return;
  const data = await storageGet([SELLER_INVENTORY_STORAGE_KEY]);
  const all = data?.[SELLER_INVENTORY_STORAGE_KEY] || {};
  delete all[performanceId];
  await storageSet({ [SELLER_INVENTORY_STORAGE_KEY]: all });
}

function scheduleIdle(work) {
  if (typeof requestIdleCallback === "function") {
    requestIdleCallback(work, { timeout: 600 });
  } else {
    setTimeout(work, 0);
  }
}

function markUserScroll() {
  if (scrollRestoreInFlight) return;
  lastUserScrollAt = Date.now();
}

function markUserInput() {
  lastUserInputAt = Date.now();
}

function shouldPauseAutoRefresh() {
  const now = Date.now();
  return now - Math.max(lastUserScrollAt, lastUserInputAt) < 2400;
}

function makeScrollRestorer(enabled) {
  if (!enabled) return () => {};
  const scroller = document.scrollingElement || document.documentElement;
  const top = scroller.scrollTop;
  const bottomGap = scroller.scrollHeight - scroller.clientHeight - top;
  const nearBottom = bottomGap < 160;
  return () => {
    if (shouldPauseAutoRefresh()) return;
    const restore = () => {
      const nextTop = nearBottom
        ? Math.max(0, scroller.scrollHeight - scroller.clientHeight - bottomGap)
        : top;
      scroller.scrollTop = nextTop;
    };
    scrollRestoreInFlight = true;
    requestAnimationFrame(() => {
      restore();
      requestAnimationFrame(() => {
        restore();
        setTimeout(() => {
          scrollRestoreInFlight = false;
        }, 80);
      });
    });
  };
}

function isScanComplete(progress) {
  const completed = Number(progress?.completed ?? 0);
  const total = Number(progress?.total ?? 0);
  return total > 0 && completed >= total;
}

function isScanActive(progress) {
  if (!progress) return false;
  const status = String(progress.status || "");
  if (["done", "blocked", "cooldown", "error", "missing-ids"].includes(status)) return false;
  if (isScanComplete(progress) && status !== "started" && status !== "queued") return false;
  return ["started", "scanning", "queued", "api-error", "already-running"].includes(status);
}

function setScanButtonBusy(active) {
  const button = document.getElementById("scan");
  if (!button) return;
  button.classList.toggle("is-scanning", active === true);
  button.setAttribute("aria-busy", active === true ? "true" : "false");
  button.dataset.tooltip = active === true ? "Checking prices" : "Check current prices";
}

function renderFingerprint(game, seats, options = {}) {
  const includeScanDiagnostics = options.includeScanDiagnostics !== false;
  const diagnostics = game?.parseDiagnostics || {};
  const velocity = game?.velocity || {};
  return JSON.stringify({
    selectedGameKey,
    selectedInsightCategory,
    performanceId: game?.performanceId || "",
    seats: seats.length,
    rawFeaturesSeen: includeScanDiagnostics ? game?.rawFeaturesSeen || 0 : 0,
    parsedSeatCount: includeScanDiagnostics ? diagnostics.parsedSeatCount || 0 : 0,
    lastFeaturePayloadCount: includeScanDiagnostics ? diagnostics.lastFeaturePayloadCount || 0 : 0,
    lastScanResultFeatureCount: includeScanDiagnostics ? diagnostics.lastScanResultFeatureCount || 0 : 0,
    categories: Object.keys(game?.categories || {}).length,
    stadiumSections: Object.keys(game?.stadiumSections || {}).length,
    stadiumSeats: Object.keys(game?.stadiumSeats || {}).length,
    velocityId: velocity.currentSnapshotId || "",
    selectedSeats: selectedMySeats.map(selectionKey).join("|"),
    listPages,
    packagePrices
  });
}

function progressFingerprint(progress) {
  if (!progress) return "";
  return JSON.stringify({
    status: progress.status || "",
    completed: progress.completed ?? null,
    total: progress.total ?? null,
    found: progress.found ?? null,
    attemptedTiles: progress.attemptedTiles ?? null,
    successfulTiles: progress.successfulTiles ?? null,
    blockedTiles: progress.blockedTiles ?? null,
    httpStatus: progress.httpStatus ?? null,
    stopReason: progress.stopReason || "",
    message: progress.message || ""
  });
}

function nextRefreshDelay() {
  return isScanActive(currentGame?.scanProgress) ? 2200 : 6000;
}

function scheduleNextRefresh() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(async () => {
    if (shouldPauseAutoRefresh()) {
      scheduleNextRefresh();
      return;
    }
    await load({ preserveScroll: true });
    scheduleNextRefresh();
  }, shouldPauseAutoRefresh() ? 1800 : nextRefreshDelay());
}

function setValidation(message, tone = "muted") {
  const node = document.getElementById("seatValidation");
  if (!node) return;
  node.className = `validation ${tone}`;
  node.textContent = message || "";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function sellerListToBuyerAllIn(value) {
  return value == null ? null : value * (1 + BUYER_FEE_RATE);
}

function sellerListToSellerNet(value) {
  return value == null ? null : value * (1 - SELLER_FEE_RATE);
}

function numericInputValue(value) {
  if (value == null || value === "") return null;
  const normalized = String(value)
    .trim()
    .replace(/[$,\s]/g, "");
  if (!normalized) return null;
  const number = Number(normalized);
  return Number.isFinite(number) ? number : null;
}

function sellerTicketCost() {
  return numericInputValue(document.getElementById("sellerTicketCost")?.value);
}

function sellerTargetPrice() {
  return numericInputValue(document.getElementById("sellerTargetPrice")?.value);
}

function supportsTextSelection(input) {
  return ["", "text", "search", "url", "tel", "password"].includes(String(input?.type || "").toLowerCase());
}

function restoreInputCaret(input, start, end = start) {
  if (!input) return;
  input.focus();
  if (!supportsTextSelection(input)) return;
  const length = input.value.length;
  const safeStart = Math.min(length, Math.max(0, Number(start ?? length)));
  const safeEnd = Math.min(length, Math.max(safeStart, Number(end ?? safeStart)));
  input.setSelectionRange?.(safeStart, safeEnd);
}

function profitFromNet(net, cost = sellerTicketCost(), ticketCount = 1) {
  return net == null || cost == null ? null : (net * Math.max(1, Number(ticketCount) || 1)) - cost;
}

function profitMarginFromNet(net, cost = sellerTicketCost(), ticketCount = 1) {
  const profit = profitFromNet(net, cost, ticketCount);
  if (profit == null || cost == null || Number(cost) <= 0) return null;
  return profit / Number(cost);
}

function percent(value) {
  if (value == null || Number.isNaN(Number(value))) return "-";
  return `${(Number(value) * 100).toLocaleString(undefined, { maximumFractionDigits: 1 })}%`;
}

function strategyPriceValues(listPrice, cost = sellerTicketCost(), ticketCount = 1) {
  const count = Math.max(1, Number(ticketCount) || 1);
  const checkout = sellerListToBuyerAllIn(listPrice);
  const net = sellerListToSellerNet(listPrice);
  const totalNet = net == null ? null : net * count;
  const profit = profitFromNet(net, cost, count);
  const margin = profitMarginFromNet(net, cost, count);
  const profitClass = profit == null ? "" : (profit >= 0 ? "profit" : "loss");
  return { listPrice, checkout, net: count > 1 ? totalNet : net, profit, margin, profitClass };
}

function pricingSpectrumHtml(strategies, cost, ticketCount) {
  const enriched = strategies.map((strategy) => ({
    ...strategy,
    values: strategyPriceValues(strategy.price, cost, ticketCount)
  }));
  const rows = [
    { label: "FIFA price", value: (strategy) => money(strategy.values.listPrice) },
    { label: "Buyer pays", value: (strategy) => money(strategy.values.checkout) },
    { label: "Seller gets", value: (strategy) => money(strategy.values.net) },
    { label: "Profit", value: (strategy) => money(strategy.values.profit), className: (strategy) => strategy.values.profitClass },
    { label: "Margin", value: (strategy) => percent(strategy.values.margin), className: (strategy) => strategy.values.profitClass }
  ];
  return `
    <div class="pricing-spectrum">
      <div class="strategy-table">
        <div></div>
        ${enriched.map((strategy) => `
          <strong class="${escapeHtml(strategy.tone)}">
            ${escapeHtml(strategy.label)}
            <em>${escapeHtml(strategy.note || "")}</em>
          </strong>
        `).join("")}
        ${rows.map((row) => `
          <span>${escapeHtml(row.label)}</span>
          ${enriched.map((strategy) => `<b class="${escapeHtml(row.className?.(strategy) || "")}">${escapeHtml(row.value(strategy))}</b>`).join("")}
        `).join("")}
      </div>
    </div>
  `;
}

function percentile(sortedValues, pct) {
  if (!sortedValues.length) return null;
  const index = Math.min(sortedValues.length - 1, Math.max(0, Math.ceil(sortedValues.length * pct) - 1));
  return sortedValues[index];
}

function average(values) {
  const nums = values.filter((value) => value != null && Number.isFinite(Number(value))).map(Number);
  return nums.length ? nums.reduce((sum, value) => sum + value, 0) / nums.length : null;
}

function numericSeatNumber(value) {
  const match = String(value ?? "").match(/\d+/);
  return match ? Number(match[0]) : null;
}

function sortedSeats(seats, priceKey = "buyerAllInPrice") {
  return [...seats].sort((a, b) => {
    const ap = Number(a[priceKey] ?? Infinity);
    const bp = Number(b[priceKey] ?? Infinity);
    if (ap !== bp) return ap - bp;
    return String(a.blockName).localeCompare(String(b.blockName)) ||
      String(a.row).localeCompare(String(b.row), undefined, { numeric: true }) ||
      String(a.seatNumber).localeCompare(String(b.seatNumber), undefined, { numeric: true });
  });
}

function sortedOfferings(offerings, priceKey = "sellerListPrice") {
  return [...offerings].sort((a, b) => {
    const ap = Number(a[priceKey] ?? Infinity);
    const bp = Number(b[priceKey] ?? Infinity);
    if (ap !== bp) return ap - bp;
    if (b.ticketCount !== a.ticketCount) return b.ticketCount - a.ticketCount;
    return naturalCompare(a.blockName, b.blockName) ||
      naturalCompare(a.row, b.row) ||
      Number(a.from ?? Infinity) - Number(b.from ?? Infinity);
  });
}

function sortedUnique(values) {
  return [...new Set(values.filter((value) => value != null && value !== "").map(String))]
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}

function naturalCompare(a, b) {
  return String(a).localeCompare(String(b), undefined, { numeric: true });
}

function rowOrderScore(row) {
  const text = String(row || "").trim().toUpperCase();
  if (!text) return Infinity;
  const leadingNumber = text.match(/^(\d+)/);
  if (leadingNumber) return Number(leadingNumber[1]);
  const leadingLetters = text.match(/^([A-Z]+)/)?.[1] || "";
  if (leadingLetters) {
    let score = 0;
    for (const char of leadingLetters) score = score * 26 + (char.charCodeAt(0) - 64);
    const trailingNumber = text.match(/(\d+)$/)?.[1];
    return score + (trailingNumber ? Number(trailingNumber) / 100 : 0);
  }
  return 10000;
}

function rowOrderCompare(a, b) {
  const scoreA = rowOrderScore(a);
  const scoreB = rowOrderScore(b);
  return scoreA - scoreB || naturalCompare(a, b);
}

function rowDepthPhrase(position) {
  if (position == null) return "";
  if (position <= 0.32) return "toward the front";
  if (position >= 0.68) return "toward the back";
  return "around the middle";
}

function rowHintForOffering(offering) {
  if (!currentGame || !offering?.blockName || !offering?.row) return "";
  const sameSectionRows = sortedUnique([
    ...stadiumSeatsForGame(currentGame),
    ...latestSeatRows(currentGame)
  ]
    .filter((seat) => String(seat.blockName || seat.blockId || "").toLowerCase() === String(offering.blockName).toLowerCase())
    .map((seat) => seat.row))
    .sort(rowOrderCompare);
  const rowText = String(offering.row);
  const rowIndex = sameSectionRows.findIndex((row) => String(row).toLowerCase() === rowText.toLowerCase());
  if (sameSectionRows.length >= 3 && rowIndex >= 0) {
    const position = rowIndex / Math.max(1, sameSectionRows.length - 1);
    return `Row ${rowText} is ${rowDepthPhrase(position)} of section ${offering.blockName}.`;
  }
  const score = rowOrderScore(rowText);
  if (!Number.isFinite(score) || score === Infinity) return "";
  const phrase = score <= 8 ? "usually closer to the front" : (score >= 27 ? "usually toward the back" : "usually around the middle");
  return `Row ${rowText} is ${phrase}.`;
}

function selectionKey(seat) {
  return [seat.blockName || "", seat.row || "", seat.seatNumber || ""].join("|").toLowerCase();
}

function mySeatToInput(seat) {
  return `${seat.blockName} ${seat.row} ${seat.seatNumber}`.trim();
}

function syncSelectedInput() {
  mySeatInput = selectedMySeats.map(mySeatToInput).join("\n");
}

function currentPickerSeat() {
  const blockName = document.getElementById("seatSection")?.value || "";
  const row = document.getElementById("seatRow")?.value || "";
  const typedNumber = document.getElementById("sellerSeatNumber")?.value || "";
  const seatNumber = typedNumber;
  if (!blockName || !row || !seatNumber) return null;
  return { blockName, row, seatNumber, raw: `${blockName} ${row} ${seatNumber}` };
}

function analysisInputsFromSelection() {
  const draft = currentPickerSeat();
  const inputs = selectedMySeats.map((seat) => ({ ...seat, raw: mySeatToInput(seat) }));
  if (draft && !inputs.some((seat) => selectionKey(seat) === selectionKey(draft))) inputs.push(draft);
  return inputs;
}

function matchName(game) {
  const raw = game?.match?.name || game?.match?.matchCode || (game?.performanceId ? `Match ${game.performanceId}` : "Match");
  const parts = String(raw).split("/").map((part) => part.trim()).filter(Boolean);
  const matchup = parts.find((part) => /\bvs\b/i.test(part));
  return (matchup || raw)
    .replace(/FIFA\s+World\s+Cup\s+2026™?/gi, "")
    .replace(/\s+VS\s+/g, " vs ")
    .replace(/\s+Vs\s+/g, " vs ")
    .replace(/\s+/g, " ")
    .trim() || "Current match";
}

function matchVenue(game) {
  if (game?.match?.venue || game?.match?.stadium) return game.match.venue || game.match.stadium;
  const raw = game?.match?.name || "";
  const parts = String(raw).split("/").map((part) => part.trim()).filter(Boolean);
  const venue = parts[parts.length - 1];
  return venue && !/\bvs\b/i.test(venue) ? venue : "Venue pending";
}

function matchDateTime(game) {
  const parts = [game?.match?.date, game?.match?.time].filter(Boolean);
  return parts.join(" · ") || "Date pending";
}

function gameSeatCount(game) {
  return Object.keys(game?.seats || {}).length;
}

function gameLastUpdated(game) {
  return game?.lastUpdatedAt ? new Date(game.lastUpdatedAt).toLocaleTimeString() : "-";
}

function activePerformanceIdFromUrl(url) {
  return String(url || "").match(/\/secure\/selection\/event\/seat\/performance\/(\d+)/)?.[1] || null;
}

function activeSiteFromUrl(url) {
  const text = String(url || "");
  if (text.includes("-shop-")) return "fifa_primary";
  if (text.includes("-resale-")) return "fifa_resale";
  return "";
}

function scanTargetMismatch(activePerformanceId) {
  if (!currentGame?.performanceId) return false;
  return String(activePerformanceId || "") !== String(currentGame.performanceId);
}

async function openSelectedGameForScan() {
  const performanceId = currentGame?.performanceId;
  if (!performanceId) return false;
  const result = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_OPEN_GAME",
    performanceId,
    site: currentGame.site || ""
  });
  if (!result?.ok) {
    statusText(result?.error || "Could not open this game");
    return false;
  }
  statusText("Opened this game. Click again to check prices.");
  return true;
}

function stadiumSeatsForGame(game) {
  const stadiumSeats = Object.values(game?.stadiumSeats || {});
  if (stadiumSeats.length) return stadiumSeats;
  return Object.values(game?.seats || {}).map((seat) => ({
    blockId: seat.blockId,
    blockName: seat.blockName,
    row: seat.row,
    seatNumber: seat.seatNumber,
    categoryId: seat.categoryId,
    categoryName: seat.categoryName,
    source: "market_only"
  }));
}

function stadiumSectionsForGame(game) {
  const sections = Object.values(game?.stadiumSections || {})
    .filter((section) => section.blockName || section.blockId);
  if (sections.length) return sections;
  const byName = new Map();
  for (const seat of stadiumSeatsForGame(game)) {
    const name = seat.blockName || seat.blockId;
    if (!name || byName.has(String(name))) continue;
    byName.set(String(name), {
      blockId: seat.blockId,
      blockName: String(name),
      categoryId: seat.categoryId || "",
      categoryName: seat.categoryName || "",
      source: seat.source || "seat_level"
    });
  }
  return Array.from(byName.values());
}

function hasFullSectionCatalog(game) {
  return Object.keys(game?.stadiumSections || {}).length > 0;
}

function hasFullStadiumCatalog(game) {
  return Object.keys(game?.stadiumSeats || {}).length > Object.keys(game?.seats || {}).length;
}

function seatCategoryKey(seat) {
  return seat?.categoryName || seat?.categoryId || "Unknown";
}

function availabilityStats(game, scopedSeats = latestSeatRows(game), category = "__all__") {
  const stadiumSeats = Object.values(game?.stadiumSeats || {});
  if (!stadiumSeats.length || !hasFullStadiumCatalog(game)) {
    return {
      live: scopedSeats.length,
      total: null,
      percent: null,
      label: "For sale",
      note: "live listings"
    };
  }
  const totalSeats = category === "__all__"
    ? stadiumSeats
    : stadiumSeats.filter((seat) => seatCategoryKey(seat) === category);
  const total = totalSeats.length;
  const live = scopedSeats.length;
  return {
    live,
    total,
    percent: total ? live / total : null,
    label: "Available",
    note: total ? `${live.toLocaleString()} / ${total.toLocaleString()} seats` : "live listings"
  };
}

function marketStats(seats) {
  const sellerPrices = sortedSeats(seats, "sellerListPrice")
    .map((s) => s.sellerListPrice)
    .filter((p) => p != null && Number.isFinite(Number(p)))
    .sort((a, b) => a - b);
  const buyerPrices = sortedSeats(seats, "buyerAllInPrice")
    .map((s) => s.buyerAllInPrice)
    .filter((p) => p != null && Number.isFinite(Number(p)))
    .sort((a, b) => a - b);
  const categoryCounts = seats.reduce((acc, s) => {
    const key = s.categoryName || s.categoryId || "Unknown";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  const blockCounts = seats.reduce((acc, s) => {
    const key = s.blockName || "Unknown";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  const groups = adjacentGroups(seats);

  return {
    count: seats.length,
    buyerFloor: buyerPrices[0] ?? null,
    buyerMedian: percentile(buyerPrices, 0.5),
    buyerP75: percentile(buyerPrices, 0.75),
    sellerFloor: sellerPrices[0] ?? null,
    sellerMedian: percentile(sellerPrices, 0.5),
    sellerP75: percentile(sellerPrices, 0.75),
    categoryCounts,
    blockCounts,
    adjacentGroups: groups,
    pairPlusGroups: groups.filter((g) => g.seats.length >= 2),
    largestAdjacentGroup: groups.reduce((best, group) => group.seats.length > (best?.seats.length || 0) ? group : best, null)
  };
}

function histogramBuckets(seats, priceKey = "sellerListPrice", bucketCount = 8) {
  const prices = seats
    .map((seat) => Number(seat[priceKey]))
    .filter((price) => Number.isFinite(price))
    .sort((a, b) => a - b);
  if (!prices.length) return { buckets: [], min: null, max: null, mode: "empty" };
  const min = prices[0];
  const max = prices[prices.length - 1];
  if (min === max) {
    return {
      min,
      max,
      mode: "single",
      buckets: [{ from: min, to: max, count: prices.length, label: money(min) }]
    };
  }

  const p95 = percentile(prices, 0.95);
  const hasOutlierTail = prices.length >= 30 && p95 != null && max > p95 * 2.5;
  const normalMax = hasOutlierTail ? p95 : max;
  const normalBucketCount = hasOutlierTail ? Math.max(1, bucketCount - 1) : bucketCount;
  const normalPrices = prices.filter((price) => price <= normalMax);
  const width = Math.max(1, (normalMax - min) / normalBucketCount);
  const buckets = Array.from({ length: normalBucketCount }, (_, index) => ({
    from: min + width * index,
    to: index === normalBucketCount - 1 ? normalMax : min + width * (index + 1),
    count: 0
  }));
  for (const price of normalPrices) {
    const index = Math.min(normalBucketCount - 1, Math.floor((price - min) / width));
    buckets[index].count += 1;
  }
  if (hasOutlierTail) {
    const tail = prices.filter((price) => price > normalMax);
    buckets.push({
      from: normalMax,
      to: max,
      count: tail.length,
      label: `${compactMoney(normalMax)}+`,
      outlier: true
    });
  }
  return { buckets, min, max, normalMax, mode: hasOutlierTail ? "trimmed" : "standard" };
}

function adjacentGroups(seats) {
  const byLocation = seats.reduce((acc, seat) => {
    const priceKey = Number.isFinite(Number(seat.sellerListPrice))
      ? Math.round(Number(seat.sellerListPrice) * 100)
      : "";
    const key = [seat.blockName || "", seat.row || "", seat.categoryName || seat.categoryId || "", priceKey].join("\u001f");
    if (!acc[key]) acc[key] = [];
    acc[key].push(seat);
    return acc;
  }, {});
  const groups = [];
  for (const [key, groupSeats] of Object.entries(byLocation)) {
    const ordered = groupSeats
      .map((seat) => ({ seat, n: numericSeatNumber(seat.seatNumber) }))
      .filter((item) => item.n != null)
      .sort((a, b) => a.n - b.n);
    let run = [];
    for (const item of ordered) {
      if (!run.length || item.n === run[run.length - 1].n + 1) {
        run.push(item);
      } else {
        groups.push(buildAdjacentGroup(key, run));
        run = [item];
      }
    }
    if (run.length) groups.push(buildAdjacentGroup(key, run));
  }
  return groups.filter(Boolean).sort((a, b) => b.seats.length - a.seats.length || a.floorSeller - b.floorSeller);
}

function buildAdjacentGroup(key, run) {
  if (!run.length) return null;
  const [blockName, row, categoryName] = key.split("\u001f");
  const seats = run.map((item) => item.seat);
  const nums = run.map((item) => item.n);
  const buyerPrices = seats.map((s) => s.buyerAllInPrice).filter((p) => p != null).sort((a, b) => a - b);
  const sellerPrices = seats.map((s) => s.sellerListPrice).filter((p) => p != null).sort((a, b) => a - b);
  const netPrices = seats.map((s) => s.estimatedSellerNet).filter((p) => p != null).sort((a, b) => a - b);
  const mapPoints = seats
    .map((seat) => ({ x: Number(seat.mapPointX), y: Number(seat.mapPointY) }))
    .filter((point) => Number.isFinite(point.x) && Number.isFinite(point.y));
  const mapPointX = mapPoints.length ? mapPoints.reduce((sum, point) => sum + point.x, 0) / mapPoints.length : null;
  const mapPointY = mapPoints.length ? mapPoints.reduce((sum, point) => sum + point.y, 0) / mapPoints.length : null;
  return {
    blockName,
    row,
    categoryName,
    seats,
    ticketCount: seats.length,
    from: nums[0],
    to: nums[nums.length - 1],
    sellerListPrice: sellerPrices[0] ?? null,
    buyerAllInPrice: buyerPrices[0] ?? null,
    estimatedSellerNet: netPrices[0] ?? null,
    floorBuyer: buyerPrices[0] ?? null,
    floorSeller: sellerPrices[0] ?? null,
    mapPointX,
    mapPointY
  };
}

function seatLabel(seat) {
  return [
    seat.blockName ? `Sec ${seat.blockName}` : "",
    seat.row ? `Row ${seat.row}` : "",
    seat.seatNumber ? `Seat ${seat.seatNumber}` : ""
  ].filter(Boolean).join(" / ");
}

function rowGroupLabel(group) {
  const seatText = group.from === group.to ? `Seat ${group.from}` : `Seats ${group.from}-${group.to}`;
  return `Sec ${group.blockName || "-"} / Row ${group.row || "-"} / ${seatText}`;
}

function offeringLabel(offering) {
  const seatText = offering.from === offering.to ? `${offering.from}` : `${offering.from}-${offering.to}`;
  return `${offering.blockName || "-"} · ${offering.row || "-"} · ${seatText}`;
}

function findSeatButtonHtml(offering) {
  if (!currentGame || !offering?.blockName || !offering?.row) return "";
  const firstSeat = offering.seats?.[0] || offering;
  const seatNumber = firstSeat.seatNumber || offering.from || "";
  if (!seatNumber) return "";
  const label = `Find ${offeringLabel(offering)} on map`;
  return `
    <button
      type="button"
      class="find-seat-btn"
      data-find-seat="1"
      data-performance-id="${escapeHtml(currentGame.performanceId || "")}"
      data-product-id="${escapeHtml(currentGame.productId || "")}"
      data-site="${escapeHtml(currentGame.site || "")}"
      data-block-name="${escapeHtml(offering.blockName || "")}"
      data-row="${escapeHtml(offering.row || "")}"
      data-seat-number="${escapeHtml(seatNumber)}"
      data-seat-from="${escapeHtml(offering.from ?? seatNumber)}"
      data-seat-to="${escapeHtml(offering.to ?? seatNumber)}"
      data-ticket-count="${escapeHtml(offering.ticketCount || 1)}"
      data-category-name="${escapeHtml(offering.categoryName || firstSeat.categoryName || "")}"
      data-map-point-x="${escapeHtml(offering.mapPointX ?? firstSeat.mapPointX ?? "")}"
      data-map-point-y="${escapeHtml(offering.mapPointY ?? firstSeat.mapPointY ?? "")}"
      data-row-hint="${escapeHtml(rowHintForOffering(offering))}"
      aria-label="${escapeHtml(label)}"
      title="${escapeHtml(label)}"
    >Map</button>
  `;
}

function findSeatTargetFromButton(button) {
  return {
    performanceId: button.dataset.performanceId || currentGame?.performanceId || "",
    productId: button.dataset.productId || currentGame?.productId || "",
    site: button.dataset.site || currentGame?.site || "",
    blockName: button.dataset.blockName || "",
    row: button.dataset.row || "",
    seatNumber: button.dataset.seatNumber || "",
    seatFrom: button.dataset.seatFrom || "",
    seatTo: button.dataset.seatTo || "",
    ticketCount: Number(button.dataset.ticketCount || 1),
    categoryName: button.dataset.categoryName || "",
    mapPointX: button.dataset.mapPointX || "",
    mapPointY: button.dataset.mapPointY || "",
    rowHint: button.dataset.rowHint || ""
  };
}

function openSeatOnMap(button) {
  if (!button || !currentGame) return;
  statusText("Opening map");
  chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_FIND_SEAT_ON_MAP",
    target: findSeatTargetFromButton(button)
  }).then((result) => {
    statusText(result?.ok ? "Map guide opened" : (result?.error || "Could not open map"));
  }).catch((error) => {
    statusText(String(error?.message || error || "Could not open map"));
  });
}

function seatMapById(seats) {
  return Object.fromEntries((seats || []).map((seat) => [seat.seatId, seat]));
}

function seatScrapedAt(seat, fallback = "") {
  return seat?.scrapedAt || seat?.capturedAt || fallback || "";
}

function seatObservationKey(seat) {
  return String(
    seat?.resaleMovementId ||
    seat?.movementId ||
    seat?.sourceFeatureId ||
    seat?.seatId ||
    [seat?.blockName, seat?.row, seat?.seatNumber, seat?.sellerListPrice].filter(Boolean).join(":")
  );
}

function dedupeSeatRows(seats) {
  const map = new Map();
  for (const seat of seats || []) {
    const key = seatObservationKey(seat);
    const existing = map.get(key);
    if (!existing || seatScrapedAt(seat) >= seatScrapedAt(existing)) {
      map.set(key, seat);
    }
  }
  return Array.from(map.values());
}

function latestSeatRows(game) {
  const seats = dedupeSeatRows(Object.values(game?.seats || {}));
  if (!seats.length) return [];

  const currentScrapeId = game?.currentScrape?.scrapeId || game?.scanProgress?.scanId || "";
  if (currentScrapeId) {
    const current = seats.filter((seat) => seat.scrapeId === currentScrapeId);
    if (current.length) return dedupeSeatRows(current);
  }

  const withScrapeId = seats.filter((seat) => seat.scrapeId);
  if (withScrapeId.length) {
    const latestByScrape = withScrapeId.reduce((best, seat) => {
      const key = seat.scrapeId;
      const time = seatScrapedAt(seat, seat.scrapeStartedAt);
      const previous = best.get(key);
      if (!previous || time > previous.time) best.set(key, { time, key });
      return best;
    }, new Map());
    const latestScrapeId = Array.from(latestByScrape.values())
      .sort((a, b) => a.time.localeCompare(b.time))
      .pop()?.key;
    const latest = seats.filter((seat) => seat.scrapeId === latestScrapeId);
    if (latest.length) return dedupeSeatRows(latest);
  }

  const latestTime = seats
    .map((seat) => seatScrapedAt(seat))
    .filter(Boolean)
    .sort()
    .pop();
  if (!latestTime) return seats;
  const latestMinute = latestTime.slice(0, 16);
  const latest = seats.filter((seat) => seatScrapedAt(seat).slice(0, 16) === latestMinute);
  return latest.length ? dedupeSeatRows(latest) : seats;
}

function latestPreviousSnapshot(game) {
  const snapshots = game?.snapshots || [];
  if (snapshots.length < 2) return null;
  return snapshots[snapshots.length - 2];
}

function compactSeatLabel(seat, fallback = "") {
  if (!seat) return fallback ? fallback.slice(0, 18) : "-";
  return [seat.blockName, seat.row, seat.seatNumber].filter(Boolean).join(" ");
}

function pageForList(id, total, pageSize = 25) {
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const current = Math.min(pageCount - 1, Math.max(0, Number(listPages[id] || 0)));
  listPages[id] = current;
  return {
    current,
    pageCount,
    pageSize,
    start: current * pageSize,
    end: Math.min(total, (current + 1) * pageSize)
  };
}

function paginationHtml(id, total, page, singular = "item") {
  if (total <= page.pageSize) return "";
  const label = `${page.start + 1}-${page.end} of ${total}`;
  return `
    <div class="pager">
      <span>${escapeHtml(label)}</span>
      <button class="pager-btn" data-page-list="${escapeHtml(id)}" data-page-delta="-1" ${page.current <= 0 ? "disabled" : ""}>Prev</button>
      <button class="pager-btn" data-page-list="${escapeHtml(id)}" data-page-delta="1" ${page.current >= page.pageCount - 1 ? "disabled" : ""}>Next</button>
    </div>
  `;
}

function pagedItems(id, items, pageSize = 25) {
  const page = pageForList(id, items.length, pageSize);
  return { page, items: items.slice(page.start, page.end) };
}

function renderMarketChange(game) {
  const velocity = game?.velocity;
  if (!velocity) return "<div class='muted'>Check prices again later to see what changed.</div>";

  const current = seatMapById(latestSeatRows(game));
  const previousSnapshot = latestPreviousSnapshot(game);
  const previous = seatMapById(previousSnapshot?.seats || []);
  const newSeats = (velocity.newlyListed || []).map((id) => current[id]).filter(Boolean);
  const goneSeats = (velocity.disappeared || []).map((id) => previous[id] || { seatId: id });
  const repriced = (velocity.repriced || []).map((item) => {
    const seat = current[item.seatId] || previous[item.seatId] || { seatId: item.seatId };
    const from = item.fromSellerList;
    const to = item.toSellerList;
    return {
      ...item,
      seat,
      delta: from != null && to != null ? to - from : null
    };
  });
  const movementTotal = (velocity.newlyListedCount || 0) + (velocity.disappearedCount || 0) + (velocity.repricedCount || 0);
  const currentCount = velocity.currentSeatCount ?? gameSeatCount(game);
  const previousCount = velocity.previousSeatCount;
  const inventoryDelta = previousCount == null ? null : currentCount - previousCount;
  const newPage = pagedItems("movement-new", newSeats, 10);
  const repricedPage = pagedItems("movement-price", repriced, 10);
  const gonePage = pagedItems("movement-gone", goneSeats, 25);
  const sinceLabel = previousSnapshot?.capturedAt ? new Date(previousSnapshot.capturedAt).toLocaleTimeString() : "your last check";
  const movementFoot = movementTotal
    ? `${movementTotal} changes since ${sinceLabel}. FIFA list means the public ticket price before buyer fee and before seller fee.`
    : `No changes since ${sinceLabel}. FIFA list means the public ticket price before buyer fee and before seller fee.`;

  return `
    <div class="movement-summary">
      <div><span>For sale now</span><strong>${currentCount}</strong><em>${inventoryDelta == null ? "first check" : `${inventoryDelta >= 0 ? "+" : ""}${inventoryDelta}`}</em></div>
      <div><span>New</span><strong>${velocity.newlyListedCount || 0}</strong><em>added</em></div>
      <div><span>Price</span><strong>${velocity.repricedCount || 0}</strong><em>changed</em></div>
      <div><span>Gone</span><strong>${velocity.disappearedCount || 0}</strong><em>no longer for sale</em></div>
    </div>
    ${movementTotal ? `<div class="movement-grid">
      <div class="movement-column new">
        <div class="movement-title"><strong>New for sale</strong><span>${velocity.newlyListedCount || 0}</span></div>
        ${newPage.items.map((seat) => `
          <div class="movement-item">
            <b>${escapeHtml(compactSeatLabel(seat))}</b>
            <span>${money(seat.sellerListPrice)}</span>
            <em>FIFA list before fees</em>
          </div>
        `).join("") || "<div class='muted'>No new seats found.</div>"}
        ${paginationHtml("movement-new", newSeats.length, newPage.page, "seat")}
      </div>
      <div class="movement-column price">
        <div class="movement-title"><strong>Price changed</strong><span>${velocity.repricedCount || 0}</span></div>
        ${repricedPage.items.map((item) => `
          <div class="movement-item">
            <b>${escapeHtml(compactSeatLabel(item.seat, item.seatId))}</b>
            <span class="${item.delta > 0 ? "up" : "down"}">${item.delta == null ? "" : `${item.delta > 0 ? "+" : ""}${money(item.delta)}`}</span>
            <em>FIFA list ${money(item.fromSellerList)} -> ${money(item.toSellerList)}</em>
          </div>
        `).join("") || "<div class='muted'>No price changes.</div>"}
        ${paginationHtml("movement-price", repriced.length, repricedPage.page, "price change")}
      </div>
      <div class="movement-column gone">
        <div class="movement-title"><strong>No longer listed</strong><span>${velocity.disappearedCount || 0}</span></div>
        ${gonePage.items.map((seat) => `
          <div class="movement-item">
            <b>${escapeHtml(compactSeatLabel(seat, seat.seatId))}</b>
            <span>${money(seat.sellerListPrice)}</span>
            <em>Last seen FIFA list</em>
          </div>
        `).join("") || "<div class='muted'>No seats disappeared.</div>"}
        ${paginationHtml("movement-gone", goneSeats.length, gonePage.page, "seat")}
      </div>
    </div>` : ""}
    <div class="movement-foot ${movementTotal ? "" : "quiet"}">${movementFoot}</div>
  `;
}

function renderInsights(game, seats) {
  if (!seats.length) {
    if (isScanActive(game.scanProgress)) {
      const progress = game.scanProgress || {};
      return `
        <div class="stream-empty">
          <strong>Checking seats</strong>
          <span>${progress.completed || 0}/${progress.total || 0} areas checked. Tickets appear as they are found.</span>
          <div class="stream-skeleton"><i></i><i></i><i></i></div>
        </div>
      `;
    }
    const progressFound = Number(game.scanProgress?.found || 0);
    const rawSeen = Number(game.rawFeaturesSeen || 0);
    const diagnostics = game.parseDiagnostics || {};
    const rawFound = rawSeen || progressFound;
    if (rawFound > 0) {
      return `
        <div class="parse-warning">
          <strong>${rawFound} tickets were seen, but seats were not saved.</strong>
          <span>Refresh the FIFA page and check prices again. If it keeps happening, reload the extension.</span>
          <em>${progressFound || 0} tickets seen · ${diagnostics.apiResponses || 0} batches saved · app ${diagnostics.contentVersion || game.scanProgress?.contentVersion || "-"}</em>
        </div>
      `;
    }
    return "<div class='muted'>Check prices to see current tickets.</div>";
  }
  const stadiumCategories = hasFullStadiumCatalog(game)
    ? Object.values(game?.stadiumSeats || {}).map(seatCategoryKey)
    : [];
  const categoriesAll = sortedUnique([...seats.map(seatCategoryKey), ...stadiumCategories]);
  if (selectedInsightCategory !== "__all__" && !categoriesAll.includes(selectedInsightCategory)) {
    selectedInsightCategory = "__all__";
  }
  const scopedSeats = selectedInsightCategory === "__all__"
    ? seats
    : seats.filter((seat) => seatCategoryKey(seat) === selectedInsightCategory);
  const stats = marketStats(scopedSeats);
  const availability = availabilityStats(game, scopedSeats, selectedInsightCategory);
  const sellerPrices = scopedSeats.map((seat) => seat.sellerListPrice).filter((price) => price != null).sort((a, b) => a - b);
  const highest = sellerPrices.length ? sellerPrices[sellerPrices.length - 1] : null;
  const histogram = histogramBuckets(scopedSeats, "sellerListPrice", 8);
  const maxBucket = Math.max(1, ...histogram.buckets.map((bucket) => bucket.count));
  const liveOfferings = sortedOfferings(adjacentGroups(scopedSeats), "sellerListPrice");
  const dealsPage = pagedItems(`live-deals-${selectedInsightCategory}`, liveOfferings, 10);
  const previous = seatMapById(latestPreviousSnapshot(game)?.seats || []);
  const cleaned = (game.velocity?.disappeared || [])
    .map((seatId) => previous[seatId])
    .filter((seat) => seat && (selectedInsightCategory === "__all__" || seatCategoryKey(seat) === selectedInsightCategory))
    .sort((a, b) => Number(a.sellerListPrice ?? Infinity) - Number(b.sellerListPrice ?? Infinity));
  const cleanedPage = pagedItems(`cleaned-${selectedInsightCategory}`, cleaned, 10);
  const categoryButtons = ["__all__", ...categoriesAll].map((category) => {
    const active = category === selectedInsightCategory;
    const label = category === "__all__" ? "All" : category;
    const categorySeats = category === "__all__" ? seats : seats.filter((seat) => seatCategoryKey(seat) === category);
    const categoryAvailability = availabilityStats(game, categorySeats, category);
    const stat = categoryAvailability.percent == null
      ? categorySeats.length.toLocaleString()
      : percent(categoryAvailability.percent);
    const note = categoryAvailability.total == null
      ? "for sale"
      : `${categoryAvailability.live.toLocaleString()} / ${categoryAvailability.total.toLocaleString()}`;
    return `
      <button class="filter-chip ${active ? "active" : ""}" data-insight-category="${escapeHtml(category)}">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(stat)}</strong>
        <em>${escapeHtml(note)}</em>
      </button>
    `;
  }).join("");

  return `
    <div class="market-panel">
      <div class="filter-bar">${categoryButtons}</div>
      <div class="supply-head">
        <div><span>${availability.label}</span><strong>${availability.percent == null ? scopedSeats.length : percent(availability.percent)}</strong><em>${escapeHtml(availability.note)}</em></div>
        <div><span>Cheapest</span><strong class="good">${money(stats.sellerFloor)}</strong></div>
        <div><span>Middle price</span><strong>${money(stats.sellerMedian)}</strong></div>
        <div><span>Highest</span><strong class="hot">${money(highest)}</strong></div>
      </div>

      <div class="supply-histogram" aria-label="Live FIFA-list price histogram">
        ${histogram.buckets.map((bucket) => `
          <div class="supply-bar ${bucket.outlier ? "outlier" : ""}" title="${money(bucket.from)}-${money(bucket.to)} · ${bucket.count}">
            <b>${bucket.count || ""}</b>
            <span style="height:${Math.max(4, Math.round((bucket.count / maxBucket) * 100))}%"></span>
            <em>${escapeHtml(bucket.label || `${compactMoney(bucket.from)}-${compactMoney(bucket.to)}`)}</em>
          </div>
        `).join("")}
      </div>

      <div class="deal-columns">
        <div>
          <div class="best-deals-head">
            <strong>Cheapest similar seats</strong>
            <span>${liveOfferings.length}</span>
          </div>
          <div class="deal-list compact">
            <div class="deal-table-head">
              <span></span>
              <span>Seat</span>
              <span>FIFA price</span>
              <span>Buyer pays</span>
              <span>Seller gets</span>
            </div>
            ${dealsPage.items.map((offering, index) => `
              <div class="deal-row">
                <div class="deal-rank ${dealsPage.page.start + index < 3 ? "podium" : ""}">${dealsPage.page.start + index + 1}</div>
                <div class="deal-seat">
                  <strong>${findSeatButtonHtml(offering)}${escapeHtml(offeringLabel(offering))} <b class="ticket-count">x${offering.ticketCount}</b></strong>
                  <span>${escapeHtml(offering.categoryName || "Category")}</span>
                </div>
                <div class="deal-price">
                  <strong>${money(offering.sellerListPrice)}</strong>
                </div>
                <div class="deal-price">
                  <strong>${money(offering.buyerAllInPrice)}</strong>
                </div>
                <div class="deal-price">
                  <strong>${money(offering.estimatedSellerNet)}</strong>
                </div>
              </div>
            `).join("")}
            ${paginationHtml(`live-deals-${selectedInsightCategory}`, liveOfferings.length, dealsPage.page, "offer")}
          </div>
        </div>
        <div>
          <div class="best-deals-head cleaned">
            <strong>No longer for sale</strong>
            <span>${cleaned.length}</span>
          </div>
          <div class="deal-list compact">
            <div class="deal-table-head">
              <span></span>
              <span>Seat</span>
              <span>FIFA price</span>
              <span>Status</span>
              <span>Seller gets</span>
            </div>
            ${cleanedPage.items.map((seat) => `
              <div class="deal-row cleaned">
                <div class="deal-rank">-</div>
                <div class="deal-seat">
                  <strong>${escapeHtml(seat.blockName ? `${seat.blockName} · ${seat.row || "-"} · ${seat.seatNumber || "-"}` : compactSeatLabel(seat))}</strong>
                  <span>${escapeHtml(seat.categoryName || "Category")}</span>
                </div>
                <div class="deal-price">
                  <strong>${money(seat.sellerListPrice)}</strong>
                </div>
                <div class="deal-price">
                  <strong>Gone</strong>
                </div>
                <div class="deal-price">
                  <strong>${money(seat.estimatedSellerNet)}</strong>
                </div>
              </div>
            `).join("")}
            ${paginationHtml(`cleaned-${selectedInsightCategory}`, cleaned.length, cleanedPage.page, "seat")}
          </div>
        </div>
      </div>
      <div class="clean-note">
        Gone means a seat was there before and is not there now. It may have sold, or the seller may have removed it.
      </div>
    </div>
  `;
}

function renderScanProgress(progress) {
  if (!progress) return "";
  const completed = Number(progress.completed || 0);
  const total = Number(progress.total || 0);
  const percentValue = total > 0 ? Math.min(100, Math.max(0, Math.round((completed / total) * 100))) : 0;
  const status = String(progress.status || "scanning");
  const waitMinutes = Math.max(1, Math.ceil(Number(progress.retryAfterMs || 0) / 60000));
  const ageMs = progress.updatedAt ? Date.now() - Date.parse(progress.updatedAt) : 0;
  const stalled = isScanActive(progress) && ageMs > 35000;
  const complete = isScanComplete(progress);
  const partialDone = status === "done" && total > 0 && completed < total;
  const statusLabel = stalled
    ? "Stopped"
    : (status === "done" && complete) || (complete && status === "scanning")
      ? "Done"
      : partialDone
        ? "Stopped"
      : status === "started"
        ? "Starting"
        : status === "blocked"
          ? "Wait"
          : status === "cooldown"
            ? "Waiting"
            : "Scanning";
  const statusValue = stalled
    ? "Try again"
    : status === "cooldown"
      ? `${waitMinutes} min`
      : total > 0
      ? `${percentValue}%`
      : "-";
  const diagnosticBits = [
    progress.attemptedTiles != null ? `${progress.attemptedTiles} tried` : "",
    progress.successfulTiles != null ? `${progress.successfulTiles} ok` : "",
    progress.blockedTiles ? `${progress.blockedTiles} blocked` : "",
    progress.timedOutTiles ? `${progress.timedOutTiles} timed out` : "",
    progress.errorTiles ? `${progress.errorTiles} failed` : ""
  ].filter(Boolean).join(" · ");
  const versionStale = (progress.injectedVersion && progress.injectedVersion !== APP_VERSION) ||
    (progress.contentVersion && progress.contentVersion !== APP_VERSION);
  const versionNote = versionStale ? " Refresh the FIFA tab once after updating the extension." : "";
  const detail = status === "blocked"
    ? `FIFA asked us to wait${progress.httpStatus ? ` with HTTP ${progress.httpStatus}` : ""}${progress.bbox ? ` near ${progress.bbox}` : ""}.${diagnosticBits ? ` ${diagnosticBits}.` : ""} Wait before checking again.${versionNote}`
    : partialDone
      ? `Stopped after ${completed}/${total} areas.${diagnosticBits ? ` ${diagnosticBits}.` : ""}${versionNote}`
      : "";
  return `
    <div class="scan-progress ${stalled ? "stalled" : ""}" ${detail ? `data-tooltip="${escapeHtml(detail)}"` : ""} aria-label="Scan progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percentValue}">
      <div class="scan-progress-head">
        <strong>${escapeHtml(statusLabel)}</strong>
        <span>${escapeHtml(statusValue)}</span>
      </div>
    </div>
  `;
}

function renderSummary(game, seats, stats, progress) {
  const sellerFloor = marketStats(seats).sellerFloor;
  return `
    <div class="match-hero">
      <div class="match-topline">
        <span>${escapeHtml(game.match?.matchCode || "FWC 26")}</span>
        <strong>${seats.length}</strong>
      </div>
      <h1>${escapeHtml(matchName(game))}</h1>
      <div class="match-meta">${escapeHtml([matchVenue(game), matchDateTime(game)].filter(Boolean).join(" · "))}</div>
      <div class="price-eyebrow">Cheapest ticket found</div>
      <div class="hero-prices">
        <div>
          <span>Buyer pays</span>
          <strong>${money(stats.min)}</strong>
          <em>final checkout</em>
        </div>
        <div>
          <span>FIFA price</span>
          <strong>${money(sellerFloor)}</strong>
          <em>public listing</em>
        </div>
        <div>
          <span>Seller gets</span>
          <strong>${money(sellerListToSellerNet(sellerFloor))}</strong>
          <em>after seller fee</em>
        </div>
      </div>
    </div>
  `;
}

function captureGameIndexOpenState() {
  const stored = document.querySelector("[data-index-section='stored']");
  const discovered = document.querySelector("[data-index-section='discovered']");
  if (stored) gameIndexOpenState.stored = stored.open;
  if (discovered) gameIndexOpenState.discovered = discovered.open;
}

function renderGameIndex(state) {
  const entries = Object.entries(state.games || {})
    .sort(([, a], [, b]) => String(b.lastUpdatedAt || "").localeCompare(String(a.lastUpdatedAt || "")));
  const discovered = state.discoveredMatches;
  const multiScan = state.multiScan;
  const discoveredCount = discovered?.matches?.length || 0;
  const defaultStoredOpen = !currentGame || entries.length === 0;
  const storedOpen = gameIndexOpenState.stored ?? defaultStoredOpen;
  const discoveredOpen = gameIndexOpenState.discovered ?? false;

  const storedRows = entries.map(([key, game]) => {
    const active = currentGame && game.performanceId === currentGame.performanceId;
    const seats = gameSeatCount(game);
    return `
      <div class="game-index-row ${active ? "active" : ""}">
        <button class="game-index-select" data-game-key="${escapeHtml(key)}">
          <span>
            <strong>${escapeHtml(matchName(game))}</strong>
            <em>${escapeHtml(matchVenue(game))} · ${escapeHtml(matchDateTime(game))}</em>
          </span>
          <span class="game-index-metrics">
            <b>${seats}</b>
            <small>${escapeHtml(gameLastUpdated(game))}</small>
          </span>
        </button>
        <button class="game-index-delete" data-delete-game-key="${escapeHtml(key)}" title="Remove stored game" aria-label="Remove stored game">×</button>
      </div>
    `;
  }).join("");

  const discoveredRows = (discovered?.matches || []).slice(0, 18).map((match) => `
    <div class="discovered-row">
      <span><strong>${escapeHtml(match.matchCode || "")}</strong> ${escapeHtml([match.home, match.away].filter(Boolean).join(" vs ") || match.name || "Match")}</span>
      <span>${escapeHtml([match.date, match.time, match.venue].filter(Boolean).join(" · "))}</span>
    </div>
  `).join("");

  return `
    <div class="index-summary">
      <div><span>Found games</span><strong>${discoveredCount}</strong></div>
      <div><span>Saved games</span><strong>${entries.length}</strong></div>
      <div><span>Status</span><strong>${escapeHtml(multiScan?.status || "-")}</strong></div>
      <div><span>Done</span><strong>${multiScan ? `${multiScan.completedMatches || 0}/${multiScan.totalMatches || 0}` : "-"}</strong></div>
    </div>
    <details class="match-index" data-index-section="stored" ${storedOpen ? "open" : ""}>
      <summary>Saved games</summary>
      <div class="game-index-list">${storedRows || "<div class='muted'>No saved games yet.</div>"}</div>
    </details>
    <details class="match-index" data-index-section="discovered" ${discoveredOpen ? "open" : ""}>
      <summary>Games found nearby</summary>
      <div class="discovered-list">${discoveredRows || "<div class='muted'>Open the FIFA game list to find more games.</div>"}</div>
    </details>
  `;
}

function parseMySeats(input) {
  return String(input || "")
    .split(/\n|;/)
    .flatMap((line) => line.split(/,(?=\s*[A-Za-z0-9]+\s+[A-Za-z]+\s+\d+)/))
    .map((line) => line.trim())
    .filter(Boolean)
    .flatMap((line) => {
      const normalized = line.replace(/\b(block|sec|section|row|seat|seats)\b/gi, " ");
      const tokens = normalized.match(/[A-Za-z0-9]+/g) || [];
      const blockName = tokens[0] || "";
      const row = tokens[1] || "";
      const seatNumbers = tokens.slice(2).filter((token) => /^\d+$/.test(token));
      if (!seatNumbers.length) {
        const lastNumber = [...tokens].reverse().find((token) => /^\d+$/.test(token)) || "";
        return [{ raw: line, blockName, row: tokens.slice(1, -1).join(" ") || row, seatNumber: lastNumber }];
      }
      return seatNumbers.map((seatNumber) => ({
        raw: seatNumbers.length > 1 ? `${blockName} ${row} ${seatNumber}` : line,
        blockName,
        row,
        seatNumber
      }));
    });
}

function matchesSeat(inputSeat, marketSeat) {
  const sameBlock = !inputSeat.blockName || String(marketSeat.blockName).toLowerCase() === inputSeat.blockName.toLowerCase();
  const sameRow = !inputSeat.row || String(marketSeat.row).toLowerCase() === inputSeat.row.toLowerCase();
  const sameSeat = !inputSeat.seatNumber || String(marketSeat.seatNumber).toLowerCase() === inputSeat.seatNumber.toLowerCase();
  return sameBlock && sameRow && sameSeat;
}

function nearbyComps(inputSeat, seats) {
  const block = inputSeat.blockName.toLowerCase();
  const row = inputSeat.row.toLowerCase();
  const exact = seats.filter((s) => matchesSeat(inputSeat, s));
  const sameRow = seats.filter((s) =>
    (!block || String(s.blockName).toLowerCase() === block) &&
    (!row || String(s.row).toLowerCase() === row)
  );
  const sameBlock = seats.filter((s) => !block || String(s.blockName).toLowerCase() === block);
  const inferredCategory = exact[0]?.categoryId || sameRow[0]?.categoryId || sameBlock[0]?.categoryId || "";
  const sameCategory = inferredCategory
    ? seats.filter((s) => String(s.categoryId || "") === String(inferredCategory))
    : [];
  const comps = sameRow.length
    ? sameRow
    : (sameCategory.length ? sameCategory : (sameBlock.length ? sameBlock : seats));
  return {
    exact,
    sameRow,
    sameBlock,
    sameCategory,
    inferredCategory,
    comps
  };
}

function enteredOfferings(inputs) {
  const byLocation = inputs.reduce((acc, seat) => {
    const key = `${seat.blockName.toLowerCase()}|${seat.row.toLowerCase()}`;
    if (!acc[key]) acc[key] = [];
    acc[key].push(seat);
    return acc;
  }, {});
  return Object.values(byLocation)
    .map((group) => group.map((seat) => ({ ...seat, n: numericSeatNumber(seat.seatNumber) })).filter((seat) => seat.n != null).sort((a, b) => a.n - b.n))
    .flatMap((group) => {
      const runs = [];
      let run = [];
      for (const seat of group) {
        if (!run.length || seat.n === run[run.length - 1].n + 1) run.push(seat);
        else {
          if (run.length) runs.push(run);
          run = [seat];
        }
      }
      if (run.length) runs.push(run);
      return runs.map((runSeats) => ({
        blockName: runSeats[0]?.blockName || "",
        row: runSeats[0]?.row || "",
        from: runSeats[0]?.n ?? null,
        to: runSeats[runSeats.length - 1]?.n ?? null,
        ticketCount: runSeats.length,
        seats: runSeats,
        raw: runSeats.length === 1
          ? (runSeats[0].raw || `${runSeats[0].blockName} ${runSeats[0].row} ${runSeats[0].seatNumber}`)
          : `${runSeats[0].blockName} ${runSeats[0].row} ${runSeats[0].n}-${runSeats[runSeats.length - 1].n}`
      }));
    });
}

function packagePriceKey(offering) {
  return [
    offering.blockName || "",
    offering.row || "",
    offering.from ?? "",
    offering.to ?? "",
    offering.ticketCount || 1
  ].map((part) => String(part).toLowerCase()).join("|");
}

function packagePriceValues(offering) {
  const key = packagePriceKey(offering);
  const values = packagePrices[key] || {};
  const paidPerTicket = numericInputValue(values.cost);
  const ticketCount = Math.max(1, Number(offering.ticketCount) || 1);
  return {
    key,
    costRaw: values.cost ?? "",
    targetListRaw: values.targetList ?? "",
    paidPerTicket,
    totalCost: paidPerTicket == null ? null : paidPerTicket * ticketCount,
    targetList: numericInputValue(values.targetList),
    compScope: values.compScope === "stadium" ? "stadium" : "category"
  };
}

function packagePriceInputsHtml(offering, values) {
  const ticketCount = Math.max(1, Number(offering.ticketCount) || 1);
  const costLabel = ticketCount > 1 ? "Paid / ticket" : "Paid";
  const costHint = ticketCount > 1 && values.totalCost != null ? `total ${money(values.totalCost)}` : "";
  return `
    <div class="package-price-row">
      <label>
        <span>${escapeHtml(costLabel)}${costHint ? ` · ${escapeHtml(costHint)}` : ""}</span>
        <input type="text" inputmode="decimal" pattern="[0-9]*[.]?[0-9]*" placeholder="${ticketCount > 1 ? "Paid each" : "What you paid"}" value="${escapeHtml(values.costRaw ?? "")}" data-package-key="${escapeHtml(values.key)}" data-package-field="cost">
      </label>
      <label>
        <span>FIFA / ticket</span>
        <input type="text" inputmode="decimal" pattern="[0-9]*[.]?[0-9]*" placeholder="Try a price" value="${escapeHtml(values.targetListRaw ?? "")}" data-package-key="${escapeHtml(values.key)}" data-package-field="targetList">
      </label>
      <label>
        <span>Compare</span>
        <select data-package-key="${escapeHtml(values.key)}" data-package-field="compScope">
          <option value="category" ${values.compScope === "category" ? "selected" : ""}>Same category</option>
          <option value="stadium" ${values.compScope === "stadium" ? "selected" : ""}>Whole stadium</option>
        </select>
      </label>
    </div>
  `;
}

function nearbyCompsForOffering(offering, seats) {
  const representative = offering.seats[0] || offering;
  const base = nearbyComps(representative, seats);
  const offerings = sortedOfferings(adjacentGroups(base.comps), "sellerListPrice");
  const sameSize = offerings.filter((comp) => comp.ticketCount === offering.ticketCount);
  const exactSeats = seats.filter((seat) =>
    String(seat.blockName).toLowerCase() === String(offering.blockName).toLowerCase() &&
    String(seat.row).toLowerCase() === String(offering.row).toLowerCase() &&
    offering.seats.some((inputSeat) => String(inputSeat.seatNumber) === String(seat.seatNumber))
  );
  return {
    ...base,
    offerings,
    sameSizeOfferings: sameSize,
    compOfferings: sameSize.length ? sameSize : offerings,
    exactSeats
  };
}

function offeringScopeFromSeats(scopeSeats, offering) {
  const allOfferings = sortedOfferings(adjacentGroups(scopeSeats || []), "sellerListPrice");
  const sameSizeOfferings = allOfferings.filter((comp) => comp.ticketCount === offering.ticketCount);
  return {
    offerings: sameSizeOfferings.length ? sameSizeOfferings : allOfferings,
    totalOfferings: allOfferings.length,
    usedSameSize: sameSizeOfferings.length > 0
  };
}

function pricingScopesForOffering(game, offering, seats, fallbackCategorySeats = []) {
  const categorySeats = sameCategorySeatsForOffering(game, offering, seats, fallbackCategorySeats);
  const category = offeringScopeFromSeats(categorySeats, offering);
  const stadium = offeringScopeFromSeats(seats, offering);
  const categoryName = categorySeats[0]?.categoryName || categorySeats[0]?.categoryId || "same category";
  return {
    category: {
      ...category,
      key: "category",
      label: "same category",
      title: categoryName
    },
    stadium: {
      ...stadium,
      key: "stadium",
      label: "whole stadium",
      title: "whole stadium"
    }
  };
}

function recommendationStats(offerings) {
  const prices = (offerings || [])
    .map((offering) => Number(offering.sellerListPrice))
    .filter((price) => Number.isFinite(price))
    .sort((a, b) => a - b);
  const floor = prices[0] ?? null;
  const median = percentile(prices, 0.5);
  const p75 = percentile(prices, 0.75);
  const average = prices.length
    ? prices.reduce((sum, price) => sum + price, 0) / prices.length
    : null;
  return { prices, floor, median, p75, average };
}

function targetPricePosition(targetList, offerings) {
  if (targetList == null || !offerings.length) return null;
  const prices = offerings
    .map((offering) => Number(offering.sellerListPrice))
    .filter((price) => Number.isFinite(price))
    .sort((a, b) => a - b);
  if (!prices.length) return null;
  const cheaper = prices.filter((price) => price < targetList).length;
  const equalOrCheaper = prices.filter((price) => price <= targetList).length;
  const percentileRank = Math.round((equalOrCheaper / prices.length) * 100);
  const label = cheaper === 0
    ? "cheapest"
    : `${cheaper} cheaper`;
  return { cheaper, equalOrCheaper, total: prices.length, percentileRank, label };
}

function sellerFloorForSeats(seats) {
  const prices = (seats || [])
    .map((seat) => Number(seat.sellerListPrice))
    .filter((price) => Number.isFinite(price))
    .sort((a, b) => a - b);
  return prices[0] ?? null;
}

function sameCategorySeatsForOffering(game, offering, seats, fallbackSeats = []) {
  if (fallbackSeats.length) return fallbackSeats;
  const section = stadiumSectionsForGame(game)
    .find((item) => String(item.blockName || item.blockId).toLowerCase() === String(offering.blockName).toLowerCase());
  const categoryId = section?.categoryId ? String(section.categoryId) : "";
  const categoryName = section?.categoryName ? String(section.categoryName).toLowerCase() : "";
  if (!categoryId && !categoryName) return [];
  return (seats || []).filter((seat) =>
    (categoryId && String(seat.categoryId || "") === categoryId) ||
    (categoryName && String(seat.categoryName || "").toLowerCase() === categoryName)
  );
}

function priceDeltaLabel(targetList, referencePrice) {
  if (targetList == null || referencePrice == null) {
    return { label: "-", detail: "no reference", className: "" };
  }
  const delta = targetList - referencePrice;
  const pct = referencePrice > 0 ? Math.abs(delta / referencePrice) : null;
  if (Math.abs(delta) < 0.01) {
    return { label: "At floor", detail: money(referencePrice), className: "even" };
  }
  const direction = delta > 0 ? "Above" : "Below";
  return {
    label: `${direction} ${money(Math.abs(delta))}`,
    detail: `${percent(pct)} vs ${money(referencePrice)}`,
    className: delta > 0 ? "over" : "under"
  };
}

function pricePositionRailHtml(targetList, overallFloor, categoryStats = {}) {
  const markers = [
    { key: "live", label: "Live low", value: overallFloor },
    { key: "category", label: "Cat low", value: categoryStats.floor },
    { key: "category average", label: "Cat avg", value: categoryStats.average },
    { key: "category high", label: "Cat high", value: categoryStats.p75 },
    { key: "target", label: "You", value: targetList }
  ].filter((marker) => Number.isFinite(Number(marker.value)));
  if (markers.length < 2) return "";
  const values = markers.map((marker) => Number(marker.value));
  const min = Math.min(...values);
  const max = Math.max(...values);
  const spread = Math.max(1, max - min);
  const start = Math.max(0, min - spread * 0.08);
  const end = max + spread * 0.08;
  const position = (value) => {
    const raw = ((Number(value) - start) / Math.max(1, end - start)) * 100;
    return Math.min(96, Math.max(4, raw));
  };
  return `
    <div class="price-position" aria-label="Price position">
      <div class="price-position-rail">
        ${markers.map((marker, index) => `
          <span class="price-marker ${escapeHtml(marker.key)} row-${index % 2}" style="left:${position(marker.value).toFixed(2)}%" data-tooltip="${escapeHtml(`${marker.label}: ${money(marker.value)}`)}">
            <b aria-hidden="true"></b>
            <i>${escapeHtml(marker.label)} <em>${compactMoney(marker.value)}</em></i>
          </span>
        `).join("")}
      </div>
    </div>
  `;
}

function targetMarketDeltaHtml(game, offering, targetList, allSeats, sameCategorySeats) {
  if (targetList == null) return "";
  const overallFloor = sellerFloorForSeats(allSeats);
  const categorySeats = sameCategorySeatsForOffering(game, offering, allSeats, sameCategorySeats);
  const categoryStats = recommendationStats(adjacentGroups(categorySeats));
  const categoryFloor = categoryStats.floor;
  const categoryName = categorySeats[0]?.categoryName || categorySeats[0]?.categoryId || "Category";
  const overallDelta = priceDeltaLabel(targetList, overallFloor);
  const categoryDelta = priceDeltaLabel(targetList, categoryFloor);
  const positionRail = pricePositionRailHtml(targetList, overallFloor, categoryStats);
  return `
    <div class="price-stand">
      <div class="price-stand-card">
        <div class="price-stand-row">
          <span><i class="legend-dot live"></i>Lowest live</span>
          <strong class="${overallDelta.className}">${escapeHtml(overallDelta.label)}</strong>
          <em>${escapeHtml(overallDelta.detail)}</em>
        </div>
        <div class="price-stand-row">
          <span><i class="legend-dot category"></i>${escapeHtml(categoryName)}</span>
          <strong class="${categoryDelta.className}">${escapeHtml(categoryDelta.label)}</strong>
          <em>${escapeHtml(categoryDelta.detail)}</em>
        </div>
        ${positionRail}
      </div>
    </div>
  `;
}

function historicalCleanedOfferings(game, offering) {
  const previous = seatMapById(latestPreviousSnapshot(game)?.seats || []);
  const disappeared = (game.velocity?.disappeared || [])
    .map((seatId) => previous[seatId])
    .filter((seat) => seat &&
      String(seat.blockName).toLowerCase() === String(offering.blockName).toLowerCase() &&
      String(seat.row).toLowerCase() === String(offering.row).toLowerCase());
  const rowOfferings = adjacentGroups(disappeared)
    .filter((comp) => comp.ticketCount === offering.ticketCount);
  if (rowOfferings.length) return rowOfferings;
  return adjacentGroups(disappeared).filter((comp) => comp.ticketCount === offering.ticketCount);
}

function velocityEstimate(game, offering, targetList, compOfferings) {
  if (targetList == null) return null;
  const cleaned = historicalCleanedOfferings(game, offering);
  const cleanedPrices = cleaned.map((comp) => comp.sellerListPrice).filter((price) => price != null).sort((a, b) => a - b);
  const compPrices = compOfferings.map((comp) => comp.sellerListPrice).filter((price) => price != null).sort((a, b) => a - b);
  const basis = cleanedPrices.length ? cleanedPrices : compPrices;
  if (!basis.length) return { label: "Not sure", confidence: "new", note: "We need more checks before we can guess speed." };
  const median = percentile(basis, 0.5);
  const p75 = percentile(basis, 0.75);
  const source = cleanedPrices.length ? "tickets that disappeared" : "tickets for sale now";
  if (targetList <= median) return { label: "Fast", confidence: cleanedPrices.length ? "good" : "early", note: `Your price is near the cheaper half of ${source}.` };
  if (targetList <= p75) return { label: "Steady", confidence: cleanedPrices.length ? "good" : "early", note: `Your price is higher, but still in the normal range.` };
  return { label: "Slow", confidence: cleanedPrices.length ? "good" : "early", note: `Your price is above most similar tickets.` };
}

function targetPriceHtml(game, offering, targetList, compOfferings, cost, allSeats = [], sameCategorySeats = []) {
  if (targetList == null) {
    return `<div class="target-card muted">Enter your price to see if it is cheap, fair, or high.</div>`;
  }
  const position = targetPricePosition(targetList, compOfferings);
  const velocity = velocityEstimate(game, offering, targetList, compOfferings);
  const buyerFinal = sellerListToBuyerAllIn(targetList);
  const sellerNet = sellerListToSellerNet(targetList);
  const profit = profitFromNet(sellerNet, cost, offering.ticketCount);
  const margin = profitMarginFromNet(sellerNet, cost, offering.ticketCount);
  const profitClass = profit == null ? "" : (profit >= 0 ? "profit" : "loss");
  return `
    <div class="target-card">
      <div><span>Your price</span><strong>${money(targetList)}</strong><em>buyer pays ${money(buyerFinal)}</em></div>
      <div><span>Price level</span><strong>${escapeHtml(position?.label || "-")}</strong><em>${position ? `${position.total} similar tickets` : "no similar tickets"}</em></div>
      <div><span>Likely speed</span><strong>${escapeHtml(velocity?.label || "-")}</strong><em>${escapeHtml(velocity?.confidence || "early")}</em></div>
      <div class="seller-result ${profitClass}"><span>Seller gets</span><strong>${money(sellerNet == null ? null : sellerNet * offering.ticketCount)}</strong><em>profit ${money(profit)} · ${percent(margin)}</em></div>
      <p>${escapeHtml(velocity?.note || "We need more checks before we can guess speed.")}</p>
    </div>
    ${targetMarketDeltaHtml(game, offering, targetList, allSeats, sameCategorySeats)}
  `;
}

function cheapestOfferingsTableHtml(offerings, listId = "comps", title = "Cheapest similar tickets") {
  const page = pagedItems(listId, offerings || [], 10);
  const rows = page.items;
  if (!rows.length) return `<div class="muted">No similar tickets found.</div>`;
  return `
    <div class="ticket-table">
      <div class="best-deals-head">
        <strong>${escapeHtml(title)}</strong>
        <span>${offerings.length}</span>
      </div>
      <div class="deal-list compact">
        <div class="deal-table-head">
          <span></span>
          <span>Seat</span>
          <span>FIFA price</span>
          <span>Buyer pays</span>
          <span>Seller gets</span>
        </div>
        ${rows.map((offering, index) => `
          <div class="deal-row">
            <div class="deal-rank ${page.page.start + index < 3 ? "podium" : ""}">${page.page.start + index + 1}</div>
            <div class="deal-seat">
              <strong>${findSeatButtonHtml(offering)}${escapeHtml(offeringLabel(offering))} <b class="ticket-count">x${offering.ticketCount}</b></strong>
              <span>${escapeHtml(offering.categoryName || "Category")}</span>
            </div>
            <div class="deal-price">
              <strong>${money(offering.sellerListPrice)}</strong>
            </div>
            <div class="deal-price">
              <strong>${money(offering.buyerAllInPrice)}</strong>
            </div>
            <div class="deal-price">
              <strong>${money(offering.estimatedSellerNet)}</strong>
            </div>
          </div>
        `).join("")}
        ${paginationHtml(listId, offerings.length, page.page, "ticket")}
      </div>
    </div>
  `;
}

function renderMySeatAnalysis(game, seats) {
  const input = mySeatInput.trim();
  const liveInputs = analysisInputsFromSelection();
  if (!input && !liveInputs.length) return "";
  if (!seats.length) return "<div class='muted compact-hint'>Check prices first.</div>";

  const inputs = liveInputs.length ? liveInputs : parseMySeats(input);
  if (!inputs.length) return "<div class='muted'>We could not read that seat. Try section, row, and seat again.</div>";
  const inputOfferings = enteredOfferings(inputs);

  const offeringPage = pagedItems("my-seat-packages", inputOfferings, 5);
  const cards = offeringPage.items.map((inputOffering) => {
    const { compOfferings, sameCategory } = nearbyCompsForOffering(inputOffering, seats);
    const priceValues = packagePriceValues(inputOffering);
    const scopes = pricingScopesForOffering(game, inputOffering, seats, sameCategory);
    const chosenScope = scopes[priceValues.compScope] || scopes.category;
    const ordered = chosenScope.offerings.length ? chosenScope.offerings : compOfferings;
    const scopeStats = recommendationStats(ordered);
    const categoryStats = recommendationStats(scopes.category.offerings);
    const stadiumStats = recommendationStats(scopes.stadium.offerings);
    const floor = scopeStats.floor;
    const median = scopeStats.median;
    const p75 = scopeStats.p75;
    const fastList = floor == null ? null : Math.max(1, floor * 0.97);
    const gainList = median == null ? fastList : median;
    const aggressiveList = p75 == null ? (gainList == null ? fastList : gainList * 1.12) : p75;
    const fastNote = floor == null ? "no comps" : `low ${money(floor)} x 0.97`;
    const gainNote = median == null ? "uses fast price" : `median ${money(median)}`;
    const aggressiveNote = p75 == null
      ? (gainList == null ? "uses fast price" : `${money(gainList)} x 1.12`)
      : `75th pct ${money(p75)}`;
    const cost = priceValues.totalCost;
    const targetList = priceValues.targetList;
    const paidLabel = inputOffering.ticketCount > 1
      ? `${money(priceValues.paidPerTicket)} each · ${money(cost)} total`
      : money(cost);
    const groupTip = inputOffering.ticketCount > 1
      ? `These seats are together, so we compare them with other ${inputOffering.ticketCount}-ticket groups first.`
      : "";

    return `
      <div class="analysis-card">
        <div class="analysis-head">
          <strong>
            ${escapeHtml(inputOffering.raw)}
            <b class="ticket-count">x${inputOffering.ticketCount}</b>
            ${groupTip ? `<span class="info-dot" data-tooltip="${escapeHtml(groupTip)}" tabindex="0">?</span>` : ""}
          </strong>
        </div>
        ${packagePriceInputsHtml(inputOffering, priceValues)}
        <div class="mini-grid">
          <div><span class="label">Category low</span><strong>${money(categoryStats.floor)}</strong></div>
          <div><span class="label">Stadium low</span><strong>${money(stadiumStats.floor)}</strong></div>
          <div><span class="label">Paid</span><strong>${escapeHtml(paidLabel)}</strong></div>
        </div>
        ${pricingSpectrumHtml([
          { label: "Fast", note: fastNote, tone: "fast", price: fastList },
          { label: "Balanced", note: gainNote, tone: "balanced", price: gainList },
          { label: "Aggressive", note: aggressiveNote, tone: "aggressive", price: aggressiveList }
        ], cost, inputOffering.ticketCount)}
        ${targetPriceHtml(game, inputOffering, targetList, ordered, cost, seats, sameCategory)}
        ${cheapestOfferingsTableHtml(ordered, `package-comps-${packagePriceKey(inputOffering)}`, `Cheapest ${chosenScope.label} tickets`)}
      </div>
    `;
  }).join("");

  return `${cards}${paginationHtml("my-seat-packages", inputOfferings.length, offeringPage.page, "package")}`;
}

function setSelectOptions(select, options, selectedValue, placeholder) {
  if (!select) return "";
  const current = selectedValue ?? select.value;
  select.innerHTML = [
    placeholder ? `<option value="">${escapeHtml(placeholder)}</option>` : "",
    ...options.map((option) => {
      const value = typeof option === "string" ? option : option.value;
      const label = typeof option === "string" ? option : option.label;
      return `<option value="${escapeHtml(value)}">${escapeHtml(label)}</option>`;
    })
  ].join("");
  const values = new Set(options.map((option) => String(typeof option === "string" ? option : option.value)));
  if (selectedValue === null) {
    select.value = "";
    return "";
  }
  select.value = values.has(String(current)) ? current : (options[0] ? String(typeof options[0] === "string" ? options[0] : options[0].value) : "");
  return select.value;
}

function setDatalistOptions(input, datalistId, options, currentValue) {
  if (!input) return "";
  const datalist = document.getElementById(datalistId);
  if (datalist) {
    datalist.innerHTML = options.map((option) => {
      const value = typeof option === "string" ? option : option.value;
      const label = typeof option === "string" ? "" : option.label;
      return `<option value="${escapeHtml(value)}"${label && label !== value ? ` label="${escapeHtml(label)}"` : ""}></option>`;
    }).join("");
  }
  const current = currentValue ?? input.value;
  input.value = current || "";
  return input.value;
}

function renderSelectedSeats() {
  const selected = document.getElementById("selectedSeats");
  if (!selected) return;
  if (!selectedMySeats.length) {
    selected.innerHTML = "";
    return;
  }
  const packages = enteredOfferings(selectedMySeats.map((seat) => ({ ...seat, raw: mySeatToInput(seat) })));
  selected.innerHTML = packages.map((offering) => `
    <button class="seat-chip" data-remove-package="${escapeHtml(packagePriceKey(offering))}" title="Remove seat">
      <span>${escapeHtml(offering.raw)}${offering.ticketCount > 1 ? ` x${offering.ticketCount}` : ""}</span>
      <strong>x</strong>
    </button>
  `).join("");
}

function renderSeatPicker(marketSeats, stadiumSeats = marketSeats, sections = [], hasFullCatalog = false) {
  const sectionInput = document.getElementById("seatSection");
  const rowInput = document.getElementById("seatRow");
  if (!sectionInput || !rowInput) return;

  const sectionOptions = (sections.length ? sections : stadiumSeats)
    .map((item) => ({
      value: item.blockName || item.blockId || "",
      label: [item.blockName || item.blockId || "", item.categoryName].filter(Boolean).join(" · ")
    }))
    .filter((item) => item.value);
  const dedupedSections = Array.from(
    sectionOptions.reduce((map, item) => {
      if (!map.has(String(item.value))) map.set(String(item.value), item);
      return map;
    }, new Map()).values()
  ).sort((a, b) => naturalCompare(a.value, b.value));
  const section = setDatalistOptions(sectionInput, "seatSectionOptions", dedupedSections, sectionInput.value);
  const rowSeats = section
    ? stadiumSeats.filter((seat) => String(seat.blockName) === section)
    : stadiumSeats;
  const rows = sortedUnique(rowSeats.map((seat) => seat.row));
  setDatalistOptions(rowInput, "seatRowOptions", rows, rowInput.value);
  renderSelectedSeats();
}

function refreshMySeatAnalysis() {
  if (!currentGame) return;
  const node = document.getElementById("mySeatAnalysis");
  if (!node) return;
  node.innerHTML = renderMySeatAnalysis(currentGame, latestSeatRows(currentGame));
}

function rowSeatNumbers(seats, section, row) {
  return seats
    .filter((seat) => String(seat.blockName) === String(section) && String(seat.row) === String(row))
    .map((seat) => numericSeatNumber(seat.seatNumber))
    .filter((value) => value != null)
    .sort((a, b) => a - b);
}

function validateTypedSeatNumber(stadiumSeats, marketSeats, section, row, seatNumber, hasFullCatalog = false) {
  if (!seatNumber) return { ok: true };
  if (!section || !row) return { ok: false, message: "Choose a section and row first." };
  if (!/^\d+$/.test(String(seatNumber))) return { ok: false, message: "Seat number must be numeric." };
  const value = Number(seatNumber);
  if (value < 1) return { ok: false, message: "Seat number must be greater than zero." };
  const stadiumRowNumbers = rowSeatNumbers(stadiumSeats, section, row);
  const marketRowNumbers = rowSeatNumbers(marketSeats, section, row);
  const rowNumbers = stadiumRowNumbers.length ? stadiumRowNumbers : marketRowNumbers;
  if (!rowNumbers.length) {
    return {
      ok: true,
      message: ""
    };
  }
  const min = rowNumbers[0];
  const max = rowNumbers[rowNumbers.length - 1];
  if (value < min || value > max) {
    return hasFullCatalog
      ? { ok: false, message: `That seat is not in ${section}, row ${row}. This row shows seats ${min}-${max}.` }
      : { ok: true, message: `That seat is not for sale right now. We will price it from nearby seats in ${section}, row ${row}.` };
  }
  if (marketRowNumbers.includes(value)) return { ok: true, message: "This seat is already for sale. We can compare it directly." };
  if (stadiumRowNumbers.includes(value)) return { ok: true, message: "This looks like a real stadium seat. We will compare it with nearby tickets." };
  return { ok: true, message: `This seat is not for sale right now. We will compare it with nearby tickets.` };
}

function addSelectedSeatsFromPicker() {
  if (!currentGame) return;
  const seats = latestSeatRows(currentGame);
  const stadiumSeats = stadiumSeatsForGame(currentGame);
  const section = document.getElementById("seatSection")?.value || "";
  const row = document.getElementById("seatRow")?.value || "";
  const typedNumber = document.getElementById("sellerSeatNumber")?.value || "";
  const validation = validateTypedSeatNumber(stadiumSeats, seats, section, row, typedNumber, hasFullStadiumCatalog(currentGame));
  if (!validation.ok) {
    setValidation(validation.message, "error");
    return;
  }
  const numbers = typedNumber ? [typedNumber] : [];
  const additions = numbers.map((seatNumber) => ({ blockName: section, row, seatNumber }));
  const existing = new Set(selectedMySeats.map(selectionKey));
  for (const seat of additions) {
    if (!seat.blockName || !seat.row || !seat.seatNumber) continue;
    const key = selectionKey(seat);
    if (existing.has(key)) continue;
    selectedMySeats.push(seat);
    existing.add(key);
  }
  syncSelectedInput();
  const input = document.getElementById("sellerSeatNumber");
  if (input) input.value = "";
  setValidation(additions.length ? "" : "Select or type a seat number.", additions.length ? "ok" : "muted");
  renderSelectedSeats();
  setHtml("mySeatAnalysis", renderMySeatAnalysis(currentGame, seats));
  saveSellerInventory();
}

function clearSelectedSeats() {
  selectedMySeats = [];
  packagePrices = {};
  syncSelectedInput();
  renderSelectedSeats();
  if (currentGame) {
    setHtml("mySeatAnalysis", renderMySeatAnalysis(currentGame, latestSeatRows(currentGame)));
  }
  deleteSellerInventory();
}

function demoState() {
  const now = new Date().toISOString();
  const featureSeats = [
    ["253", "FF", "102", "Category 1", 451.78],
    ["253", "FF", "103", "Category 1", 460.00],
    ["253", "GG", "98", "Category 1", 520.00],
    ["202", "AA", "11", "Category 2", 310.00],
    ["202", "AA", "12", "Category 2", 310.00],
    ["440", "WW", "109", "Category 3", 380.00],
    ["440", "WW", "110", "Category 3", 395.00],
    ["118", "B", "7", "Category 1", 775.00]
  ];
  const seats = {};
  for (const [blockName, row, seatNumber, categoryName, sellerListPrice] of featureSeats) {
    const seatId = `${blockName}:${row}:${seatNumber}`;
    seats[seatId] = {
      seatId,
      blockName,
      row,
      seatNumber,
      categoryName,
      sellerListPrice,
      buyerAllInPrice: sellerListToBuyerAllIn(sellerListPrice),
      estimatedSellerNet: sellerListToSellerNet(sellerListPrice),
      seatType: "resale",
      capturedAt: now,
      productId: "10229225515651",
      performanceId: "10229226700890"
    };
  }
  const previousCapturedAt = new Date(Date.now() - 1000 * 60 * 22).toISOString();
  const previousSeats = Object.values(seats)
    .filter((seat) => seat.seatId !== "253:GG:98" && seat.seatId !== "118:B:7")
    .map((seat) => ({
      seatId: seat.seatId,
      blockName: seat.blockName,
      row: seat.row,
      seatNumber: seat.seatNumber,
      categoryName: seat.categoryName,
      sellerListPrice: seat.seatId === "253:FF:102" ? 500 : seat.sellerListPrice,
      buyerAllInPrice: sellerListToBuyerAllIn(seat.seatId === "253:FF:102" ? 500 : seat.sellerListPrice),
      estimatedSellerNet: sellerListToSellerNet(seat.seatId === "253:FF:102" ? 500 : seat.sellerListPrice),
      resaleMovementId: null
    }));
  previousSeats.push({
    seatId: "440:WW:111",
    blockName: "440",
    row: "WW",
    seatNumber: "111",
    categoryName: "Category 3",
    sellerListPrice: 410,
    buyerAllInPrice: sellerListToBuyerAllIn(410),
    estimatedSellerNet: sellerListToSellerNet(410),
    resaleMovementId: null
  });
  return {
    games: {
      "fifa_resale:10229226700890": {
        site: "fifa_resale",
        performanceId: "10229226700890",
        productId: "10229225515651",
        match: { name: "Brazil vs Morocco", date: "Today", venue: "World Cup Stadium" },
        seats,
        categories: {},
        rawFeaturesSeen: featureSeats.length,
        tileStats: [{ featureCount: featureSeats.length }],
        snapshots: [
          {
            snapshotId: "preview-previous",
            capturedAt: previousCapturedAt,
            seatCount: previousSeats.length,
            rawFeaturesSeen: previousSeats.length,
            seats: previousSeats
          },
          {
            snapshotId: "preview-current",
            capturedAt: now,
            seatCount: Object.keys(seats).length,
            rawFeaturesSeen: featureSeats.length,
            seats: Object.values(seats)
          }
        ],
        velocity: {
          previousSnapshotId: "preview-previous",
          currentSnapshotId: "preview-current",
          capturedAt: now,
          currentSeatCount: Object.keys(seats).length,
          previousSeatCount: previousSeats.length,
          newlyListedCount: 2,
          disappearedCount: 1,
          repricedCount: 1,
          stillListedCount: 5,
          newlyListed: ["253:GG:98", "118:B:7"],
          disappeared: ["440:WW:111"],
          repriced: [{ seatId: "253:FF:102", fromSellerList: 500, toSellerList: 451.78 }]
        },
        lastUpdatedAt: now,
        scanProgress: { status: "preview", completed: 32, total: 32, found: featureSeats.length, tileWidth: 10000, tileHeight: 5000 }
      },
      "fifa_resale:10229226700889": {
        site: "fifa_resale",
        performanceId: "10229226700889",
        productId: "10229225515651",
        match: { name: "Haiti vs Scotland", date: "Tomorrow", time: "8:00 PM", venue: "Boston Stadium", matchCode: "Match 5" },
        seats: {},
        categories: {},
        rawFeaturesSeen: 0,
        tileStats: [],
        velocity: null,
        lastUpdatedAt: new Date(Date.now() - 1000 * 60 * 26).toISOString(),
        scanProgress: { status: "queued", completed: 0, total: 32, found: 0, tileWidth: 10000, tileHeight: 5000 }
      }
    },
    discoveredMatches: {
      start: "Today",
      end: "+7d",
      matches: [
        { matchCode: "Match 5", home: "Haiti", away: "Scotland", date: "Tomorrow", time: "8:00 PM", venue: "Boston Stadium" },
        { matchCode: "Match 6", home: "USA", away: "Australia", date: "+2d", time: "7:30 PM", venue: "Los Angeles Stadium" }
      ]
    },
    multiScan: null
  };
}

async function getPopupContext(options = {}) {
  if (!hasChromeApi) {
    return { tab: { url: "" }, state: demoState() };
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const state = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_GET_STATE",
    skipActiveRefresh: options.skipActiveRefresh === true
  });
  return { tab, state };
}

function download(name, type, text) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}

function toCsv(game) {
  const headers = [
    "source",
    "scraped_at",
    "scrape_id",
    "product_id",
    "performance_id",
    "match_name",
    "match_date",
    "venue",
    "category_id",
    "category_name",
    "area_id",
    "area_name",
    "block_id",
    "block_name",
    "row",
    "seat_number",
    "fifa_list_price",
    "buyer_checkout_price_est",
    "seller_net_est",
    "seat_type",
    "exclusive",
    "resale_movement_id",
    "movement_id",
    "tariff_id",
    "advantage_id",
    "seat_quality"
  ];
  const rows = latestSeatRows(game).map((s) => [
    game.site,
    seatScrapedAt(s),
    s.scrapeId,
    s.productId,
    s.performanceId,
    game.match?.name || "",
    game.match?.date || "",
    game.match?.venue || "",
    s.categoryId,
    s.categoryName,
    s.areaId,
    s.areaName,
    s.blockId,
    s.blockName,
    s.row,
    s.seatNumber,
    s.sellerListPrice,
    s.buyerAllInPrice,
    s.estimatedSellerNet,
    s.seatType,
    s.exclusive,
    s.resaleMovementId,
    s.movementId,
    s.tariffId,
    s.advantageId,
    s.seatQuality
  ]);
  return [headers, ...rows]
    .map((row) => row.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

function toAllCsv(state) {
  const games = Object.values(state.games || {});
  const headers = [
    "source",
    "scraped_at",
    "scrape_id",
    "match_code",
    "match_name",
    "match_date",
    "venue",
    "product_id",
    "performance_id",
    "category_name",
    "block_name",
    "row",
    "seat_number",
    "fifa_list_price",
    "buyer_checkout_price_est",
    "seller_net_est",
    "resale_movement_id",
    "velocity_status"
  ];
  const rows = [];
  for (const game of games) {
    const newly = new Set(game.velocity?.newlyListed || []);
    const disappeared = new Set(game.velocity?.disappeared || []);
    const repriced = new Set((game.velocity?.repriced || []).map((item) => item.seatId));
    for (const s of latestSeatRows(game)) {
      const velocityStatus = newly.has(s.seatId) ? "newly_listed" : (repriced.has(s.seatId) ? "repriced" : "still_listed");
      rows.push([
        game.site,
        seatScrapedAt(s),
        s.scrapeId,
        game.match?.matchCode || "",
        game.match?.name || "",
        game.match?.date || "",
        game.match?.venue || "",
        s.productId,
        s.performanceId,
        s.categoryName,
        s.blockName,
        s.row,
        s.seatNumber,
        s.sellerListPrice,
        s.buyerAllInPrice,
        s.estimatedSellerNet,
        s.resaleMovementId,
        velocityStatus
      ]);
    }
    for (const seatId of disappeared) {
      rows.push([
        game.site,
        game.velocity?.capturedAt || "",
        game.currentScrape?.scrapeId || "",
        game.match?.matchCode || "",
        game.match?.name || "",
        game.match?.date || "",
        game.match?.venue || "",
        game.productId,
        game.performanceId,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        `disappeared:${seatId}`
      ]);
    }
  }
  return [headers, ...rows]
    .map((row) => row.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

function toHistoryCsv(game) {
  const headers = [
    "source",
    "scraped_at",
    "scrape_id",
    "snapshot_id",
    "status",
    "gone_detected_at",
    "match_code",
    "match_name",
    "match_date",
    "venue",
    "product_id",
    "performance_id",
    "category_name",
    "block_name",
    "row",
    "seat_number",
    "fifa_list_price",
    "buyer_checkout_price_est",
    "seller_net_est",
    "resale_movement_id"
  ];
  const rows = [];
  const snapshots = game.snapshots || [];
  for (let index = 0; index < snapshots.length; index++) {
    const snapshot = snapshots[index];
    const nextSnapshot = snapshots[index + 1] || null;
    const nextIds = new Set((nextSnapshot?.seats || []).map((seat) => seat.seatId));
    for (const seat of snapshot.seats || []) {
      const removedByNext = nextSnapshot && !nextIds.has(seat.seatId);
      rows.push([
        game.site,
        seatScrapedAt(seat, snapshot.capturedAt),
        seat.scrapeId || "",
        snapshot.snapshotId || "",
        removedByNext ? "gone_by_next_snapshot" : "listed",
        removedByNext ? nextSnapshot.capturedAt || "" : "",
        game.match?.matchCode || "",
        game.match?.name || "",
        game.match?.date || "",
        game.match?.venue || "",
        game.productId,
        game.performanceId,
        seat.categoryName,
        seat.blockName,
        seat.row,
        seat.seatNumber,
        seat.sellerListPrice,
        seat.buyerAllInPrice,
        seat.estimatedSellerNet,
        seat.resaleMovementId
      ]);
    }
  }

  if (!rows.length) {
    for (const seat of latestSeatRows(game)) {
      rows.push([
        game.site,
        seatScrapedAt(seat),
        seat.scrapeId || "",
        "",
        "listed",
        "",
        game.match?.matchCode || "",
        game.match?.name || "",
        game.match?.date || "",
        game.match?.venue || "",
        game.productId,
        game.performanceId,
        seat.categoryName,
        seat.blockName,
        seat.row,
        seat.seatNumber,
        seat.sellerListPrice,
        seat.buyerAllInPrice,
        seat.estimatedSellerNet,
        seat.resaleMovementId
      ]);
    }
  }

  return [headers, ...rows]
    .map((row) => row.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

function statsForSeats(seats) {
  const prices = seats.map((s) => s.buyerAllInPrice).filter((p) => p != null).sort((a, b) => a - b);
  const median = prices.length ? prices[Math.floor(prices.length / 2)] : null;
  return {
    count: seats.length,
    min: prices.length ? prices[0] : null,
    median,
    max: prices.length ? prices[prices.length - 1] : null
  };
}

async function load(options = {}) {
  if (loadInFlight) return;
  loadInFlight = true;
  const restoreScroll = makeScrollRestorer(options.preserveScroll);
  try {
  captureGameIndexOpenState();
  const { tab, state } = await getPopupContext({ skipActiveRefresh: options.preserveScroll === true });
  currentState = state;
  const perfId = activePerformanceIdFromUrl(tab?.url);
  const activeSite = activeSiteFromUrl(tab?.url);
  activeTabPerformanceId = perfId;
  const gameEntries = Object.entries(state.games || {});
  const selectedEntry = selectedGameKey ? gameEntries.find(([key]) => key === selectedGameKey) : null;
  const pageEntry = perfId ? gameEntries.find(([, game]) => game.performanceId === perfId && (!activeSite || game.site === activeSite)) : null;
  const activeEntry = pageEntry || selectedEntry || null;
  selectedGameKey = pageEntry?.[0] || selectedEntry?.[0] || selectedGameKey;
  currentGame = activeEntry?.[1] || null;
  document.body.classList.toggle("no-current-game", !currentGame);

  const status = document.getElementById("status");
  const summary = document.getElementById("summary");
  const categories = document.getElementById("categories");
  const inventory = document.getElementById("inventory");
  const multi = document.getElementById("multi");
  const insights = document.getElementById("insights");
  const movement = document.getElementById("movement");
  const mySeatAnalysis = document.getElementById("mySeatAnalysis");
  const scanProgressSlot = document.getElementById("scanProgressSlot");
  await refreshCrowdSharingUi();
  await refreshCrowdPrompt(null, []);

  if (!currentGame) {
    setScanButtonBusy(false);
    lastFullRenderKey = "no-current-game";
    status.textContent = "No data";
    if (scanProgressSlot) scanProgressSlot.innerHTML = "";
    summary.innerHTML = `
      <div class="empty-state">
        <strong>No game open</strong>
        <span>Open a FIFA seat map, or choose a saved game below.</span>
      </div>
    `;
    categories.textContent = "";
    inventory.textContent = "";
    insights.innerHTML = "<div class='muted'>No prices yet.</div>";
    movement.innerHTML = "<div class='muted'>No changes yet.</div>";
    mySeatAnalysis.innerHTML = "<div class='muted'>Check prices first, then add your seat.</div>";
    renderSeatPicker([]);
    multi.innerHTML = renderMulti(state);
    restoreScroll();
    return;
  }

  const seats = latestSeatRows(currentGame);
  const stadiumSeats = stadiumSeatsForGame(currentGame);
  const stadiumSections = stadiumSectionsForGame(currentGame);
  if (selectedPerformanceId !== currentGame.performanceId) {
    selectedPerformanceId = currentGame.performanceId;
    const savedInventory = await loadSellerInventory(currentGame.performanceId);
    selectedMySeats = savedInventory.seats;
    packagePrices = savedInventory.packagePrices;
    syncSelectedInput();
  }
  const stats = statsForSeats(seats);
  status.textContent = `${seats.length} seats`;
  const progress = currentGame.scanProgress;
  const scanActive = isScanActive(progress);
  setScanButtonBusy(scanActive);
  if (scanProgressSlot) {
    const progressHtml = renderScanProgress(progress);
    if (scanProgressSlot.innerHTML !== progressHtml) scanProgressSlot.innerHTML = progressHtml;
  }
  const fullRenderKey = renderFingerprint(currentGame, seats, { includeScanDiagnostics: !scanActive });
  const progressRenderKey = progressFingerprint(progress);
  const progressOnlyUpdate = options.preserveScroll
    && scanActive
    && lastFullRenderKey === fullRenderKey
    && lastProgressRenderKey !== progressRenderKey;
  if (progressOnlyUpdate) {
    lastProgressRenderKey = progressRenderKey;
    restoreScroll();
    return;
  }
  if (options.preserveScroll && scanActive && lastFullRenderKey === fullRenderKey) {
    restoreScroll();
    return;
  }
  if (options.preserveScroll && scanActive && Date.now() - lastStreamingFullRenderAt < 3600) {
    lastProgressRenderKey = progressRenderKey;
    restoreScroll();
    return;
  }
  lastProgressRenderKey = progressRenderKey;
  lastFullRenderKey = fullRenderKey;
  const streamingRender = options.preserveScroll && scanActive;
  if (streamingRender) lastStreamingFullRenderAt = Date.now();

  summary.innerHTML = renderSummary(currentGame, seats, stats, progress);
  await refreshCrowdPrompt(currentGame, seats);

  insights.innerHTML = renderInsights(currentGame, seats);
  renderSeatPicker(seats, stadiumSeats, stadiumSections, hasFullStadiumCatalog(currentGame));
  mySeatAnalysis.innerHTML = renderMySeatAnalysis(currentGame, seats);
  if (streamingRender) {
    restoreScroll();
    return;
  }
  movement.innerHTML = "<div class='lazy-placeholder'>Loading movement...</div>";
  multi.innerHTML = "<div class='lazy-placeholder'>Loading games...</div>";
  categories.innerHTML = "";
  inventory.innerHTML = "";
  restoreScroll();

  scheduleIdle(() => {
    if (currentGame !== activeEntry?.[1]) return;
    movement.innerHTML = renderMarketChange(currentGame);
    multi.innerHTML = renderMulti(state);
    restoreScroll();
  });

  scheduleIdle(() => {
    if (currentGame !== activeEntry?.[1]) return;
    categories.innerHTML = Object.values(currentGame.categories || {})
      .sort((a, b) => (a.rank || 0) - (b.rank || 0))
      .map((c) => `
        <div class="row">
          <div>${c.name}</div>
          <div>${money(c.minBuyerAllIn)}-${money(c.maxBuyerAllIn)}</div>
          <div class="muted">net ${money(c.minSellerNet)}+</div>
        </div>
      `)
      .join("") || "<div class='muted'>No price groups found yet.</div>";

    const byType = seats.reduce((acc, s) => {
      const key = s.seatType || "unknown";
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const byCategory = seats.reduce((acc, s) => {
      const key = s.categoryName || s.categoryId || "Unknown";
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const tileStats = currentGame.tileStats || [];
    const nonEmptyTiles = tileStats.filter((t) => (t.featureCount || 0) > 0).length;
    const maxTileFeatures = tileStats.reduce((max, t) => Math.max(max, t.featureCount || 0), 0);
    inventory.innerHTML = `
      <div class="row"><div>Game ID</div><div>${escapeHtml(currentGame.performanceId)}</div><div></div></div>
      <div class="row"><div>Ticket group ID</div><div>${escapeHtml(currentGame.productId || "-")}</div><div></div></div>
      <div class="row"><div>Tickets saved</div><div>${stats.count}</div><div class="muted">${currentGame.rawFeaturesSeen || 0} seen</div></div>
      <div class="row"><div>Last checked</div><div>${gameLastUpdated(currentGame)}</div><div></div></div>
      <div class="row"><div>Areas checked</div><div>${tileStats.length}</div><div class="muted">${nonEmptyTiles} with tickets</div></div>
      <div class="row"><div>Busiest area</div><div>${maxTileFeatures}</div><div></div></div>
      <div class="row"><div>Ticket type</div><div></div><div></div></div>
      ${Object.entries(byType).map(([k, v]) => `<div class="row"><div>${k}</div><div>${v}</div><div></div></div>`).join("")}
      <div class="row"><div>Category</div><div></div><div></div></div>
      ${Object.entries(byCategory).map(([k, v]) => `<div class="row"><div>${k}</div><div>${v}</div><div></div></div>`).join("")}
    `;
    restoreScroll();
  });
  } finally {
    loadInFlight = false;
  }
}

function renderMulti(state) {
  return renderGameIndex(state);
}

function on(id, eventName, handler) {
  const node = document.getElementById(id);
  if (!node) return;
  node.addEventListener(eventName, async (event) => {
    try {
      await handler(event);
    } catch (error) {
      statusText(error?.message || "Action failed");
      console.error("World Cup Seller Champion action failed", error);
    }
  });
}

function setValue(id, value) {
  const node = document.getElementById(id);
  if (node) node.value = value;
}

function setHtml(id, html) {
  const node = document.getElementById(id);
  if (node) node.innerHTML = html;
}

window.addEventListener("wheel", markUserScroll, { passive: true });
window.addEventListener("touchstart", markUserScroll, { passive: true });
window.addEventListener("touchmove", markUserScroll, { passive: true });
window.addEventListener("scroll", markUserScroll, { passive: true });
window.addEventListener("input", markUserInput, { passive: true });
window.addEventListener("keydown", (event) => {
  const scrollKeys = new Set(["ArrowDown", "ArrowUp", "PageDown", "PageUp", "Home", "End", " "]);
  if (scrollKeys.has(event.key)) markUserScroll();
}, { passive: true });

on("scan", "click", async () => {
  if (!hasChromeApi) {
    statusText("Open as extension");
    return;
  }
  const { tab } = await getPopupContext();
  const activePerformanceId = activePerformanceIdFromUrl(tab?.url);
  activeTabPerformanceId = activePerformanceId;
  if (scanTargetMismatch(activePerformanceId)) {
    await openSelectedGameForScan();
    return;
  }
  const reminded = await remindCrowdSharingBeforeScan();
  if (reminded) statusText("Tip: share public listings to unlock better Insights");
  const testMode = document.getElementById("testMode")?.checked;
  setScanButtonBusy(true);
  const result = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_SCAN_ACTIVE_TAB",
    scanConfig: testMode
      ? { testMode: true, delayMs: 700, tileWidth: 10000, tileHeight: 5000, stepX: 10000, stepY: 5000, mapMax: 40000, maxConsecutiveBlocks: 2, reset: true, isExclusive: false }
      : { delayMs: 2000, tileWidth: 10000, tileHeight: 5000, stepX: 10000, stepY: 5000, mapMax: 40000, maxConsecutiveBlocks: 1, reset: true, isExclusive: false }
  });
  if (!result?.ok) setScanButtonBusy(false);
  statusText(result?.ok ? "Checking prices" : result?.error || "Could not check prices");
  setTimeout(load, 1000);
});

on("discover", "click", async () => {
  if (!hasChromeApi) {
    statusText("Open as extension");
    return;
  }
  const result = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_DISCOVER_ACTIVE_TAB",
    days: 7
  });
  statusText(result?.ok ? "Finding games" : result?.error || "Could not find games");
  setTimeout(load, 1000);
});

on("scanDiscovered", "click", async () => {
  if (!hasChromeApi) {
    statusText("Open as extension");
    return;
  }
  const testMode = document.getElementById("testMode")?.checked;
  const result = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_SCAN_DISCOVERED",
    scanConfig: testMode
      ? { testMode: true, delayMs: 700, matchDelayMs: 1500, tileWidth: 10000, tileHeight: 5000, stepX: 10000, stepY: 5000, mapMax: 40000, maxConsecutiveBlocks: 2, reset: true, isExclusive: false }
      : { delayMs: 2000, matchDelayMs: 3000, tileWidth: 10000, tileHeight: 5000, stepX: 10000, stepY: 5000, mapMax: 40000, maxConsecutiveBlocks: 1, reset: true, isExclusive: false }
  });
  statusText(result?.ok ? `Checking ${result.matches} games` : result?.error || "Could not check games");
  setTimeout(load, 1000);
});

on("seatSection", "change", () => {
  if (!currentGame) return;
  setValue("seatRow", "");
  setValue("sellerSeatNumber", "");
  setValidation("");
  renderSeatPicker(latestSeatRows(currentGame), stadiumSeatsForGame(currentGame), stadiumSectionsForGame(currentGame), hasFullStadiumCatalog(currentGame));
  refreshMySeatAnalysis();
});

on("seatSection", "input", () => {
  if (!currentGame) return;
  setValidation("");
  renderSeatPicker(latestSeatRows(currentGame), stadiumSeatsForGame(currentGame), stadiumSectionsForGame(currentGame), hasFullStadiumCatalog(currentGame));
  refreshMySeatAnalysis();
});

on("seatRow", "change", () => {
  if (!currentGame) return;
  setValue("sellerSeatNumber", "");
  setValidation("");
  renderSeatPicker(latestSeatRows(currentGame), stadiumSeatsForGame(currentGame), stadiumSectionsForGame(currentGame), hasFullStadiumCatalog(currentGame));
  refreshMySeatAnalysis();
});

on("seatRow", "input", () => {
  if (!currentGame) return;
  setValue("sellerSeatNumber", "");
  setValidation("");
  refreshMySeatAnalysis();
});

on("sellerSeatNumber", "input", (event) => {
  if (!currentGame) return;
  const seats = latestSeatRows(currentGame);
  const stadiumSeats = stadiumSeatsForGame(currentGame);
  const section = document.getElementById("seatSection")?.value || "";
  const row = document.getElementById("seatRow")?.value || "";
  const validation = validateTypedSeatNumber(stadiumSeats, seats, section, row, event.target.value, hasFullStadiumCatalog(currentGame));
  setValidation(validation.message || "", validation.ok ? "muted" : "error");
  refreshMySeatAnalysis();
});

on("sellerTicketCost", "input", () => {
  if (!currentGame) return;
  refreshMySeatAnalysis();
});

on("sellerTargetPrice", "input", () => {
  if (!currentGame) return;
  refreshMySeatAnalysis();
});

async function handleCrowdShareToggle(event) {
  const enabled = event.target.checked === true;
  const result = await setCrowdSharing(enabled);
  const scanning = isScanActive(currentGame?.scanProgress);
  statusText(result?.preview
    ? "Sharing on in preview"
    : result?.enabled
      ? scanning
        ? "Sharing on. This scan will upload when it finishes."
        : "Sharing on"
      : "Sharing off");
  await refreshCrowdSharingUi();
  await refreshCrowdPrompt();
}

on("crowdShare", "change", handleCrowdShareToggle);
on("topCrowdShare", "change", handleCrowdShareToggle);

on("shareCrowdNow", "click", async () => {
  if (!hasRuntimeApi) {
    statusText("Preview only");
    return;
  }
  const result = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_SHARE_CROWD_NOW",
    performanceId: currentGame?.performanceId || selectedPerformanceId || null
  });
  if (result?.ok) {
    statusText(result.skipped ? result.reason || "Already shared" : `Shared ${result.seatCount || 0} seats`);
  } else {
    statusText(result?.reason || result?.error || "Could not share");
  }
  await refreshCrowdSharingUi();
  await refreshCrowdPrompt();
});

async function acceptCrowdPrompt() {
  const result = await setCrowdSharing(true);
  await setCrowdPromptDismissed(false);
  if (isScanActive(currentGame?.scanProgress)) {
    statusText("Sharing on. This scan will upload when it finishes.");
    await refreshCrowdSharingUi();
    await refreshCrowdPrompt();
    return;
  }
  if (!hasRuntimeApi) {
    statusText("Sharing on in preview");
    await refreshCrowdSharingUi();
    await refreshCrowdPrompt();
    return;
  }
  const shared = await chrome.runtime.sendMessage({
    type: "FIFA_SELLER_SCOUT_SHARE_CROWD_NOW",
    performanceId: currentGame?.performanceId || selectedPerformanceId || null
  });
  if (shared?.ok) {
    statusText(shared.skipped ? shared.reason || "Sharing on" : `Shared ${shared.seatCount || 0} seats`);
  } else {
    statusText(shared?.reason || shared?.error || (result?.enabled ? "Sharing on" : "Could not share"));
  }
  await refreshCrowdSharingUi();
  await refreshCrowdPrompt();
}

async function dismissCrowdPrompt() {
  await setCrowdPromptDismissed(true);
  statusText("Not sharing");
  await refreshCrowdPrompt();
}

document.addEventListener("click", (event) => {
  if (event.target.closest("#crowdPromptAccept")) {
    event.preventDefault();
    acceptCrowdPrompt().catch((error) => {
      statusText(error?.message || "Could not share");
      console.error("World Cup Seller Champion action failed", error);
    });
  }
  if (event.target.closest("#crowdPromptDismiss")) {
    event.preventDefault();
    dismissCrowdPrompt().catch((error) => {
      statusText(error?.message || "Action failed");
      console.error("World Cup Seller Champion action failed", error);
    });
  }
});

function handlePackagePriceChange(event) {
  const input = event.target.closest("[data-package-key][data-package-field]");
  if (!input || !currentGame) return;
  const key = input.dataset.packageKey;
  const field = input.dataset.packageField;
  const selectionStart = supportsTextSelection(input) ? input.selectionStart : null;
  const selectionEnd = supportsTextSelection(input) ? input.selectionEnd : selectionStart;
  packagePrices[key] = {
    ...(packagePrices[key] || {}),
    [field]: input.value
  };
  saveSellerInventory();
  refreshMySeatAnalysis();
  const restored = document.querySelector(`[data-package-key="${CSS.escape(key)}"][data-package-field="${CSS.escape(field)}"]`);
  if (restored) {
    requestAnimationFrame(() => restoreInputCaret(restored, selectionStart, selectionEnd));
  }
}

document.addEventListener("input", handlePackagePriceChange, true);
document.addEventListener("change", handlePackagePriceChange, true);

on("mySeatAnalysis", "click", (event) => {
  const findButton = event.target.closest("[data-find-seat]");
  if (findButton && currentGame) {
    openSeatOnMap(findButton);
    return;
  }
  const pageButton = event.target.closest("[data-page-list]");
  if (!pageButton || !currentGame) return;
  const id = pageButton.dataset.pageList;
  listPages[id] = Math.max(0, Number(listPages[id] || 0) + Number(pageButton.dataset.pageDelta || 0));
  refreshMySeatAnalysis();
});

on("multi", "click", (event) => {
  const summary = event.target.closest("summary");
  if (summary) {
    const details = summary.closest("[data-index-section]");
    if (details) {
      setTimeout(() => {
        gameIndexOpenState[details.dataset.indexSection] = details.open;
      }, 0);
    }
    return;
  }
  const deleteButton = event.target.closest("[data-delete-game-key]");
  if (deleteButton) {
    const gameKey = deleteButton.dataset.deleteGameKey;
    if (hasChromeApi) {
      chrome.runtime.sendMessage({ type: "FIFA_SELLER_SCOUT_DELETE_GAME", gameKey }).then(() => {
        const performanceId = currentState?.games?.[gameKey]?.performanceId || gameKey.split(":")[1];
        deleteSellerInventory(performanceId);
        if (selectedGameKey === gameKey) selectedGameKey = null;
        load();
      });
    }
    return;
  }
  const selectButton = event.target.closest("[data-game-key]");
  if (!selectButton) return;
  selectedGameKey = selectButton.dataset.gameKey;
  load();
});

on("insights", "click", (event) => {
  const findButton = event.target.closest("[data-find-seat]");
  if (findButton && currentGame) {
    openSeatOnMap(findButton);
    return;
  }
  const pageButton = event.target.closest("[data-page-list]");
  if (pageButton && currentGame) {
    const id = pageButton.dataset.pageList;
    listPages[id] = Math.max(0, Number(listPages[id] || 0) + Number(pageButton.dataset.pageDelta || 0));
    setHtml("insights", renderInsights(currentGame, latestSeatRows(currentGame)));
    return;
  }
  const button = event.target.closest("[data-insight-category]");
  if (!button || !currentGame) return;
  selectedInsightCategory = button.dataset.insightCategory;
  listPages[`cleaned-${selectedInsightCategory}`] = 0;
  listPages[`live-deals-${selectedInsightCategory}`] = 0;
  setHtml("insights", renderInsights(currentGame, latestSeatRows(currentGame)));
});

on("movement", "click", (event) => {
  const pageButton = event.target.closest("[data-page-list]");
  if (!pageButton || !currentGame) return;
  const id = pageButton.dataset.pageList;
  listPages[id] = Math.max(0, Number(listPages[id] || 0) + Number(pageButton.dataset.pageDelta || 0));
  setHtml("movement", renderMarketChange(currentGame));
});

on("addSeats", "click", addSelectedSeatsFromPicker);
on("clearSeats", "click", clearSelectedSeats);

on("selectedSeats", "click", (event) => {
  const packageButton = event.target.closest("[data-remove-package]");
  if (packageButton) {
    const key = packageButton.dataset.removePackage;
    const packages = enteredOfferings(selectedMySeats.map((seat) => ({ ...seat, raw: mySeatToInput(seat) })));
    const target = packages.find((offering) => packagePriceKey(offering) === key);
    const removeKeys = new Set((target?.seats || []).map(selectionKey));
    selectedMySeats = selectedMySeats.filter((seat) => !removeKeys.has(selectionKey(seat)));
    delete packagePrices[key];
    syncSelectedInput();
    renderSelectedSeats();
    refreshMySeatAnalysis();
    saveSellerInventory();
    return;
  }
  const button = event.target.closest("[data-remove-seat]");
  if (!button) return;
  const index = Number(button.dataset.removeSeat);
  selectedMySeats.splice(index, 1);
  syncSelectedInput();
  renderSelectedSeats();
  refreshMySeatAnalysis();
  saveSellerInventory();
});

on("exportCsv", "click", () => {
  if (!currentGame) return;
  download(`fifa-current-inventory-${currentGame.performanceId}.csv`, "text/csv", toCsv(currentGame));
});

on("exportHistoryCsv", "click", () => {
  if (!currentGame) return;
  download(`fifa-history-${currentGame.performanceId}.csv`, "text/csv", toHistoryCsv(currentGame));
});

on("exportJson", "click", () => {
  if (!currentGame) return;
  download(`fifa-inventory-${currentGame.performanceId}.json`, "application/json", JSON.stringify(currentGame, null, 2));
});

on("exportAllCsv", "click", () => {
  if (!currentState) return;
  download("fifa-all-inventory-velocity.csv", "text/csv", toAllCsv(currentState));
});

load().finally(scheduleNextRefresh);
