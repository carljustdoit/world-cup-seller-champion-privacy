(function () {
  const INJECTED_VERSION = "0.4.112";
  if (window.__fifaSellerScoutLoaded && window.__fifaSellerScoutVersion === INJECTED_VERSION) return;
  const previousState = window.__fifaSellerScoutState || {};
  try {
    previousState.cleanup?.();
  } catch {
    // Old builds did not expose cleanup. A page refresh clears them.
  }
  const ACTIVE_TOKEN = `${INJECTED_VERSION}:${Date.now()}:${Math.random().toString(16).slice(2)}`;
  const sharedState = {
    token: ACTIVE_TOKEN,
    version: INJECTED_VERSION,
    originalFetch: previousState.originalFetch || window.fetch,
    originalOpen: previousState.originalOpen || XMLHttpRequest.prototype.open,
    originalSend: previousState.originalSend || XMLHttpRequest.prototype.send,
    originalSetHeader: previousState.originalSetHeader || XMLHttpRequest.prototype.setRequestHeader,
    cleanup: null
  };
  window.__fifaSellerScoutState = sharedState;
  window.__fifaSellerScoutLoaded = true;
  window.__fifaSellerScoutVersion = INJECTED_VERSION;

  const MATCH_PATTERNS = ["/seatmap/", "/performance/google-ecommerce-detail"];
  const FREE_SEATS_PATH = "/tnwr/v1/secure/seatmap/seats/free/ol";

  let capturedHeaders = null;
  let scanInProgress = false;
  const lastScanStartedByTarget = new Map();
  const blockedUntilByTarget = new Map();
  const SCAN_COOLDOWN_MS = 10 * 60 * 1000;
  const SCAN_BLOCK_COOLDOWN_MS = 30 * 60 * 1000;

  function isActive() {
    return window.__fifaSellerScoutState?.token === ACTIVE_TOKEN &&
      window.__fifaSellerScoutVersion === INJECTED_VERSION;
  }

  function shouldCapture(url) {
    return MATCH_PATTERNS.some((pattern) => String(url || "").includes(pattern));
  }

  function headersToObject(headers) {
    if (!headers) return {};
    if (headers instanceof Headers) return Object.fromEntries(headers.entries());
    if (Array.isArray(headers)) return Object.fromEntries(headers);
    return { ...headers };
  }

  function rememberHeaders(url, initHeaders) {
    if (!isActive()) return;
    if (!shouldCapture(url)) return;
    const headers = headersToObject(initHeaders);
    if (Object.keys(headers).length > 0) {
      capturedHeaders = { ...capturedHeaders, ...headers };
    }
  }

  function emit(type, payload) {
    if (!isActive()) return;
    window.postMessage({ type: "FIFA_SELLER_SCOUT", kind: type, injectedVersion: INJECTED_VERSION, ...payload }, "*");
  }

  function extractParam(url, name) {
    try {
      return new URL(url, window.location.origin).searchParams.get(name);
    } catch {
      const match = String(url || "").match(new RegExp(`[?&]${name}=([^&]+)`));
      return match ? decodeURIComponent(match[1]) : null;
    }
  }

  function scanParams(scanConfig = {}) {
    const tileWidth = scanConfig.tileWidth || scanConfig.tileSize || 10000;
    const tileHeight = scanConfig.tileHeight || 5000;
    const stepX = scanConfig.stepX || tileWidth;
    const stepY = scanConfig.stepY || tileHeight;
    const mapMax = scanConfig.mapMax || 40000;
    const delayMs = scanConfig.testMode
      ? Math.max(scanConfig.delayMs || 700, 600)
      : Math.max(scanConfig.delayMs || 2500, 2500);
    const maxConsecutiveBlocks = scanConfig.testMode
      ? Math.min(scanConfig.maxConsecutiveBlocks || 2, 2)
      : 1;
    return { tileWidth, tileHeight, stepX, stepY, mapMax, delayMs, maxConsecutiveBlocks };
  }

  function buildTiles({ tileWidth, tileHeight, stepX, stepY, mapMax }) {
    const tiles = [];
    for (let x = 0; x < mapMax; x += stepX) {
      for (let y = 0; y < mapMax; y += stepY) {
        tiles.push({ x, y, w: tileWidth, h: tileHeight });
      }
    }
    return tiles;
  }

  function requestHeaders() {
    return {
      Accept: "application/json",
      "X-Secutix-Host": window.location.hostname,
      "X-Secutix-SecretKey": "DUMMY",
      ...(capturedHeaders || {})
    };
  }

  function aggregateSeatKey(feature, fallbackIndex) {
    const p = feature?.properties || {};
    return [
      p.id,
      p.seatId,
      p.resaleMovementId,
      p.movementId,
      p.block?.id,
      p.block?.name?.en || p.block?.name || p.block,
      p.row,
      p.number,
      p.seatCategoryId,
      p.amount ?? p.seatBasedPriceAmount,
      fallbackIndex
    ].filter((value) => value != null && value !== "").map((value) => String(value).replace(/\s+/g, "_")).join(":");
  }

  function compactFeature(feature) {
    if (!feature || typeof feature !== "object") return feature;
    return {
      id: feature.id ?? feature.properties?.id ?? null,
      geometry: feature.geometry?.coordinates ? {
        coordinates: feature.geometry.coordinates,
        rotation: feature.geometry.rotation,
        type: feature.geometry.type
      } : undefined,
      properties: feature.properties || feature
    };
  }

  function localizedName(value) {
    if (!value) return "";
    if (typeof value === "string" || typeof value === "number") return String(value);
    return value.name?.en || value.name || value.label?.en || value.label || value.en || "";
  }

  function firstCoordinate(value) {
    if (!Array.isArray(value)) return null;
    if (value.length >= 2 && Number.isFinite(Number(value[0])) && Number.isFinite(Number(value[1]))) {
      return [Number(value[0]), Number(value[1])];
    }
    for (const child of value) {
      const point = firstCoordinate(child);
      if (point) return point;
    }
    return null;
  }

  function featureToSeatRow(feature) {
    const p = feature?.properties || feature || {};
    const block = p.block || p.section || {};
    const area = p.area || p.zone || {};
    const rawPrice = p.amount ?? p.seatBasedPriceAmount ?? p.priceAmount ?? p.listPriceAmount ?? p.price?.amount ?? p.resalePrice?.amount ?? p.seatPrice?.amount ?? p.tariff?.amount ?? null;
    const fifaBasePrice = rawPrice == null ? null : Number(rawPrice) / 1000;
    const sellerListPrice = fifaBasePrice == null ? null : fifaBasePrice * 1.15;
    const mapPoint = firstCoordinate(feature?.geometry?.coordinates);
    return {
      sourceFeatureId: p.id ?? p.seatId ?? feature?.id ?? null,
      mapGeometryType: feature?.geometry?.type || "",
      mapPointX: mapPoint?.[0] ?? null,
      mapPointY: mapPoint?.[1] ?? null,
      blockId: block?.id ?? p.blockId ?? p.sectionId ?? null,
      blockName: localizedName(block) || p.blockName || p.sectionName || "",
      row: p.row ?? p.rowName ?? p.seat?.row ?? "",
      seatNumber: p.number ?? p.seatNumber ?? p.seat?.number ?? "",
      categoryId: p.seatCategoryId ?? p.categoryId ?? p.seatCategory?.id ?? p.category?.id ?? "",
      categoryName: localizedName(p.seatCategory) || localizedName(p.category) || "",
      areaId: area?.id ?? p.areaId ?? p.zoneId ?? null,
      areaName: localizedName(area),
      sellerListPrice,
      buyerAllInPrice: sellerListPrice == null ? null : sellerListPrice * 1.15,
      estimatedSellerNet: sellerListPrice == null ? null : sellerListPrice * 0.85,
      resaleMovementId: p.resaleMovementId ?? null,
      movementId: p.movementId ?? null,
      contingentId: p.contingentId ?? null,
      exclusive: p.exclusive !== false
    };
  }

  function safeFeatureToSeatRow(feature) {
    try {
      return featureToSeatRow(feature);
    } catch (error) {
      const p = feature?.properties || feature || {};
      return {
        sourceFeatureId: p.id ?? p.seatId ?? feature?.id ?? null,
        blockId: p.blockId ?? p.sectionId ?? null,
        blockName: localizedName(p.block) || p.blockName || p.sectionName || "",
        row: p.row ?? p.rowName ?? p.seat?.row ?? "",
        seatNumber: p.number ?? p.seatNumber ?? p.seat?.number ?? "",
        categoryId: p.seatCategoryId ?? p.categoryId ?? "",
        categoryName: localizedName(p.seatCategory) || localizedName(p.category) || "",
        resaleMovementId: p.resaleMovementId ?? null,
        movementId: p.movementId ?? null,
        parseError: String(error?.message || error || "row parse failed").slice(0, 160)
      };
    }
  }

  async function fetchJson(url, headers) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    const startedAt = Date.now();
    const response = await originalFetch(url, {
      credentials: "include",
      headers,
      signal: controller.signal
    });
    const text = await response.text();
    clearTimeout(timeoutId);
    let body = null;
    try {
      body = JSON.parse(text);
    } catch {
      // Keep body null for non-JSON errors.
    }
    return { response, body, text, elapsedMs: Date.now() - startedAt };
  }

  function emitSeatBatchChunks({ url, productId, performanceId, match, scanId, multiScanId, bbox, tileIndex, featureCount, seatRows, progress = null }) {
    const chunkSize = 20;
    for (let start = 0; start < seatRows.length; start += chunkSize) {
      const chunk = seatRows.slice(start, start + chunkSize);
      const payload = {
        url,
        productId,
        performanceId,
        match,
        scanId,
        multiScanId,
        bbox,
        tileIndex,
        chunkIndex: Math.floor(start / chunkSize),
        chunkCount: Math.ceil(seatRows.length / chunkSize),
        featureCount,
        seatsJson: JSON.stringify(chunk)
      };
      emit("seat-batch", payload);
      emit("scan-progress", {
        status: progress?.status || "scanning",
        completed: progress?.completed ?? null,
        total: progress?.total ?? null,
        found: progress?.found ?? null,
        tileWidth: progress?.tileWidth ?? null,
        tileHeight: progress?.tileHeight ?? null,
        stepX: progress?.stepX ?? null,
        stepY: progress?.stepY ?? null,
        mapMax: progress?.mapMax ?? null,
        seatBatch: true,
        ...payload
      });
    }
  }

  async function scanPerformance({ productId, performanceId, match = null, scanConfig = {}, scanId, multiScanId = null, matchIndex = null, matchTotal = null }) {
    const params = scanParams(scanConfig);
    const tiles = buildTiles(params);
    const headers = requestHeaders();
    let consecutiveBlocks = 0;
    let found = 0;
    let completed = 0;
    const diagnostics = {
      attemptedTiles: 0,
      successfulTiles: 0,
      blockedTiles: 0,
      timedOutTiles: 0,
      errorTiles: 0
    };
    const aggregateSeats = new Map();
    const aggregateSeatRows = new Map();
    const aggregateTileStats = [];

    const scanDiagnostics = () => ({ ...diagnostics });

    function emitScanResult(status, details = {}) {
      const finalSeatRows = Array.from(aggregateSeatRows.values());
      if (finalSeatRows.length) {
        emitSeatBatchChunks({
          url: window.location.href,
          productId,
          performanceId,
          match,
          scanId,
          multiScanId,
          bbox: "final",
          tileIndex: "final",
          featureCount: finalSeatRows.length,
          seatRows: finalSeatRows,
          progress: {
            status,
            completed,
            total: tiles.length,
            found,
            final: true,
            ...scanDiagnostics(),
            ...details,
            ...params
          }
        });
      }
      emit("scan-result", {
        status,
        scanId,
        multiScanId,
        productId,
        performanceId,
        match,
        completed,
        total: tiles.length,
        found,
        rawFeaturesSeen: found,
        tileStats: aggregateTileStats,
        seatsJson: JSON.stringify(finalSeatRows),
        ...scanDiagnostics(),
        ...details
      });
    }

    emit("scan-progress", {
      status: "started",
      completed: 0,
      total: tiles.length,
      productId,
      performanceId,
      scanId,
      multiScanId,
      matchIndex,
      matchTotal,
      match,
      ...scanDiagnostics(),
      ...params,
      reset: scanConfig.reset !== false
    });

    const availabilityUrl = `/tnwr/v1/secure/seatmap/availability?perfId=${encodeURIComponent(performanceId)}&productId=${encodeURIComponent(productId)}&isSeasonTicketMode=false&advantageId=&withPriceRange=true&ppid=&reservationIdx=&crossSellId=&baseOperationIdsString=`;
    try {
      const { response, body, elapsedMs } = await fetchJson(availabilityUrl, headers);
      if (response.ok && body) {
        emit("api-response", {
          url: window.location.origin + availabilityUrl,
          body,
          meta: { scanId, multiScanId, productId, performanceId, match, elapsedMs }
        });
      }
    } catch (error) {
      emit("scan-progress", {
        status: "api-error",
        stage: "availability",
        message: error.message,
        completed,
        total: tiles.length,
        found,
        productId,
        performanceId,
        scanId,
        multiScanId
      });
    }

    const matchUrl = `/tnwr/v1/secure/seatmap/performance/google-ecommerce-detail?productId=${encodeURIComponent(productId)}&performanceId=${encodeURIComponent(performanceId)}`;
    try {
      const { response, body, elapsedMs } = await fetchJson(matchUrl, headers);
      if (response.ok && body) {
        emit("api-response", {
          url: window.location.origin + matchUrl,
          body,
          meta: { scanId, multiScanId, productId, performanceId, match, elapsedMs }
        });
      }
    } catch (error) {
      emit("scan-progress", {
        status: "api-error",
        stage: "match",
        message: error.message,
        completed,
        total: tiles.length,
        found,
        productId,
        performanceId,
        scanId,
        multiScanId
      });
    }

    for (let i = 0; i < tiles.length; i++) {
      const tile = tiles[i];
      completed = i + 1;
      const bbox = `${tile.x},${tile.y},${tile.w},${tile.h}`;
      const isExclusive = scanConfig.isExclusive === true ? "true" : "false";
      const url = `${FREE_SEATS_PATH}?productId=${encodeURIComponent(productId)}&performanceId=${encodeURIComponent(performanceId)}&isSeasonTicketMode=false&advantageId=&isModifyAllSeatsMode=false&ppid=&reservationIdx=&crossSellId=&baseOperationIdsString=&bbox=${bbox}&isExclusive=${isExclusive}`;

      try {
        diagnostics.attemptedTiles++;
        const { response, body, elapsedMs } = await fetchJson(url, headers);
        if (response.ok) {
          consecutiveBlocks = 0;
          diagnostics.successfulTiles++;
          const count = Array.isArray(body?.features) ? body.features.length : 0;
          found += count;
          aggregateTileStats.push({
            scanId,
            bbox,
            tileIndex: i,
            featureCount: count,
            capturedAt: new Date().toISOString()
          });
          (body?.features || []).forEach((feature, featureIndex) => {
            const key = aggregateSeatKey(feature, `${i}-${featureIndex}`);
            if (key) aggregateSeats.set(key, feature);
          });
          if (count > 0) {
            const seatRows = (body.features || []).map(safeFeatureToSeatRow);
            seatRows.forEach((row, rowIndex) => {
              const rowKey = aggregateSeatKey({ properties: row }, `${i}-${rowIndex}`);
              if (rowKey) aggregateSeatRows.set(rowKey, row);
            });
            emitSeatBatchChunks({
              url: window.location.origin + url,
              productId,
              performanceId,
              match,
              scanId,
              multiScanId,
              bbox,
              tileIndex: i,
              featureCount: count,
              seatRows,
              progress: {
                status: "scanning",
                completed,
                total: tiles.length,
                found,
                ...scanDiagnostics(),
                ...params
              }
            });
          }
        } else if (response.status === 403 || response.status === 429) {
          consecutiveBlocks++;
          diagnostics.blockedTiles++;
          emit("scan-progress", {
            status: "blocked",
            httpStatus: response.status,
            retryAfterMs: SCAN_BLOCK_COOLDOWN_MS,
            completed,
            total: tiles.length,
            found,
            productId,
            performanceId,
            scanId,
            multiScanId,
            matchIndex,
            matchTotal,
            bbox,
            ...scanDiagnostics()
          });
          if (consecutiveBlocks >= params.maxConsecutiveBlocks) {
            const details = { httpStatus: response.status, bbox, stopReason: "consecutive-blocks" };
            emitScanResult("blocked", details);
            return { status: "blocked", completed, total: tiles.length, found, ...details };
          }
        }
      } catch (error) {
        if (error?.name === "AbortError") {
          diagnostics.timedOutTiles++;
        } else {
          diagnostics.errorTiles++;
        }
        emit("scan-progress", {
          status: "error",
          message: error.message,
          completed,
          total: tiles.length,
          found,
          productId,
          performanceId,
          scanId,
          multiScanId,
          matchIndex,
          matchTotal,
          bbox,
          stopReason: error?.name === "AbortError" ? "timeout" : "request-error",
          ...scanDiagnostics()
        });
      }

      emit("scan-progress", {
        status: "scanning",
        completed,
        total: tiles.length,
        found,
        productId,
        performanceId,
        scanId,
        multiScanId,
        matchIndex,
        matchTotal,
        ...scanDiagnostics()
      });
      await new Promise((resolve) => setTimeout(resolve, params.delayMs));
    }

    emitScanResult("done");
    emit("scan-progress", {
      status: "done",
      completed,
      total: tiles.length,
      found,
      productId,
      performanceId,
      scanId,
      multiScanId,
      matchIndex,
      matchTotal,
      ...scanDiagnostics()
    });
    return { status: "done", completed, total: tiles.length, found };
  }

  const originalFetch = sharedState.originalFetch;
  window.fetch = async function (...args) {
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url || "";
    const init = args[1] || {};
    rememberHeaders(url, init.headers);

    const response = await originalFetch.apply(this, args);
    if (isActive() && shouldCapture(url)) {
      try {
        const clone = response.clone();
        const body = await clone.json();
        emit("api-response", { url: String(url), body });
      } catch {
        // Ignore non-JSON responses.
      }
    }
    return response;
  };

  const originalOpen = sharedState.originalOpen;
  const originalSend = sharedState.originalSend;
  const originalSetHeader = sharedState.originalSetHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__fssUrl = url;
    this.__fssHeaders = {};
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (isActive() && this.__fssHeaders) this.__fssHeaders[name] = value;
    return originalSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (isActive() && shouldCapture(this.__fssUrl)) {
      rememberHeaders(this.__fssUrl, this.__fssHeaders);
      this.addEventListener("load", function () {
        if (!isActive()) return;
        try {
          emit("api-response", {
            url: String(this.__fssUrl),
            body: JSON.parse(this.responseText)
          });
        } catch {
          // Ignore non-JSON responses.
        }
      });
    }
    return originalSend.apply(this, args);
  };

  const handleScoutMessage = async (event) => {
    if (!isActive()) return;
    if (event.source !== window) return;
    if (!["FIFA_SELLER_SCOUT_SCAN_ALL", "FIFA_SELLER_SCOUT_SCAN_MATCHES"].includes(event.data?.type)) return;
    if (scanInProgress) {
      emit("scan-progress", { status: "already-running" });
      return;
    }

    const { productId, performanceId, scanConfig = {} } = event.data;
    if (!productId || (event.data.type === "FIFA_SELLER_SCOUT_SCAN_ALL" && !performanceId)) {
      emit("scan-progress", { status: "missing-ids", productId, performanceId });
      return;
    }

    const now = Date.now();
    const cooldownKey = event.data.type === "FIFA_SELLER_SCOUT_SCAN_MATCHES"
      ? `multi:${productId}`
      : `performance:${performanceId}`;
    const lastScanStartedAt = lastScanStartedByTarget.get(cooldownKey) || 0;
    const blockedUntil = blockedUntilByTarget.get(cooldownKey) || 0;
    if (now < blockedUntil) {
      emit("scan-progress", {
        status: "cooldown",
        productId,
        performanceId,
        retryAfterMs: blockedUntil - now,
        reason: "fifa-rate-limit"
      });
      return;
    }
    if (!scanConfig.testMode && now - lastScanStartedAt < SCAN_COOLDOWN_MS) {
      emit("scan-progress", {
        status: "cooldown",
        productId,
        performanceId,
        retryAfterMs: SCAN_COOLDOWN_MS - (now - lastScanStartedAt)
      });
      return;
    }

    scanInProgress = true;
    lastScanStartedByTarget.set(cooldownKey, now);

    try {
      if (event.data.type === "FIFA_SELLER_SCOUT_SCAN_MATCHES") {
        const matches = Array.isArray(event.data.matches) ? event.data.matches : [];
        const multiScanId = `multi-${Date.now()}`;
        emit("multi-scan-progress", {
          status: "started",
          multiScanId,
          completedMatches: 0,
          totalMatches: matches.length
        });
        let completedMatches = 0;
        let finalStatus = "done";
        for (let index = 0; index < matches.length; index++) {
          const match = matches[index];
          const targetPerformanceId = match.performanceId;
          if (!targetPerformanceId) continue;
          const scanId = `${targetPerformanceId}-${Date.now()}`;
          emit("multi-scan-progress", {
            status: "match-started",
            multiScanId,
            completedMatches: index,
            totalMatches: matches.length,
            match
          });
          const result = await scanPerformance({
            productId,
            performanceId: targetPerformanceId,
            match,
            scanConfig,
            scanId,
            multiScanId,
            matchIndex: index + 1,
            matchTotal: matches.length
          });
          completedMatches = index + 1;
          emit("multi-scan-progress", {
            status: result.status === "blocked" ? "blocked" : "match-done",
            multiScanId,
            completedMatches,
            totalMatches: matches.length,
            match,
            result
          });
          if (result.status === "blocked") {
            finalStatus = "blocked";
            blockedUntilByTarget.set(cooldownKey, Date.now() + SCAN_BLOCK_COOLDOWN_MS);
            break;
          }
          await new Promise((resolve) => setTimeout(resolve, scanConfig.matchDelayMs || 1200));
        }
        emit("multi-scan-progress", {
          status: finalStatus,
          multiScanId,
          completedMatches,
          totalMatches: matches.length
        });
      } else {
        const scanId = `${performanceId}-${Date.now()}`;
        const result = await scanPerformance({ productId, performanceId, scanConfig, scanId });
        if (result.status === "blocked") {
          blockedUntilByTarget.set(cooldownKey, Date.now() + SCAN_BLOCK_COOLDOWN_MS);
        }
      }
    } catch (error) {
      emit("scan-progress", {
        status: "error",
        productId,
        performanceId,
        message: String(error?.message || error || "scan failed")
      });
    } finally {
      scanInProgress = false;
    }
  };

  window.addEventListener("message", handleScoutMessage);
  sharedState.cleanup = () => {
    window.removeEventListener("message", handleScoutMessage);
    if (window.fetch === sharedState.fetchWrapper) window.fetch = sharedState.originalFetch;
    if (XMLHttpRequest.prototype.open === sharedState.openWrapper) XMLHttpRequest.prototype.open = sharedState.originalOpen;
    if (XMLHttpRequest.prototype.send === sharedState.sendWrapper) XMLHttpRequest.prototype.send = sharedState.originalSend;
    if (XMLHttpRequest.prototype.setRequestHeader === sharedState.setHeaderWrapper) {
      XMLHttpRequest.prototype.setRequestHeader = sharedState.originalSetHeader;
    }
  };
  sharedState.fetchWrapper = window.fetch;
  sharedState.openWrapper = XMLHttpRequest.prototype.open;
  sharedState.sendWrapper = XMLHttpRequest.prototype.send;
  sharedState.setHeaderWrapper = XMLHttpRequest.prototype.setRequestHeader;

  emit("ready", { href: window.location.href });
})();
