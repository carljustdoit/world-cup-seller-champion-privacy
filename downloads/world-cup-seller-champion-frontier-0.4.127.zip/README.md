# World Cup Seller Champion Extension Prototype

This is a Chrome extension prototype for capturing FIFA resale seat-map inventory.

## What It Captures

From FIFA seat-map JSON responses:

- Performance ID and product ID.
- Category IDs and names.
- FIFA list price and estimated buyer checkout price.
- Available seat IDs.
- Area, block, row, and seat number where exposed.
- Seat category.
- FIFA list price from FIFA seat inventory.
- Estimated buyer checkout price after buyer fee.
- Estimated seller net after FIFA seller fee.
- Snapshot-to-snapshot velocity: newly listed, disappeared, repriced, and still listed seats.
- Seat type: resale, face value, or unknown.
- Resale movement IDs and related ticket metadata where exposed.
- A separate `stadiumSeats` catalog when FIFA exposes full-map block/row/seat records. If the full catalog is not exposed, the seller seat picker falls back to market-observed sections and allows manual unlisted seats.
- Optional anonymous market scan sharing when the user turns it on.
- A 12-character, 24-hour seller insights pass after a successful shared scan.

## Fee Math

The `seats/free/ol` endpoint exposes `properties.amount` in thousandths of USD. In observed resale pages, the extension treats the displayed FIFA list price as `amount * 1.15`.

The prototype assumes:

```text
fifa_list_price = amount * 1.15
buyer_checkout_price = fifa_list_price * 1.15
seller_net = fifa_list_price * 0.85
```

## Install

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click `Load unpacked`.
4. Select this folder:

```text
/Users/carl.liu/Documents/Codex/2026-06-13/so-i-have-lots-of-world/outputs/fifa-seller-scout-extension
```

## Use

1. Open a FIFA resale seat-map page.
2. Wait for the map and price ranges to load.
3. Click the extension icon.
4. For development only, check `Test mode`.
5. Click into at least one colored section on the seat map so FIFA loads the detailed seat layer.
6. Click `Deep scan`.
7. Wait for scan progress to finish.
8. Click `Export CSV` or `Export JSON`.

If buttons appear to do nothing after updating the extension, reload the unpacked extension in `chrome://extensions` once. Version `0.3.1` also force-injects the page scripts before scans, so the FIFA page itself should not need a perfect reload cycle.

## Next-7-Day Scan

Temporarily hidden in the popup while the seller listing workflow is being simplified.

1. Open the FIFA match-selection page for the World Cup product.
2. Click `Discover 7d` in the extension popup. This stores the visible performances from today through seven days out.
3. Open any authenticated FIFA seat-map page.
4. Click `Scan 7d`.
5. Leave the tab open until progress finishes or stops.
6. Click `Export all` for a combined inventory and velocity CSV.

## Notes

- This uses the same broad approach as a normal Chrome extension would: it observes the FIFA page's own seat-map JSON responses.
- Seat-level inventory appears only after the map dives into a section. Browsing manually is useful because the extension captures the page's own `seats/free/ol` responses as you inspect sections.
- The deep scan mimics FIFA's section viewport request shape. The observed seat-level request used:

```text
/tnwr/v1/secure/seatmap/seats/free/ol?...&bbox=15000,5000,10000,5000&isExclusive=false
```

- Each bbox is sent as `x,y,width,height`, not `minX,minY,maxX,maxY`.
- The default single-match deep scan uses non-overlapping `10000x5000` viewports over a 40,000px map. Duplicate seats are merged by seat id.
- The next-7-day scan uses the same non-overlapping `10000x5000` viewports for each discovered match to reduce request volume and avoid suspicious half-step bboxes.
- Multi-match scanning can run from any authenticated seat-map page. FIFA blocks inventory requests from the match-selection page, so discover on match selection first, then scan from a seat-map page.
- Requests are user-triggered only.
- The scan waits at least 2.5 seconds between tile requests.
- The page enforces a 10-minute cooldown between scans.
- The scan stops immediately on `403` or `429` responses and waits longer before allowing another check on the same page.
- Test mode uses a faster delay for debugging, but it does not override a FIFA rate-limit block. Do not use it for continuous polling.
- Anonymous market sharing is off by default. When turned on, the extension sends visible market listings from completed scans to `https://wc26champion.com/api/market-scan`.
- Shared scans do not include the user's name, email, FIFA account, payment details, IP address, purchase cost, target price, or seats typed as their own.
- A successful shared scan may show a 12-character, 24-hour Seller Insights pass. The portal uses aggregated market data only.
- The popup shows raw features seen versus unique seats stored. If raw features are high but unique seats are low, the issue is seat-key normalization. If both are low, the issue is scan coverage, throttling, or the endpoint returning capped results.
- `List Your Seats` does not require your seat to already be listed. The typed seat is analyzed against live resale comps; validation uses full-stadium records when captured and otherwise marks the input as market-only coverage.
- Seller analysis shows four separate values: FIFA list price, buyer final checkout price, seller proceeds after FIFA seller fee, and profit after the seller's original ticket cost.
- If FIFA returns `403` or `429`, stop scanning and wait. Do not try to bypass CAPTCHA, queue, rate limits, account controls, or access restrictions.
- Do not use this to bypass CAPTCHA, queue, login, or other access controls.
