(function () {
  const INJECTED_VERSION = "0.4.157";
  if (window.__fifaSellerScoutLoaded && window.__fifaSellerScoutVersion === INJECTED_VERSION) return;
  const previousState = window.__fifaSellerScoutState || {};
  try {
    previousState.cleanup?.();
  } catch {
    // Old builds did not expose cleanup. A page refresh clears them.
  }
  const ACTIVE_TOKEN = `${INJECTED_VERSION}:${Date.now()}:${Math.random().toString(16).slice(2)}`;
  const sharedState = {
    token: ACTIVE_TOKEN,
    version: INJECTED_VERSION,
    originalFetch: previousState.originalFetch || window.fetch,
    originalOpen: previousState.originalOpen || XMLHttpRequest.prototype.open,
    originalSend: previousState.originalSend || XMLHttpRequest.prototype.send,
    originalSetHeader: previousState.originalSetHeader || XMLHttpRequest.prototype.setRequestHeader,
    cleanup: null
  };
  window.__fifaSellerScoutState = sharedState;
  window.__fifaSellerScoutLoaded = true;
  window.__fifaSellerScoutVersion = INJECTED_VERSION;

  const MATCH_PATTERNS = ["/seatmap/", "/performance/google-ecommerce-detail"];
  const FREE_SEATS_PATH = "/tnwr/v1/secure/seatmap/seats/free/ol";

  let capturedHeaders = null;
  let capturedFreeSeatHeaders = null;
  let capturedFreeSeatUrl = null;
  let scanInProgress = false;
  const lastScanStartedByTarget = new Map();
  const blockedUntilByTarget = new Map();
  const SCAN_COOLDOWN_MS = 60 * 1000;
  const SCAN_BLOCK_COOLDOWN_MS = 5 * 60 * 1000;
  const MAX_SCAN_TILES = 256;

  function isActive() {
    return window.__fifaSellerScoutState?.token === ACTIVE_TOKEN &&
      window.__fifaSellerScoutVersion === INJECTED_VERSION;
  }

  function shouldCapture(url) {
    return MATCH_PATTERNS.some((pattern) => String(url || "").includes(pattern));
  }

  function headersToObject(headers) {
    if (!headers) return {};
    if (headers instanceof Headers) return Object.fromEntries(headers.entries());
    if (Array.isArray(headers)) return Object.fromEntries(headers);
    return { ...headers };
  }

  function rememberHeaders(url, initHeaders) {
    if (!isActive()) return;
    if (!shouldCapture(url)) return;
    const headers = headersToObject(initHeaders);
    if (Object.keys(headers).length > 0) {
      capturedHeaders = { ...capturedHeaders, ...headers };
      if (String(url || "").includes(FREE_SEATS_PATH)) {
        capturedFreeSeatHeaders = { ...capturedFreeSeatHeaders, ...headers };
        capturedFreeSeatUrl = String(url || "");
      }
    }
  }

  function emit(type, payload) {
    if (!isActive()) return;
    window.postMessage({ type: "FIFA_SELLER_SCOUT", kind: type, injectedVersion: INJECTED_VERSION, ...payload }, "*");
  }

  function extractParam(url, name) {
    try {
      return new URL(url, window.location.origin).searchParams.get(name);
    } catch {
      const match = String(url || "").match(new RegExp(`[?&]${name}=([^&]+)`));
      return match ? decodeURIComponent(match[1]) : null;
    }
  }

  function clampNumber(value, fallback, min, max) {
    const next = Number(value);
    if (!Number.isFinite(next)) return fallback;
    return Math.min(max, Math.max(min, Math.floor(next)));
  }

  function scanParams(scanConfig = {}) {
    const tileWidth = clampNumber(scanConfig.tileWidth || scanConfig.tileSize, 10000, 1000, 20000);
    const tileHeight = clampNumber(scanConfig.tileHeight, 5000, 1000, 20000);
    const stepX = clampNumber(scanConfig.stepX, tileWidth, 1000, 20000);
    const stepY = clampNumber(scanConfig.stepY, tileHeight, 1000, 20000);
    const mapMax = clampNumber(scanConfig.mapMax, 40000, 1000, 60000);
    const delayMs = scanConfig.testMode
      ? Math.max(scanConfig.delayMs || 700, 600)
      : Math.max(scanConfig.delayMs || 2000, 1800);
    const maxConsecutiveBlocks = scanConfig.testMode
      ? Math.min(scanConfig.maxConsecutiveBlocks || 3, 3)
      : Math.min(scanConfig.maxConsecutiveBlocks || 3, 3);
    return { tileWidth, tileHeight, stepX, stepY, mapMax, delayMs, maxConsecutiveBlocks };
  }

  function buildTiles({ tileWidth, tileHeight, stepX, stepY, mapMax }) {
    const tiles = [];
    for (let x = 0; x < mapMax; x += stepX) {
      for (let y = 0; y < mapMax; y += stepY) {
        tiles.push({ x, y, w: tileWidth, h: tileHeight });
        if (tiles.length >= MAX_SCAN_TILES) break;
      }
      if (tiles.length >= MAX_SCAN_TILES) break;
    }
    return tiles;
  }

  function requestHeaders() {
    return {
      Accept: "application/json",
      ...(capturedHeaders || {}),
      ...(capturedFreeSeatHeaders || {})
    };
  }

  function headerValue(headers, name) {
    const target = String(name || "").toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() === target && value != null && value !== "") return value;
    }
    return null;
  }

  function headerDiagnostics() {
    const names = Object.keys(capturedHeaders || {});
    const freeNames = Object.keys(capturedFreeSeatHeaders || {});
    return {
      capturedHeaderNames: names.map((name) => String(name).toLowerCase()).sort(),
      capturedFreeSeatHeaderNames: freeNames.map((name) => String(name).toLowerCase()).sort(),
      hasGenericSecret: Boolean(headerValue(capturedHeaders, "X-Secutix-SecretKey")),
      hasFreeSeatSecret: Boolean(headerValue(capturedFreeSeatHeaders, "X-Secutix-SecretKey")),
      hasFreeSeatUrlTemplate: Boolean(capturedFreeSeatUrl)
    };
  }

  function freeSeatsUrlFromTemplate({ productId, performanceId, bbox, isExclusive }) {
    if (capturedFreeSeatUrl) {
      try {
        const parsed = new URL(capturedFreeSeatUrl, window.location.origin);
        parsed.searchParams.set("productId", String(productId));
        parsed.searchParams.set("performanceId", String(performanceId));
        parsed.searchParams.set("bbox", String(bbox));
        if (isExclusive != null) parsed.searchParams.set("isExclusive", String(isExclusive));
        return parsed.pathname + parsed.search;
      } catch {
        // Fall through to the known URL shape below.
      }
    }
    const exclusiveValue = isExclusive == null ? "true" : String(isExclusive);
    return `${FREE_SEATS_PATH}?productId=${encodeURIComponent(productId)}&performanceId=${encodeURIComponent(performanceId)}&isSeasonTicketMode=false&advantageId=&isModifyAllSeatsMode=false&ppid=&reservationIdx=&crossSellId=&baseOperationIdsString=&bbox=${bbox}&isExclusive=${exclusiveValue}`;
  }

  function aggregateSeatKey(feature, fallbackIndex) {
    const p = feature?.properties || {};
    return [
      p.id,
      p.seatId,
      p.resaleMovementId,
      p.movementId,
      p.block?.id,
      p.block?.name?.en || p.block?.name || p.block,
      p.row,
      p.number,
      p.seatCategoryId,
      p.amount ?? p.seatBasedPriceAmount,
      fallbackIndex
    ].filter((value) => value != null && value !== "").map((value) => String(value).replace(/\s+/g, "_")).join(":");
  }

  function compactFeature(feature) {
    if (!feature || typeof feature !== "object") return feature;
    return {
      id: feature.id ?? feature.properties?.id ?? null,
      geometry: feature.geometry?.coordinates ? {
        coordinates: feature.geometry.coordinates,
        rotation: feature.geometry.rotation,
        type: feature.geometry.type
      } : undefined,
      properties: feature.properties || feature
    };
  }

  function safeCompactFeature(feature) {
    try {
      return compactFeature(feature);
    } catch (error) {
      return {
        id: feature?.id ?? feature?.properties?.id ?? null,
        properties: feature?.properties || {},
        parseError: String(error?.message || error || "feature compact failed").slice(0, 160)
      };
    }
  }

  function localizedName(value) {
    if (!value) return "";
    if (typeof value === "string" || typeof value === "number") return String(value);
    return value.name?.en || value.name || value.label?.en || value.label || value.en || "";
  }

  function firstCoordinate(value) {
    if (!Array.isArray(value)) return null;
    if (value.length >= 2 && Number.isFinite(Number(value[0])) && Number.isFinite(Number(value[1]))) {
      return [Number(value[0]), Number(value[1])];
    }
    for (const child of value) {
      const point = firstCoordinate(child);
      if (point) return point;
    }
    return null;
  }

  function siteFromLocation() {
    const host = String(window.location.hostname || "");
    if (host.includes("-shop-")) return "fifa_primary";
    if (host.includes("-resale-")) return "fifa_resale";
    return "fifa_resale";
  }

  function priceSetFromRawAmount(rawPrice) {
    const fifaBasePrice = rawPrice == null || Number.isNaN(Number(rawPrice)) ? null : Number(rawPrice) / 1000;
    if (fifaBasePrice == null) return { sellerListPrice: null, buyerAllInPrice: null, estimatedSellerNet: null };
    if (siteFromLocation() === "fifa_primary") {
      return {
        sellerListPrice: fifaBasePrice,
        buyerAllInPrice: fifaBasePrice,
        estimatedSellerNet: null
      };
    }
    const sellerListPrice = fifaBasePrice * 1.15;
    return {
      sellerListPrice,
      buyerAllInPrice: sellerListPrice * 1.15,
      estimatedSellerNet: sellerListPrice * 0.85
    };
  }

  function featureToSeatRow(feature) {
    const p = feature?.properties || feature || {};
    const block = p.block || p.section || {};
    const area = p.area || p.zone || {};
    const rawPrice = p.amount ?? p.seatBasedPriceAmount ?? p.priceAmount ?? p.listPriceAmount ?? p.price?.amount ?? p.resalePrice?.amount ?? p.seatPrice?.amount ?? p.tariff?.amount ?? null;
    const prices = priceSetFromRawAmount(rawPrice);
    const mapPoint = firstCoordinate(feature?.geometry?.coordinates);
    return {
      sourceFeatureId: p.id ?? p.seatId ?? feature?.id ?? null,
      mapGeometryType: feature?.geometry?.type || "",
      mapPointX: mapPoint?.[0] ?? null,
      mapPointY: mapPoint?.[1] ?? null,
      blockId: block?.id ?? p.blockId ?? p.sectionId ?? null,
      blockName: localizedName(block) || p.blockName || p.sectionName || "",
      row: p.row ?? p.rowName ?? p.seat?.row ?? "",
      seatNumber: p.number ?? p.seatNumber ?? p.seat?.number ?? "",
      categoryId: p.seatCategoryId ?? p.categoryId ?? p.seatCategory?.id ?? p.category?.id ?? "",
      categoryName: localizedName(p.seatCategory) || localizedName(p.category) || "",
      areaId: area?.id ?? p.areaId ?? p.zoneId ?? null,
      areaName: localizedName(area),
      sellerListPrice: prices.sellerListPrice,
      buyerAllInPrice: prices.buyerAllInPrice,
      estimatedSellerNet: prices.estimatedSellerNet,
      resaleMovementId: p.resaleMovementId ?? null,
      movementId: p.movementId ?? null,
      contingentId: p.contingentId ?? null,
      exclusive: p.exclusive !== false
    };
  }

  function fallbackFeatureToSeatRow(feature, fallbackIndex, error = null) {
    const compact = safeCompactFeature(feature);
    const p = compact?.properties || feature?.properties || feature || {};
    const block = p.block || p.section || {};
    const area = p.area || p.zone || {};
    const rawPrice = p.amount ?? p.seatBasedPriceAmount ?? p.priceAmount ?? p.listPriceAmount ?? p.price?.amount ?? p.resalePrice?.amount ?? p.seatPrice?.amount ?? p.tariff?.amount ?? null;
    const prices = priceSetFromRawAmount(rawPrice);
    const mapPoint = firstCoordinate(compact?.geometry?.coordinates || feature?.geometry?.coordinates);
    return {
      sourceFeatureId: p.id ?? p.seatId ?? compact?.id ?? feature?.id ?? `raw-${fallbackIndex}`,
      mapGeometryType: compact?.geometry?.type || feature?.geometry?.type || "",
      mapPointX: mapPoint?.[0] ?? null,
      mapPointY: mapPoint?.[1] ?? null,
      blockId: block?.id ?? p.blockId ?? p.sectionId ?? null,
      blockName: localizedName(block) || p.blockName || p.sectionName || "",
      row: p.row ?? p.rowName ?? p.seat?.row ?? "",
      seatNumber: p.number ?? p.seatNumber ?? p.seat?.number ?? "",
      categoryId: p.seatCategoryId ?? p.categoryId ?? p.seatCategory?.id ?? p.category?.id ?? "",
      categoryName: localizedName(p.seatCategory) || localizedName(p.category) || "",
      areaId: area?.id ?? p.areaId ?? p.zoneId ?? null,
      areaName: localizedName(area),
      sellerListPrice: prices.sellerListPrice,
      buyerAllInPrice: prices.buyerAllInPrice,
      estimatedSellerNet: prices.estimatedSellerNet,
      resaleMovementId: p.resaleMovementId ?? null,
      movementId: p.movementId ?? null,
      contingentId: p.contingentId ?? null,
      exclusive: p.exclusive !== false,
      parseError: error ? String(error?.message || error || "row parse failed").slice(0, 160) : undefined
    };
  }

  function safeFeatureToSeatRow(feature, fallbackIndex = "") {
    try {
      return featureToSeatRow(feature);
    } catch (error) {
      return fallbackFeatureToSeatRow(feature, fallbackIndex, error);
    }
  }

  async function fetchJson(url, headers) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    const startedAt = Date.now();
    try {
      const response = await originalFetch(url, {
        credentials: "include",
        headers,
        signal: controller.signal
      });
      const text = await response.text();
      let body = null;
      try {
        body = JSON.parse(text);
      } catch {
        // Keep body null for non-JSON errors.
      }
      return { response, body, text, elapsedMs: Date.now() - startedAt };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  function emitSeatBatchChunks({ url, productId, performanceId, match, scanId, multiScanId, bbox, tileIndex, featureCount, seatRows = [], features = [], progress = null }) {
    const chunkSize = 20;
    const totalRows = Math.max(seatRows.length, features.length);
    for (let start = 0; start < totalRows; start += chunkSize) {
      const chunk = seatRows.slice(start, start + chunkSize);
      const featureChunk = features.slice(start, start + chunkSize);
      let seatsJson = "[]";
      let featuresJson = "[]";
      try {
        seatsJson = JSON.stringify(chunk);
      } catch (error) {
        seatsJson = "[]";
      }
      try {
        featuresJson = JSON.stringify(featureChunk);
      } catch (error) {
        featuresJson = "[]";
      }
      const payload = {
        url,
        productId,
        performanceId,
        match,
        scanId,
        multiScanId,
        bbox,
        tileIndex,
        chunkIndex: Math.floor(start / chunkSize),
        chunkCount: Math.ceil(totalRows / chunkSize),
        featureCount,
        rowCount: chunk.length,
        seatsJson,
        featuresJson
      };
      emit("seat-batch", payload);
      emit("scan-progress", {
        status: progress?.status || "scanning",
        completed: progress?.completed ?? null,
        total: progress?.total ?? null,
        found: progress?.found ?? null,
        tileWidth: progress?.tileWidth ?? null,
        tileHeight: progress?.tileHeight ?? null,
        stepX: progress?.stepX ?? null,
        stepY: progress?.stepY ?? null,
        mapMax: progress?.mapMax ?? null,
        seatBatch: true,
        ...payload
      });
    }
  }

  async function scanPerformance({ productId, performanceId, match = null, scanConfig = {}, scanId, multiScanId = null, matchIndex = null, matchTotal = null }) {
    const params = scanParams(scanConfig);
    const tiles = buildTiles(params);
    const headers = requestHeaders();
    let consecutiveBlocks = 0;
    let found = 0;
    let completed = 0;
    let adaptiveDelayMs = params.delayMs;
    const diagnostics = {
      attemptedTiles: 0,
      successfulTiles: 0,
      blockedTiles: 0,
      timedOutTiles: 0,
      errorTiles: 0,
      rowParseErrors: 0
    };
    const aggregateSeatRows = new Map();
    const aggregateFeatures = new Map();
    const aggregateTileStats = [];

    const scanDiagnostics = () => ({ ...diagnostics });

    function emitScanResult(status, details = {}) {
      const finalSeatRows = Array.from(aggregateSeatRows.values());
      if (finalSeatRows.length) {
        const finalFeatures = Array.from(aggregateFeatures.values());
        emitSeatBatchChunks({
          url: window.location.href,
          productId,
          performanceId,
          match,
          scanId,
          multiScanId,
          bbox: "final",
          tileIndex: "final",
          featureCount: finalSeatRows.length,
          seatRows: finalSeatRows,
          features: finalFeatures,
          progress: {
            status,
            completed,
            total: tiles.length,
            found,
            final: true,
            ...scanDiagnostics(),
            ...details,
            ...params
          }
        });
      }
      emit("scan-result", {
        status,
        scanId,
        multiScanId,
        productId,
        performanceId,
        match,
        completed,
        total: tiles.length,
        found,
        rawFeaturesSeen: found,
        tileStats: aggregateTileStats,
        seatsJson: JSON.stringify(finalSeatRows),
        ...scanDiagnostics(),
        ...details
      });
    }

    emit("scan-progress", {
      status: "started",
      completed: 0,
      total: tiles.length,
      productId,
      performanceId,
      scanId,
      multiScanId,
      matchIndex,
      matchTotal,
      match,
      ...scanDiagnostics(),
      ...params,
      reset: scanConfig.reset !== false
    });

    const availabilityUrl = `/tnwr/v1/secure/seatmap/availability?perfId=${encodeURIComponent(performanceId)}&productId=${encodeURIComponent(productId)}&isSeasonTicketMode=false&advantageId=&withPriceRange=true&ppid=&reservationIdx=&crossSellId=&baseOperationIdsString=`;
    try {
      const { response, body, elapsedMs } = await fetchJson(availabilityUrl, headers);
      if (response.ok && body) {
        emit("api-response", {
          url: window.location.origin + availabilityUrl,
          body,
          meta: { scanId, multiScanId, productId, performanceId, match, elapsedMs }
        });
      }
    } catch (error) {
      emit("scan-progress", {
        status: "api-error",
        stage: "availability",
        message: error.message,
        completed,
        total: tiles.length,
        found,
        productId,
        performanceId,
        scanId,
        multiScanId
      });
    }

    const matchUrl = `/tnwr/v1/secure/seatmap/performance/google-ecommerce-detail?productId=${encodeURIComponent(productId)}&performanceId=${encodeURIComponent(performanceId)}`;
    try {
      const { response, body, elapsedMs } = await fetchJson(matchUrl, headers);
      if (response.ok && body) {
        emit("api-response", {
          url: window.location.origin + matchUrl,
          body,
          meta: { scanId, multiScanId, productId, performanceId, match, elapsedMs }
        });
      }
    } catch (error) {
      emit("scan-progress", {
        status: "api-error",
        stage: "match",
        message: error.message,
        completed,
        total: tiles.length,
        found,
        productId,
        performanceId,
        scanId,
        multiScanId
      });
    }

    for (let i = 0; i < tiles.length; i++) {
      const tile = tiles[i];
      completed = i + 1;
      const bbox = `${tile.x},${tile.y},${tile.w},${tile.h}`;
      const isExclusive = scanConfig.isExclusive == null ? null : (scanConfig.isExclusive === true ? "true" : "false");
      const url = freeSeatsUrlFromTemplate({ productId, performanceId, bbox, isExclusive });

      try {
        diagnostics.attemptedTiles++;
        let { response, body, elapsedMs } = await fetchJson(url, headers);
        if ((response.status === 403 || response.status === 429) && scanConfig.retryBlocked !== false) {
          await new Promise((resolve) => setTimeout(resolve, scanConfig.retryCooldownMs || 3000));
          const retry = await fetchJson(url, headers);
          if (retry.response.ok) {
            response = retry.response;
            body = retry.body;
            elapsedMs = retry.elapsedMs;
          }
        }
        if (response.ok) {
          consecutiveBlocks = 0;
          diagnostics.successfulTiles++;
          adaptiveDelayMs = elapsedMs > 4500
            ? Math.max(adaptiveDelayMs, params.delayMs + 900)
            : Math.max(params.delayMs, adaptiveDelayMs - 150);
          const rawFeatures = Array.isArray(body?.features) ? body.features : [];
          const count = rawFeatures.length;
          found += count;
          aggregateTileStats.push({
            scanId,
            bbox,
            tileIndex: i,
            featureCount: count,
            capturedAt: new Date().toISOString()
          });
          if (count > 0) {
            const compactFeatures = rawFeatures.map(safeCompactFeature);
            const seatRows = rawFeatures.map((feature, rowIndex) => {
              const row = safeFeatureToSeatRow(feature, `${i}-${rowIndex}`);
              if (row?.parseError) diagnostics.rowParseErrors++;
              return row;
            });
            seatRows.forEach((row, rowIndex) => {
              const rowKey = aggregateSeatKey({ properties: row }, `${i}-${rowIndex}`);
              if (rowKey) aggregateSeatRows.set(rowKey, row);
            });
            compactFeatures.forEach((feature, rowIndex) => {
              const featureKey = aggregateSeatKey(feature, `${i}-${rowIndex}`);
              if (featureKey) aggregateFeatures.set(featureKey, feature);
            });
            emitSeatBatchChunks({
              url: window.location.origin + url,
              productId,
              performanceId,
              match,
              scanId,
              multiScanId,
              bbox,
              tileIndex: i,
              featureCount: count,
              seatRows,
              features: compactFeatures,
              progress: {
                status: "scanning",
                completed,
                total: tiles.length,
                found,
                ...scanDiagnostics(),
                ...params
              }
            });
          }
        } else if (response.status === 403 || response.status === 429) {
          consecutiveBlocks++;
          diagnostics.blockedTiles++;
          adaptiveDelayMs = Math.max(adaptiveDelayMs, params.delayMs + 2200);
          emit("scan-progress", {
            status: "blocked",
            httpStatus: response.status,
            retryAfterMs: SCAN_BLOCK_COOLDOWN_MS,
            completed,
            total: tiles.length,
            found,
            productId,
            performanceId,
            scanId,
            multiScanId,
            matchIndex,
            matchTotal,
            bbox,
            headerDiagnostics: headerDiagnostics(),
            ...scanDiagnostics()
          });
          if (consecutiveBlocks >= params.maxConsecutiveBlocks) {
            const details = { httpStatus: response.status, bbox, stopReason: "consecutive-blocks" };
            emitScanResult("blocked", details);
            return { status: "blocked", completed, total: tiles.length, found, ...details };
          }
        }
      } catch (error) {
        if (error?.name === "AbortError") {
          diagnostics.timedOutTiles++;
          adaptiveDelayMs = Math.max(adaptiveDelayMs, params.delayMs + 1600);
        } else {
          diagnostics.errorTiles++;
          adaptiveDelayMs = Math.max(adaptiveDelayMs, params.delayMs + 900);
        }
        emit("scan-progress", {
          status: "error",
          message: error.message,
          completed,
          total: tiles.length,
          found,
          productId,
          performanceId,
          scanId,
          multiScanId,
          matchIndex,
          matchTotal,
          bbox,
          stopReason: error?.name === "AbortError" ? "timeout" : "request-error",
          ...scanDiagnostics()
        });
      }

      emit("scan-progress", {
        status: "scanning",
        completed,
        total: tiles.length,
        found,
        productId,
        performanceId,
        scanId,
        multiScanId,
        matchIndex,
        matchTotal,
        ...scanDiagnostics()
      });
      const jitterMs = scanConfig.jitterMs == null ? 400 : Number(scanConfig.jitterMs);
      const waitMs = adaptiveDelayMs + (Number.isFinite(jitterMs) && jitterMs > 0 ? Math.random() * jitterMs : 0);
      await new Promise((resolve) => setTimeout(resolve, waitMs));
    }

    emitScanResult("done");
    emit("scan-progress", {
      status: "done",
      completed,
      total: tiles.length,
      found,
      productId,
      performanceId,
      scanId,
      multiScanId,
      matchIndex,
      matchTotal,
      ...scanDiagnostics()
    });
    return { status: "done", completed, total: tiles.length, found };
  }

  const originalFetch = sharedState.originalFetch;
  window.fetch = async function (...args) {
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url || "";
    const init = args[1] || {};
    rememberHeaders(url, init.headers);

    const response = await originalFetch.apply(this, args);
    if (isActive() && shouldCapture(url)) {
      try {
        const clone = response.clone();
        const body = await clone.json();
        emit("api-response", { url: String(url), body });
      } catch {
        // Ignore non-JSON responses.
      }
    }
    return response;
  };

  const originalOpen = sharedState.originalOpen;
  const originalSend = sharedState.originalSend;
  const originalSetHeader = sharedState.originalSetHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__fssUrl = url;
    this.__fssHeaders = {};
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (isActive() && this.__fssHeaders) this.__fssHeaders[name] = value;
    return originalSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (isActive() && shouldCapture(this.__fssUrl)) {
      rememberHeaders(this.__fssUrl, this.__fssHeaders);
      this.addEventListener("load", function () {
        if (!isActive()) return;
        try {
          emit("api-response", {
            url: String(this.__fssUrl),
            body: JSON.parse(this.responseText)
          });
        } catch {
          // Ignore non-JSON responses.
        }
      });
    }
    return originalSend.apply(this, args);
  };

  const handleScoutMessage = async (event) => {
    if (!isActive()) return;
    if (event.source !== window) return;
    if (!["FIFA_SELLER_SCOUT_SCAN_ALL", "FIFA_SELLER_SCOUT_SCAN_MATCHES"].includes(event.data?.type)) return;
    if (scanInProgress) {
      emit("scan-progress", { status: "already-running" });
      return;
    }

    const { productId, performanceId, scanConfig = {} } = event.data;
    if (!productId || (event.data.type === "FIFA_SELLER_SCOUT_SCAN_ALL" && !performanceId)) {
      emit("scan-progress", { status: "missing-ids", productId, performanceId });
      return;
    }
    const now = Date.now();
    const cooldownKey = event.data.type === "FIFA_SELLER_SCOUT_SCAN_MATCHES"
      ? `multi:${productId}`
      : `performance:${performanceId}`;
    const lastScanStartedAt = lastScanStartedByTarget.get(cooldownKey) || 0;
    const blockedUntil = blockedUntilByTarget.get(cooldownKey) || 0;
    if (now < blockedUntil) {
      emit("scan-progress", {
        status: "cooldown",
        productId,
        performanceId,
        retryAfterMs: blockedUntil - now,
        reason: "fifa-rate-limit"
      });
      return;
    }
    if (!scanConfig.testMode && now - lastScanStartedAt < SCAN_COOLDOWN_MS) {
      emit("scan-progress", {
        status: "cooldown",
        productId,
        performanceId,
        retryAfterMs: SCAN_COOLDOWN_MS - (now - lastScanStartedAt)
      });
      return;
    }

    scanInProgress = true;
    lastScanStartedByTarget.set(cooldownKey, now);

    try {
      if (event.data.type === "FIFA_SELLER_SCOUT_SCAN_MATCHES") {
        const matches = Array.isArray(event.data.matches) ? event.data.matches : [];
        const multiScanId = `multi-${Date.now()}`;
        emit("multi-scan-progress", {
          status: "started",
          multiScanId,
          completedMatches: 0,
          totalMatches: matches.length
        });
        let completedMatches = 0;
        let finalStatus = "done";
        for (let index = 0; index < matches.length; index++) {
          const match = matches[index];
          const targetPerformanceId = match.performanceId;
          if (!targetPerformanceId) continue;
          const scanId = `${targetPerformanceId}-${Date.now()}`;
          emit("multi-scan-progress", {
            status: "match-started",
            multiScanId,
            completedMatches: index,
            totalMatches: matches.length,
            match
          });
          const result = await scanPerformance({
            productId,
            performanceId: targetPerformanceId,
            match,
            scanConfig,
            scanId,
            multiScanId,
            matchIndex: index + 1,
            matchTotal: matches.length
          });
          completedMatches = index + 1;
          emit("multi-scan-progress", {
            status: result.status === "blocked" ? "blocked" : "match-done",
            multiScanId,
            completedMatches,
            totalMatches: matches.length,
            match,
            result
          });
          if (result.status === "blocked") {
            finalStatus = "blocked";
            blockedUntilByTarget.set(cooldownKey, Date.now() + SCAN_BLOCK_COOLDOWN_MS);
            break;
          }
          await new Promise((resolve) => setTimeout(resolve, scanConfig.matchDelayMs || 1200));
        }
        emit("multi-scan-progress", {
          status: finalStatus,
          multiScanId,
          completedMatches,
          totalMatches: matches.length
        });
      } else {
        const scanId = `${performanceId}-${Date.now()}`;
        const result = await scanPerformance({ productId, performanceId, scanConfig, scanId });
        if (result.status === "blocked") {
          blockedUntilByTarget.set(cooldownKey, Date.now() + SCAN_BLOCK_COOLDOWN_MS);
        }
      }
    } catch (error) {
      emit("scan-progress", {
        status: "error",
        productId,
        performanceId,
        message: String(error?.message || error || "scan failed")
      });
    } finally {
      scanInProgress = false;
    }
  };

  window.addEventListener("message", handleScoutMessage);
  sharedState.cleanup = () => {
    window.removeEventListener("message", handleScoutMessage);
    if (window.fetch === sharedState.fetchWrapper) window.fetch = sharedState.originalFetch;
    if (XMLHttpRequest.prototype.open === sharedState.openWrapper) XMLHttpRequest.prototype.open = sharedState.originalOpen;
    if (XMLHttpRequest.prototype.send === sharedState.sendWrapper) XMLHttpRequest.prototype.send = sharedState.originalSend;
    if (XMLHttpRequest.prototype.setRequestHeader === sharedState.setHeaderWrapper) {
      XMLHttpRequest.prototype.setRequestHeader = sharedState.originalSetHeader;
    }
  };
  sharedState.fetchWrapper = window.fetch;
  sharedState.openWrapper = XMLHttpRequest.prototype.open;
  sharedState.sendWrapper = XMLHttpRequest.prototype.send;
  sharedState.setHeaderWrapper = XMLHttpRequest.prototype.setRequestHeader;

  emit("ready", { href: window.location.href });
})();
