const BUYER_FEE_RATE = 0.15;
const SELLER_FEE_RATE = 0.15;
const CROWD_API_URL = "https://wc26champion.com/api/market-scan";
const DIRECT_LISTINGS_API_URL = "https://wc26champion.com/api/direct-listings";
const DIRECT_LEADS_API_URL = "https://wc26champion.com/api/direct-leads";
const CROWD_SHARE_ENABLED_KEY = "crowdShareEnabled";
const CROWD_VISITOR_ID_KEY = "crowdVisitorId";
const CROWD_LAST_SYNC_KEY = "crowdLastSync";
const CROWD_CONTRIBUTOR_PASS_KEY = "crowdContributorPass";
const CROWD_UPLOAD_BACKOFF_UNTIL_KEY = "crowdUploadBackoffUntil";
const MAX_LOCAL_SNAPSHOTS_PER_GAME = 80;
const MAX_TILE_STATS_PER_GAME = 256;
const CROWD_UPLOAD_TIMEOUT_MS = 15000;
const shareInFlightBySnapshot = new Map();

function currentContributorPass(passOrSync) {
  const pass = passOrSync?.code ? passOrSync : passOrSync?.result?.contributorPass;
  if (!pass?.code || !pass?.expiresAt) return null;
  const expiresAt = new Date(pass.expiresAt).getTime();
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) return null;
  return { code: pass.code, expiresAt: pass.expiresAt };
}

async function fetchJsonWithTimeout(url, options = {}, timeoutMs = CROWD_UPLOAD_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    const json = await response.json().catch(() => null);
    return { response, json };
  } finally {
    clearTimeout(timer);
  }
}

function shareErrorMessage(result, response = null) {
  const detail = result?.detail || result?.data || null;
  const detailText =
    detail?.message ||
    detail?.error ||
    detail?.details ||
    detail?.hint ||
    detail?.raw ||
    "";
  const base = result?.error || result?.message || (response?.status ? `HTTP ${response.status}` : "Could not share");
  if (!detailText) return base;
  return `${base}: ${String(detailText).slice(0, 220)}`;
}

async function directApi(url, options = {}) {
  const { response, json } = await fetchJsonWithTimeout(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });
  if (!response.ok || json?.ok === false) {
    return {
      ok: false,
      status: response.status,
      error: shareErrorMessage(json, response),
      detail: json?.detail || null
    };
  }
  return json || { ok: true };
}

function directMatchSeatPayload(seat = {}) {
  return {
    seatId: seat.seatId,
    blockName: seat.blockName,
    areaName: seat.areaName,
    section: seat.blockName || seat.areaName || "",
    row: seat.row,
    seatNumber: seat.seatNumber,
    categoryId: seat.categoryId,
    categoryName: seat.categoryName,
    sellerListPrice: seat.sellerListPrice,
    buyerAllInPrice: seat.buyerAllInPrice,
    estimatedSellerNet: seat.estimatedSellerNet,
    movementId: seat.movementId,
    resaleMovementId: seat.resaleMovementId
  };
}

function configureSidePanel() {
  if (!chrome.sidePanel?.setPanelBehavior) return;
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch(() => {});
}

configureSidePanel();

function gameKey(site, performanceId) {
  return `${site || "fifa_resale"}:${performanceId}`;
}

function siteFromUrl(url) {
  const host = (() => {
    try {
      return new URL(String(url || "")).hostname;
    } catch {
      return String(url || "");
    }
  })();
  if (host.includes("-resale-")) return "fifa_resale";
  if (host.includes("-shop-")) return "fifa_primary";
  return "fifa_resale";
}

function extractParam(url, name) {
  try {
    return new URL(url).searchParams.get(name);
  } catch {
    const match = String(url || "").match(new RegExp(`[?&]${name}=([^&]+)`));
    return match ? decodeURIComponent(match[1]) : null;
  }
}

function amountToUsd(raw) {
  if (raw == null || Number.isNaN(Number(raw))) return null;
  return Number(raw) / 1000;
}

function buyerAllInToSellerList(buyerAllIn) {
  return buyerAllIn == null ? null : buyerAllIn / (1 + BUYER_FEE_RATE);
}

function buyerAllInToSellerNet(buyerAllIn) {
  const list = buyerAllInToSellerList(buyerAllIn);
  return list == null ? null : list * (1 - SELLER_FEE_RATE);
}

function sellerListToBuyerAllIn(sellerList) {
  return sellerList == null ? null : sellerList * (1 + BUYER_FEE_RATE);
}

function sellerListToSellerNet(sellerList) {
  return sellerList == null ? null : sellerList * (1 - SELLER_FEE_RATE);
}

function snapshotSeatFingerprint(seats = []) {
  return seats
    .map((seat) => [
      seat.seatId,
      seat.sellerListPrice,
      seat.buyerAllInPrice,
      seat.estimatedSellerNet
    ].map((part) => part ?? "").join(":"))
    .sort()
    .join("|");
}

function isPrimarySite(site) {
  return site === "fifa_primary";
}

function marketPriceSet(site, rawAmount) {
  const fifaBasePrice = amountToUsd(rawAmount);
  if (fifaBasePrice == null) return { sellerListPrice: null, buyerAllInPrice: null, estimatedSellerNet: null };
  if (isPrimarySite(site)) {
    return {
      sellerListPrice: fifaBasePrice,
      buyerAllInPrice: fifaBasePrice,
      estimatedSellerNet: null
    };
  }
  const sellerListPrice = sellerListToBuyerAllIn(fifaBasePrice);
  return {
    sellerListPrice,
    buyerAllInPrice: sellerListToBuyerAllIn(sellerListPrice),
    estimatedSellerNet: sellerListToSellerNet(sellerListPrice)
  };
}

function emptyGame(site, performanceId, productId) {
  return {
    site,
    performanceId,
    productId,
    match: {},
    stadiumKey: "",
    categories: {},
    seats: {},
    stadiumSections: {},
    stadiumSeats: {},
    tileStats: [],
    rawFeaturesSeen: 0,
    parseDiagnostics: {
      apiResponses: 0,
      scanResults: 0,
      lastFeaturePayloadCount: 0,
      lastScanResultFeatureCount: 0,
      parsedSeatCount: 0,
      parsedStadiumSectionCount: 0,
      parsedStadiumSeatCount: 0,
      lastPayloadAt: null,
      lastFeatureSample: null
    },
    snapshots: [],
    velocity: null,
    lastUpdatedAt: null,
    scanProgress: null
  };
}

function updateParseDiagnostics(game, patch = {}) {
  game.parseDiagnostics = {
    ...(game.parseDiagnostics || {}),
    ...patch,
    parsedSeatCount: Object.keys(game.seats || {}).length,
    parsedStadiumSectionCount: Object.keys(game.stadiumSections || {}).length,
    parsedStadiumSeatCount: Object.keys(game.stadiumSeats || {}).length
  };
}

async function getState() {
  const data = await chrome.storage.local.get(["games", "discoveredMatches", "multiScan"]);
  const normalized = normalizeGames(data.games || {});
  if (normalized.changed) {
    await chrome.storage.local.set({ games: normalized.games });
  }
  return {
    games: normalized.games,
    discoveredMatches: data.discoveredMatches || null,
    multiScan: data.multiScan || null
  };
}

async function saveState(games) {
  await chrome.storage.local.set({ games: normalizeGames(games || {}).games });
}

async function saveDiscoveredMatches(discoveredMatches) {
  await chrome.storage.local.set({ discoveredMatches });
}

async function saveMultiScan(multiScan) {
  await chrome.storage.local.set({ multiScan });
}

function randomHex(bytes = 16) {
  const values = new Uint8Array(bytes);
  crypto.getRandomValues(values);
  return Array.from(values, (value) => value.toString(16).padStart(2, "0")).join("");
}

async function crowdSettings() {
  const data = await chrome.storage.local.get([
    CROWD_SHARE_ENABLED_KEY,
    CROWD_VISITOR_ID_KEY,
    CROWD_LAST_SYNC_KEY,
    CROWD_CONTRIBUTOR_PASS_KEY,
    CROWD_UPLOAD_BACKOFF_UNTIL_KEY
  ]);
  let visitorId = data[CROWD_VISITOR_ID_KEY];
  if (!visitorId) {
    visitorId = randomHex(16);
    await chrome.storage.local.set({ [CROWD_VISITOR_ID_KEY]: visitorId });
  }
  return {
    enabled: data[CROWD_SHARE_ENABLED_KEY] === true,
    visitorId,
    lastSync: data[CROWD_LAST_SYNC_KEY] || null,
    contributorPass: currentContributorPass(data[CROWD_CONTRIBUTOR_PASS_KEY]) || currentContributorPass(data[CROWD_LAST_SYNC_KEY]),
    uploadBackoffUntil: data[CROWD_UPLOAD_BACKOFF_UNTIL_KEY] || null
  };
}

function crowdSeatPayload(game) {
  return Object.values(game.seats || {}).map((seat) => ({
    seatId: seat.seatId,
    blockName: seat.blockName,
    areaName: seat.areaName,
    section: seat.blockName || seat.areaName || "",
    row: seat.row,
    seatNumber: seat.seatNumber,
    categoryId: seat.categoryId,
    categoryName: seat.categoryName,
    sellerListPrice: seat.sellerListPrice,
    buyerAllInPrice: seat.buyerAllInPrice,
    estimatedSellerNet: seat.estimatedSellerNet,
    movementId: seat.movementId,
    resaleMovementId: seat.resaleMovementId
  }));
}

function crowdScanQuality(game) {
  const progress = game.scanProgress || {};
  const completedAll = Number(progress.total || 0) > 0 && Number(progress.completed || 0) >= Number(progress.total || 0);
  if (progress.status === "done" || progress.final === true || completedAll) {
    return "complete";
  }
  if (progress.status === "blocked") return "blocked";
  return "partial";
}

function crowdMatchName(match = {}) {
  const name = match.name || "";
  const matchCode = match.matchCode || "";
  if (matchCode && !/\bmatch\s+\d+\b/i.test(name)) return `${matchCode} / ${name}`.trim();
  return name;
}

async function shareCrowdSnapshot(game, options = {}) {
  const settings = await crowdSettings();
  if (!settings.enabled) return { ok: false, skipped: true, reason: "Sharing is off" };
  if (!game) return { ok: false, skipped: true, reason: "No game selected" };
  const backoffUntil = settings.uploadBackoffUntil ? new Date(settings.uploadBackoffUntil).getTime() : 0;
  if (!options.force && Number.isFinite(backoffUntil) && backoffUntil > Date.now()) {
    return {
      ok: false,
      skipped: true,
      reason: "Scan sharing is cooling down. Try again in a minute.",
      retryAfterMs: backoffUntil - Date.now()
    };
  }
  if ((!game.snapshots || !game.snapshots.length) && Object.keys(game.seats || {}).length) {
    createVelocity(game);
  }
  const snapshot = game.snapshots?.[game.snapshots.length - 1];
  if (!snapshot?.snapshotId) return { ok: false, skipped: true, reason: "No finished scan yet" };
  if (!options.force && settings.lastSync?.snapshotId === snapshot.snapshotId) {
    return { ok: true, skipped: true, reason: "Already shared", lastSync: settings.lastSync };
  }
  if (!options.force && shareInFlightBySnapshot.has(snapshot.snapshotId)) {
    return shareInFlightBySnapshot.get(snapshot.snapshotId);
  }

  const uploadPromise = (async () => {
  const seats = crowdSeatPayload(game);
  if (!seats.length) return { ok: false, skipped: true, reason: "No seats to share" };

  const payload = {
    source: game.site || "fifa_resale",
    visitorId: settings.visitorId,
    performanceId: game.performanceId,
    productId: game.productId,
    match: {
      name: crowdMatchName(game.match),
      date: game.match?.date || "",
      time: game.match?.time || "",
      venue: game.match?.venue || game.match?.stadium || "",
      currency: game.match?.currency || "USD"
    },
    scan: {
      status: crowdScanQuality(game) === "complete" ? "done" : (game.scanProgress?.status || "done"),
      quality: crowdScanQuality(game),
      rawFeaturesSeen: game.rawFeaturesSeen || 0,
      attemptedTiles: game.scanProgress?.attemptedTiles || null,
      successfulTiles: game.scanProgress?.successfulTiles || null,
      blockedTiles: game.scanProgress?.blockedTiles || null
    },
    seats,
    contributorPass: settings.contributorPass
  };

  try {
    const { response, json: result } = await fetchJsonWithTimeout(CROWD_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const contributorPass = currentContributorPass(result?.contributorPass) || settings.contributorPass || null;
    const ok = response.ok && result?.ok !== false;
    const retryAfterSeconds = Number(result?.retryAfterSeconds || response.headers.get("Retry-After") || 0);
    const nextStorage = {
      [CROWD_LAST_SYNC_KEY]: {
        ok,
        snapshotId: snapshot.snapshotId,
        syncedAt: new Date().toISOString(),
        seatCount: seats.length,
        error: ok ? null : shareErrorMessage(result, response),
        result
      }
    };
    if (!ok && response.status === 429) {
      nextStorage[CROWD_UPLOAD_BACKOFF_UNTIL_KEY] = new Date(Date.now() + Math.max(60, retryAfterSeconds || 60) * 1000).toISOString();
    } else if (ok) {
      nextStorage[CROWD_UPLOAD_BACKOFF_UNTIL_KEY] = null;
    }
    if (contributorPass) nextStorage[CROWD_CONTRIBUTOR_PASS_KEY] = contributorPass;
    await chrome.storage.local.set(nextStorage);
    return {
      ok,
      snapshotId: snapshot.snapshotId,
      seatCount: seats.length,
      error: ok ? null : shareErrorMessage(result, response),
      result
    };
  } catch (error) {
    const message = String(error?.message || error || "sync failed");
    await chrome.storage.local.set({
      [CROWD_LAST_SYNC_KEY]: {
        ok: false,
        snapshotId: snapshot.snapshotId,
        syncedAt: new Date().toISOString(),
        error: message
      }
    });
    return { ok: false, snapshotId: snapshot.snapshotId, error: message };
  }
  })();

  shareInFlightBySnapshot.set(snapshot.snapshotId, uploadPromise);
  try {
    return await uploadPromise;
  } finally {
    setTimeout(() => {
      if (shareInFlightBySnapshot.get(snapshot.snapshotId) === uploadPromise) {
        shareInFlightBySnapshot.delete(snapshot.snapshotId);
      }
    }, 1000);
  }
}

async function recordCrowdSkip(reason, snapshotId = null) {
  await chrome.storage.local.set({
    [CROWD_LAST_SYNC_KEY]: {
      ok: false,
      skipped: true,
      snapshotId,
      syncedAt: new Date().toISOString(),
      reason
    }
  });
}

async function maybeShareFinishedScan(ctx, message = {}) {
  if (!ctx?.game) return null;
  const progress = ctx.game.scanProgress || {};
  const status = message.status || progress.status || "";
  const completed = Number(message.completed ?? progress.completed ?? 0);
  const total = Number(message.total ?? progress.total ?? 0);
  const hasSeats = Object.keys(ctx.game.seats || {}).length > 0;
  const finalFlag = message.final === true || progress.final === true;
  const completedAll = total > 0 && completed >= total;
  const shareableFinal =
    status === "done" ||
    (status === "blocked" && hasSeats) ||
    (finalFlag && completedAll && hasSeats);
  if (!shareableFinal) return null;

  const currentScanId = message.scanId || ctx.game.scanProgress?.scanId || ctx.game.currentScrape?.scrapeId || null;
  const lastSnapshot = ctx.game.snapshots?.[ctx.game.snapshots.length - 1] || null;
  const needsSnapshot =
    !lastSnapshot ||
    (currentScanId && lastSnapshot.scrapeId !== currentScanId) ||
    ctx.game.velocity?.currentSeatCount !== Object.keys(ctx.game.seats || {}).length;
  if (needsSnapshot) {
    createVelocity(ctx.game);
  }
  const result = await shareCrowdSnapshot(ctx.game);
  ctx.game.lastCrowdShareAttemptAt = new Date().toISOString();
  ctx.game.lastCrowdShareResult = result || null;
  await saveState(ctx.state.games);
  return result;
}

async function ensureInjected(tabId) {
  if (!tabId || !chrome.scripting?.executeScript) return;
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["injected.js"],
    world: "MAIN"
  }).catch(() => {});
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  }).catch(() => {});
}

function queryTabs(query) {
  return new Promise((resolve) => chrome.tabs.query(query, resolve));
}

function isSeatMapTab(tab) {
  return Boolean(tab?.id && String(tab.url || "").includes("/secure/selection/event/seat/performance/"));
}

async function findSeatMapTab(site = "") {
  const active = await queryTabs({ active: true, currentWindow: true });
  if (isSeatMapTab(active[0]) && (!site || siteFromUrl(active[0].url || "") === site)) return active[0];
  const fifaTabs = await queryTabs({ url: "*://*.tickets.fifa.com/secure/selection/event/seat/performance/*" });
  return fifaTabs.find((tab) => isSeatMapTab(tab) && (!site || siteFromUrl(tab.url || "") === site)) || null;
}

async function refreshActiveSeatMapState() {
  const tab = await findSeatMapTab();
  if (!tab?.id) return;
  await ensureInjected(tab.id);
  const pageInfo = await chrome.tabs.sendMessage(tab.id, { type: "FIFA_SELLER_SCOUT_READ_PAGE" }).catch(() => null);
  if (pageInfo?.type === "FIFA_SELLER_SCOUT_PAGE_INFO") {
    await processPageInfo(pageInfo);
    return;
  }
  const ctx = await ensureGame(tab.url || "", { site: siteFromUrl(tab.url || "") });
  if (ctx) {
    ctx.game.lastUpdatedAt = new Date().toISOString();
    await saveState(ctx.state.games);
  }
}

async function activeSeatMapContext() {
  const [tab] = await queryTabs({ active: true, currentWindow: true });
  if (!isSeatMapTab(tab)) {
    return { ok: false, error: "Open the FIFA game seat map you want to use" };
  }
  await ensureInjected(tab.id);
  const site = siteFromUrl(tab.url || "");
  const pageInfo = await chrome.tabs.sendMessage(tab.id, { type: "FIFA_SELLER_SCOUT_READ_PAGE" }).catch(() => null);
  if (pageInfo?.type === "FIFA_SELLER_SCOUT_PAGE_INFO") await processPageInfo(pageInfo);
  const performanceId =
    pageInfo?.performanceId ||
    extractParam(tab.url, "performanceId") ||
    String(tab.url || "").match(/performance\/(\d+)/)?.[1] ||
    "";
  const productId = pageInfo?.productId || extractParam(tab.url, "productId") || "";
  if (!performanceId) {
    return { ok: false, error: "Open the FIFA game seat map you want to use" };
  }
  const state = await getState();
  const key = gameKey(site, performanceId);
  const game = state.games?.[key] || null;
  return {
    ok: true,
    tabId: tab.id,
    url: tab.url || "",
    site,
    performanceId,
    productId: game?.productId || productId,
    gameKey: key,
    game
  };
}

async function findSeatMapTabByPerformance(performanceId) {
  const tabs = await queryTabs({ url: "*://*.tickets.fifa.com/secure/selection/event/seat/performance/*" });
  return tabs.find((tab) => String(tab.url || "").includes(`/performance/${performanceId}/`)) || null;
}

function marketSeatMapUrl(performanceId, site = "fifa_resale", productId = "") {
  const host = site === "fifa_primary" ? "fwc26-shop-usd.tickets.fifa.com" : "fwc26-resale-usd.tickets.fifa.com";
  const productQuery = productId ? `?productId=${encodeURIComponent(productId)}` : "";
  return `https://${host}/secure/selection/event/seat/performance/${encodeURIComponent(performanceId)}/lang/en${productQuery}`;
}

function fifaResaleStartUrl() {
  return "https://fwc26-resale-usd.tickets.fifa.com/";
}

function fifaPrimaryStartUrl() {
  return "https://fwc26-shop-usd.tickets.fifa.com/secure/selection/event/date/product/10229225515651/lang/en";
}

async function findSeatMapTabByMarket(performanceId, site = "") {
  const tabs = await queryTabs({ url: "*://*.tickets.fifa.com/secure/selection/event/seat/performance/*" });
  return tabs.find((tab) => {
    const url = String(tab.url || "");
    if (!url.includes(`/performance/${performanceId}/`)) return false;
    return !site || siteFromUrl(url) === site;
  }) || null;
}

function normalizeCategoryName(name) {
  if (!name) return "";
  if (typeof name === "string") return name;
  return name.en || name.label || String(name);
}

function isUsefulMatchValue(value) {
  const text = String(value || "").trim();
  return text && !/^(Current FIFA Match|Current match|Seat selection on map)/i.test(text);
}

function mergeMatch(base = {}, incoming = {}) {
  const merged = { ...base };
  for (const [key, value] of Object.entries(incoming || {})) {
    if (key === "date" && /\d{1,2}:\d{2}/.test(String(merged.date || merged.time || "")) && !/\d{1,2}:\d{2}/.test(String(value || ""))) {
      continue;
    }
    if (key === "currency" && !merged.currency) merged.currency = value;
    else if (isUsefulMatchValue(value) || !isUsefulMatchValue(merged[key])) merged[key] = value;
  }
  return merged;
}

function normalizeVenue(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function deriveStadiumKey(game = {}, fallback = {}) {
  const match = fallback.match || game.match || {};
  const venue = match.venue || match.stadium || game.match?.venue || game.match?.stadium || "";
  const productId = fallback.productId || game.productId || "";
  const performanceId = fallback.performanceId || game.performanceId || "";
  return normalizeVenue(venue) || (productId && performanceId ? `${productId}:${performanceId}` : String(performanceId || productId || ""));
}

function ensureStadiumCatalogScope(game, fallback = {}) {
  const nextKey = deriveStadiumKey(game, fallback);
  if (!nextKey) return;
  if (!game.stadiumKey) {
    game.stadiumKey = nextKey;
    return;
  }
  if (game.stadiumKey !== nextKey) {
    game.stadiumKey = nextKey;
    game.categories = {};
    game.stadiumSections = {};
    game.stadiumSeats = {};
  }
}

function mergeUniqueBy(items = [], keyFn) {
  const map = new Map();
  for (const item of items || []) {
    const key = keyFn(item);
    if (!key || map.has(key)) continue;
    map.set(key, item);
  }
  return Array.from(map.values());
}

function trimGameHistory(game) {
  if (!game) return game;
  if (Array.isArray(game.snapshots) && game.snapshots.length > MAX_LOCAL_SNAPSHOTS_PER_GAME) {
    game.snapshots = game.snapshots.slice(-MAX_LOCAL_SNAPSHOTS_PER_GAME);
  }
  if (Array.isArray(game.tileStats) && game.tileStats.length > MAX_TILE_STATS_PER_GAME) {
    game.tileStats = game.tileStats.slice(-MAX_TILE_STATS_PER_GAME);
  }
  return game;
}

function mergeGameRecords(existing = {}, incoming = {}) {
  const lastUpdatedAt = [existing.lastUpdatedAt, incoming.lastUpdatedAt].filter(Boolean).sort().pop() || null;
  const existingSeatCount = Object.keys(existing.seats || {}).length;
  const incomingSeatCount = Object.keys(incoming.seats || {}).length;
  const seatSource = incomingSeatCount >= existingSeatCount ? incoming : existing;
  const merged = {
    ...existing,
    ...incoming,
    site: incoming.site || existing.site || "fifa_resale",
    productId: incoming.productId || existing.productId || "",
    performanceId: incoming.performanceId || existing.performanceId || "",
    match: mergeMatch(existing.match || {}, incoming.match || {}),
    stadiumKey: incoming.stadiumKey || existing.stadiumKey || deriveStadiumKey({ ...existing, ...incoming }),
    categories: { ...(existing.categories || {}), ...(incoming.categories || {}) },
    stadiumSections: { ...(existing.stadiumSections || {}), ...(incoming.stadiumSections || {}) },
    stadiumSeats: { ...(existing.stadiumSeats || {}), ...(incoming.stadiumSeats || {}) },
    seats: { ...(seatSource.seats || {}) },
    rawFeaturesSeen: Math.max(Number(existing.rawFeaturesSeen || 0), Number(incoming.rawFeaturesSeen || 0)),
    tileStats: mergeUniqueBy([...(existing.tileStats || []), ...(incoming.tileStats || [])], (item) => JSON.stringify([item.scanId, item.tileIndex, item.bbox, item.featureCount])),
    snapshots: mergeUniqueBy([...(existing.snapshots || []), ...(incoming.snapshots || [])], (item) => item.snapshotId),
    velocity: incoming.velocity || existing.velocity || null,
    scanProgress: incoming.scanProgress || existing.scanProgress || null,
    parseDiagnostics: { ...(existing.parseDiagnostics || {}), ...(incoming.parseDiagnostics || {}) },
    lastUpdatedAt
  };
  return trimGameHistory(merged);
}

function normalizeGames(games = {}) {
  let changed = false;
  const normalized = {};
  for (const [key, game] of Object.entries(games || {})) {
    const performanceId = game.performanceId || key.split(":")[1];
    if (!performanceId) continue;
    const keySite = key.split(":")[0];
    const site = game.site || (keySite === "fifa" ? "fifa_resale" : keySite) || "fifa_resale";
    const canonicalKey = gameKey(site, performanceId);
    if (key !== canonicalKey || game.site !== site) changed = true;
    normalized[canonicalKey] = mergeGameRecords(normalized[canonicalKey], {
      ...game,
      site,
      performanceId
    });
  }
  return { games: normalized, changed };
}

function firstDefined(...values) {
  return values.find((value) => value != null && value !== "");
}

function localizedName(value) {
  if (!value) return "";
  if (typeof value === "string" || typeof value === "number") return String(value);
  return value.name?.en || value.name || value.label?.en || value.label || value.en || "";
}

function firstCoordinate(value) {
  if (!Array.isArray(value)) return null;
  if (value.length >= 2 && Number.isFinite(Number(value[0])) && Number.isFinite(Number(value[1]))) {
    return [Number(value[0]), Number(value[1])];
  }
  for (const child of value) {
    const point = firstCoordinate(child);
    if (point) return point;
  }
  return null;
}

function rawAmountFromProperties(p) {
  const raw = firstDefined(
    p.amount,
    p.seatBasedPriceAmount,
    p.priceAmount,
    p.listPriceAmount,
    p.price?.amount,
    p.resalePrice?.amount,
    p.seatPrice?.amount,
    p.tariff?.amount
  );
  return raw == null || typeof raw === "object" ? null : raw;
}

function looksLikeSeatPayload(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const p = value.properties || value;
  const hasSeatNumber = firstDefined(
    p.number,
    p.seatNumber,
    p.seat?.number,
    p.place?.number,
    p.placeNumber
  ) != null;
  const hasRow = firstDefined(
    p.row,
    p.rowName,
    p.rowLabel,
    p.seat?.row,
    p.place?.row,
    p.placeRow
  ) != null;
  const hasLocation = Boolean(firstDefined(
    p.block,
    p.section,
    p.logicalBlock,
    p.physicalBlock,
    p.blockId,
    p.sectionId,
    p.blockName,
    p.sectionName,
    p.place?.block,
    p.place?.section
  ));
  const hasPrice = rawAmountFromProperties(p) != null;
  return Boolean(hasSeatNumber && hasRow && (hasLocation || hasPrice));
}

function extractSeatFeaturesFromPayload(body) {
  if (Array.isArray(body?.features)) return body.features;
  const out = [];
  const seen = new Set();

  function visit(value, depth = 0) {
    if (out.length >= 6000 || depth > 12 || value == null) return;
    if (Array.isArray(value)) {
      for (const child of value) visit(child, depth + 1);
      return;
    }
    if (typeof value !== "object") return;
    if (seen.has(value)) return;
    seen.add(value);

    if (looksLikeSeatPayload(value)) {
      out.push(value.properties ? value : {
        id: value.id ?? value.seatId ?? value.placeId ?? value.place?.id ?? null,
        geometry: value.geometry || value.shape || undefined,
        properties: value
      });
      return;
    }

    for (const [key, child] of Object.entries(value)) {
      if ([
        "styles",
        "style",
        "legend",
        "priceRangeCategories",
        "filters",
        "facets"
      ].includes(key)) continue;
      visit(child, depth + 1);
    }
  }

  visit(body);
  return out;
}

function stadiumSeatKey(row) {
  const parts = [
    row.blockId,
    row.blockName,
    row.row,
    row.seatNumber
  ].filter((value) => value != null && value !== "");
  return parts.map((value) => String(value).replace(/\s+/g, "_")).join(":");
}

function stadiumSectionKey(row) {
  return String(firstDefined(row.blockId, row.blockName, row.sectionId, row.sectionName, "") || "")
    .replace(/\s+/g, "_");
}

function upsertStadiumSection(game, row, source = "unknown") {
  const blockName = firstDefined(row.blockName, row.sectionName);
  const blockId = firstDefined(row.blockId, row.sectionId);
  if (!blockName && !blockId) return false;
  game.stadiumSections = game.stadiumSections || {};
  const key = stadiumSectionKey({ blockId, blockName });
  if (!key) return false;
  const existing = game.stadiumSections[key] || {};
  game.stadiumSections[key] = {
    ...existing,
    stadiumKey: game.stadiumKey || existing.stadiumKey || "",
    blockId: blockId ?? existing.blockId ?? null,
    blockName: String(blockName || existing.blockName || blockId || ""),
    categoryId: row.categoryId != null ? String(row.categoryId) : (existing.categoryId || ""),
    categoryName: row.categoryName || existing.categoryName || "",
    color: row.color || existing.color || null,
    source,
    capturedAt: new Date().toISOString()
  };
  return true;
}

function upsertStadiumSeat(game, row, source = "unknown", fallbackIndex = "") {
  if (!row?.blockName || !row?.row || !row?.seatNumber) return false;
  upsertStadiumSection(game, row, source);
  game.stadiumSeats = game.stadiumSeats || {};
  const key = stadiumSeatKey(row, fallbackIndex);
  if (!key) return false;
  game.stadiumSeats[key] = {
    ...(game.stadiumSeats[key] || {}),
    stadiumKey: game.stadiumKey || game.stadiumSeats[key]?.stadiumKey || "",
    blockId: row.blockId ?? game.stadiumSeats[key]?.blockId ?? null,
    blockName: row.blockName || game.stadiumSeats[key]?.blockName || "",
    row: row.row || game.stadiumSeats[key]?.row || "",
    seatNumber: row.seatNumber || game.stadiumSeats[key]?.seatNumber || "",
    categoryId: row.categoryId != null ? String(row.categoryId) : (game.stadiumSeats[key]?.categoryId || ""),
    categoryName: row.categoryName || game.stadiumSeats[key]?.categoryName || "",
    areaId: row.areaId ?? game.stadiumSeats[key]?.areaId ?? null,
    areaName: row.areaName || game.stadiumSeats[key]?.areaName || "",
    source,
    capturedAt: new Date().toISOString()
  };
  return true;
}

function collectStadiumSeatRows(value, context = {}, out = [], depth = 0) {
  if (out.length > 75000 || depth > 12 || value == null) return out;
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index++) {
      collectStadiumSeatRows(value[index], context, out, depth + 1);
    }
    return out;
  }
  if (typeof value !== "object") return out;

  const block = value.block || value.section || value.logicalBlock || value.physicalBlock;
  const area = value.area || value.zone;
  const category = value.seatCategory || value.category;
  const next = {
    ...context,
    blockId: firstDefined(block?.id, value.blockId, value.sectionId, context.blockId),
    blockName: firstDefined(localizedName(block), value.blockName, value.sectionName, context.blockName),
    areaId: firstDefined(area?.id, value.areaId, value.zoneId, context.areaId),
    areaName: firstDefined(localizedName(area), value.areaName, value.zoneName, context.areaName),
    categoryId: firstDefined(value.seatCategoryId, value.categoryId, category?.id, context.categoryId),
    categoryName: firstDefined(localizedName(category), value.seatCategoryName, value.categoryName, context.categoryName)
  };
  const row = firstDefined(value.row, value.rowName, value.rowLabel, value.seat?.row, value.place?.row, context.row);
  const seatNumber = firstDefined(value.number, value.seatNumber, value.seat?.number, value.place?.number);
  if (next.blockName && row != null && seatNumber != null) {
    out.push({
      blockId: next.blockId ?? null,
      blockName: String(next.blockName),
      row: String(row),
      seatNumber: String(seatNumber),
      categoryId: next.categoryId ?? "",
      categoryName: next.categoryName || "",
      areaId: next.areaId ?? null,
      areaName: next.areaName || ""
    });
  }

  for (const [key, child] of Object.entries(value)) {
    if (["geometry", "coordinates", "points", "path"].includes(key)) continue;
    const childContext = /row/i.test(key) && typeof child === "object" && !Array.isArray(child)
      ? { ...next, row: firstDefined(child.name, child.label, child.id, row) }
      : next;
    collectStadiumSeatRows(child, childContext, out, depth + 1);
  }
  return out;
}

async function ensureGame(url, fallback = {}) {
  const site = fallback.site || siteFromUrl(url);
  const performanceId =
    extractParam(url, "performanceId") ||
    extractParam(url, "perfId") ||
    String(url || "").match(/performance\/(\d+)/)?.[1] ||
    fallback.performanceId;
  const productId = extractParam(url, "productId") || fallback.productId;
  if (!performanceId) return null;

  const state = await getState();
  const key = gameKey(site, performanceId);
  if (!state.games[key]) state.games[key] = emptyGame(site, performanceId, productId);
  if (productId) state.games[key].productId = productId;
  if (fallback.match) {
    state.games[key].match = mergeMatch(state.games[key].match || {}, fallback.match);
  }
  if (fallback.productId && !state.games[key].productId) {
    state.games[key].productId = fallback.productId;
  }
  ensureStadiumCatalogScope(state.games[key], { ...fallback, productId, performanceId });
  return { state, key, game: state.games[key], site, performanceId, productId };
}

async function processPageInfo(message) {
  const ctx = await ensureGame(message.href || "", {
    site: siteFromUrl(message.href || ""),
    performanceId: message.performanceId,
    productId: message.productId,
    match: message.match
  });
  if (!ctx) return;
  ctx.game.lastUpdatedAt = new Date().toISOString();
  await saveState(ctx.state.games);
}

async function processAvailability(url, body) {
  if (!body?.priceRangeCategories) return;
  const ctx = await ensureGame(url);
  if (!ctx) return;

  let addedSections = 0;
  for (const c of body.priceRangeCategories) {
    const minPrices = marketPriceSet(ctx.site, c.minPrice);
    const maxPrices = marketPriceSet(ctx.site, c.maxPrice);
    const categoryName = normalizeCategoryName(c.name);
    ctx.game.categories[String(c.id)] = {
      id: String(c.id),
      name: categoryName,
      rank: c.rank ?? null,
      color: c.bgColor || c.color || null,
      minBuyerAllIn: minPrices.buyerAllInPrice,
      maxBuyerAllIn: maxPrices.buyerAllInPrice,
      minSellerList: minPrices.sellerListPrice,
      maxSellerList: maxPrices.sellerListPrice,
      minSellerNet: minPrices.estimatedSellerNet,
      maxSellerNet: maxPrices.estimatedSellerNet
    };
    for (const block of c.blocks || []) {
      if (upsertStadiumSection(ctx.game, {
        blockId: block.id,
        blockName: localizedName(block),
        categoryId: c.id,
        categoryName,
        color: c.bgColor || c.color || null
      }, "availability")) {
        addedSections++;
      }
    }
  }
  updateParseDiagnostics(ctx.game, {
    lastPayloadAt: new Date().toISOString(),
    lastStadiumSectionPayloadCount: addedSections
  });
  ctx.game.lastUpdatedAt = new Date().toISOString();
  await saveState(ctx.state.games);
}

async function processMatch(url, body) {
  const product = body?.ecommerceViewProduct;
  if (!product) return;
  const ctx = await ensureGame(url);
  if (!ctx) return;
  ctx.game.match = mergeMatch(ctx.game.match || {}, {
    name: product.name || "",
    date: product.date || "",
    currency: product.currency || "USD",
    imgUrl: product.imgUrl || ""
  });
  ctx.game.lastUpdatedAt = new Date().toISOString();
  await saveState(ctx.state.games);
}

function fallbackSeatId(p, fallbackIndex, feature = {}) {
  const parts = [
    feature.id,
    p.id,
    p.seatId,
    p.seat?.id,
    p.placeId,
    p.resaleMovementId,
    p.movementId,
    p.block?.id,
    p.blockId,
    p.block?.name?.en || p.block?.name || p.block,
    p.blockName,
    p.place?.block,
    p.place?.section,
    p.row,
    p.rowName,
    p.seat?.row,
    p.place?.row,
    p.number,
    p.seatNumber,
    p.seat?.number,
    p.place?.number,
    p.seatCategoryId ?? p.categoryId ?? p.seatCategory?.id ?? p.category?.id,
    rawAmountFromProperties(p),
    fallbackIndex
  ].filter((v) => v != null && v !== "");
  return parts.map((v) => String(v).replace(/\s+/g, "_")).join(":");
}

function currentScrapeMeta(game, fallback = {}) {
  return {
    scrapeId: fallback.scanId || game.currentScrape?.scrapeId || game.scanProgress?.scanId || null,
    scrapeStartedAt: fallback.scrapeStartedAt || fallback.startedAt || game.currentScrape?.startedAt || null
  };
}

function storeFeatureSeat(game, performanceId, productId, feature, fallbackIndex, meta = {}) {
  const p = feature.properties || feature || {};
  const seatId = fallbackSeatId(p, fallbackIndex, feature);
  if (!seatId) return false;
  const now = new Date().toISOString();
  const scrape = currentScrapeMeta(game, meta);

  const rawPrice = rawAmountFromProperties(p);
  const prices = marketPriceSet(game.site, rawPrice);
  const categoryIdValue = firstDefined(p.seatCategoryId, p.categoryId, p.seatCategory?.id, p.category?.id);
  const categoryId = categoryIdValue != null ? String(categoryIdValue) : "";
  const category = game.categories[categoryId];
  const buyerAllIn = prices.buyerAllInPrice ?? category?.minBuyerAllIn ?? null;
  const block = p.block || p.section || p.logicalBlock || p.physicalBlock || p.place?.block || p.place?.section || {};
  const categoryName = localizedName(p.seatCategory) || localizedName(p.category) || category?.name || "";
  const area = p.area || p.zone || {};
  const mapPoint = firstCoordinate(feature.geometry?.coordinates);

  game.seats[seatId] = {
    seatId,
    sourceFeatureId: p.id ?? p.seatId ?? feature.id ?? null,
    mapGeometryType: feature.geometry?.type || "",
    mapPointX: mapPoint?.[0] ?? null,
    mapPointY: mapPoint?.[1] ?? null,
    capturedAt: now,
    scrapedAt: now,
    scrapeId: scrape.scrapeId,
    scrapeStartedAt: scrape.scrapeStartedAt,
    productId: game.productId || productId || null,
    performanceId,
    categoryId,
    categoryName,
    areaId: area?.id ?? p.areaId ?? p.zoneId ?? null,
    areaName: localizedName(area),
    blockId: block?.id ?? p.blockId ?? p.sectionId ?? null,
    blockName: localizedName(block) || p.blockName || p.sectionName || "",
    row: firstDefined(p.row, p.rowName, p.rowLabel, p.seat?.row, p.place?.row, p.placeRow, ""),
    seatNumber: firstDefined(p.number, p.seatNumber, p.seat?.number, p.place?.number, p.placeNumber, ""),
    sellerListPrice: prices.sellerListPrice,
    buyerAllInPrice: buyerAllIn,
    estimatedSellerListPrice: prices.sellerListPrice,
    estimatedSellerNet: prices.estimatedSellerNet,
    tariffId: p.tariffId ?? p.tariff?.id ?? null,
    advantageId: p.advantageId ?? p.advantage?.id ?? null,
    movementId: p.movementId ?? null,
    resaleMovementId: p.resaleMovementId ?? null,
    contingentId: p.contingentId ?? null,
    exclusive: p.exclusive !== false,
    seatQuality: p.seatQuality ?? null,
    seatType: p.resaleMovementId ? "resale" : (rawPrice != null ? "face_value" : "unknown")
  };
  upsertStadiumSeat(game, game.seats[seatId], "market_observed", fallbackIndex);
  return true;
}

function storeSeatRow(game, performanceId, productId, row, fallbackIndex, meta = {}) {
  if (!row) return false;
  const hasStableIdentity = row.sourceFeatureId || row.resaleMovementId || row.movementId;
  const seatId = [
    row.sourceFeatureId,
    row.resaleMovementId,
    row.blockId,
    row.blockName,
    row.row,
    row.seatNumber,
    row.categoryId,
    row.sellerListPrice,
    hasStableIdentity ? "" : fallbackIndex
  ].filter((value) => value != null && value !== "").map((value) => String(value).replace(/\s+/g, "_")).join(":");
  if (!seatId) return false;
  const now = new Date().toISOString();
  const scrape = currentScrapeMeta(game, meta);
  game.seats[seatId] = {
    seatId,
    sourceFeatureId: row.sourceFeatureId ?? null,
    mapGeometryType: row.mapGeometryType || "",
    mapPointX: row.mapPointX ?? null,
    mapPointY: row.mapPointY ?? null,
    capturedAt: now,
    scrapedAt: now,
    scrapeId: scrape.scrapeId,
    scrapeStartedAt: scrape.scrapeStartedAt,
    productId: game.productId || productId || null,
    performanceId,
    categoryId: row.categoryId != null ? String(row.categoryId) : "",
    categoryName: row.categoryName || "",
    areaId: row.areaId ?? null,
    areaName: row.areaName || "",
    blockId: row.blockId ?? null,
    blockName: row.blockName || "",
    row: row.row || "",
    seatNumber: row.seatNumber || "",
    sellerListPrice: row.sellerListPrice ?? null,
    buyerAllInPrice: row.buyerAllInPrice ?? null,
    estimatedSellerListPrice: row.sellerListPrice ?? null,
    estimatedSellerNet: row.estimatedSellerNet ?? null,
    tariffId: row.tariffId ?? null,
    advantageId: row.advantageId ?? null,
    movementId: row.movementId ?? null,
    resaleMovementId: row.resaleMovementId ?? null,
    contingentId: row.contingentId ?? null,
    exclusive: row.exclusive !== false,
    seatQuality: row.seatQuality ?? null,
    seatType: row.resaleMovementId ? "resale" : (row.sellerListPrice != null ? "face_value" : "unknown")
  };
  upsertStadiumSeat(game, game.seats[seatId], "market_observed", fallbackIndex);
  return true;
}

async function processSeatmapConfig(url, body, meta = {}) {
  if (!body || typeof body !== "object") return;
  const ctx = await ensureGame(url, {
    productId: meta.productId,
    performanceId: meta.performanceId,
    match: meta.match
  });
  if (!ctx) return;
  const rows = collectStadiumSeatRows(body);
  let added = 0;
  for (let index = 0; index < rows.length; index++) {
    if (upsertStadiumSeat(ctx.game, rows[index], "seatmap_config", index)) added++;
  }
  if (added > 0) {
    updateParseDiagnostics(ctx.game, {
      lastPayloadAt: new Date().toISOString(),
      lastStadiumCatalogPayloadCount: rows.length
    });
    ctx.game.lastUpdatedAt = new Date().toISOString();
    await saveState(ctx.state.games);
  }
}

async function processSeats(url, body, meta = {}) {
  const features = extractSeatFeaturesFromPayload(body);
  if (!features.length) return;
  const ctx = await ensureGame(url, {
    productId: meta.productId,
    performanceId: meta.performanceId,
    match: meta.match
  });
  if (!ctx) return;

  ctx.game.rawFeaturesSeen = (ctx.game.rawFeaturesSeen || 0) + features.length;
  updateParseDiagnostics(ctx.game, {
    apiResponses: (ctx.game.parseDiagnostics?.apiResponses || 0) + 1,
    lastFeaturePayloadCount: features.length,
    lastPayloadAt: new Date().toISOString(),
    lastFeatureSample: features[0] ? JSON.stringify(features[0]).slice(0, 1200) : null
  });
  ctx.game.tileStats = ctx.game.tileStats || [];
  if (meta.bbox || meta.featureCount != null) {
    ctx.game.tileStats.push({
      scanId: meta.scanId || null,
      bbox: meta.bbox || null,
      tileIndex: meta.tileIndex ?? null,
      featureCount: meta.featureCount ?? features.length,
      capturedAt: new Date().toISOString()
    });
    if (ctx.game.tileStats.length > MAX_TILE_STATS_PER_GAME) {
      ctx.game.tileStats = ctx.game.tileStats.slice(-MAX_TILE_STATS_PER_GAME);
    }
  }

  for (let index = 0; index < features.length; index++) {
    const feature = features[index];
    storeFeatureSeat(ctx.game, ctx.performanceId, ctx.productId, feature, index, meta);
  }
  updateParseDiagnostics(ctx.game);
  ctx.game.lastUpdatedAt = new Date().toISOString();
  await saveState(ctx.state.games);
}

async function processScanResult(message, url = "") {
  const ctx = await ensureGame(url || message.url || "", {
    site: message.site || siteFromUrl(url || message.url || ""),
    productId: message.productId,
    performanceId: message.performanceId,
    match: message.match
  });
  if (!ctx) return;
  let aggregateSeatRows = [];
  if (message.seatsJson) {
    try {
      aggregateSeatRows = JSON.parse(message.seatsJson);
    } catch {
      aggregateSeatRows = [];
    }
  }
  let aggregateFeatures = Array.isArray(message.features) ? message.features : [];
  if (message.featuresJson) {
    try {
      aggregateFeatures = JSON.parse(message.featuresJson);
    } catch {
      aggregateFeatures = [];
    }
  }
  updateParseDiagnostics(ctx.game, {
    scanResults: (ctx.game.parseDiagnostics?.scanResults || 0) + 1,
    lastScanResultFeatureCount: aggregateSeatRows.length || aggregateFeatures.length,
    lastPayloadAt: new Date().toISOString(),
    lastFeatureSample: (aggregateSeatRows[0] || aggregateFeatures[0])
      ? JSON.stringify(aggregateSeatRows[0] || aggregateFeatures[0]).slice(0, 1200)
      : ctx.game.parseDiagnostics?.lastFeatureSample || null
  });
  if (aggregateSeatRows.length > 0 || aggregateFeatures.length > 0) ctx.game.seats = {};
  if (message.scanId && !ctx.game.currentScrape?.scrapeId) {
    ctx.game.currentScrape = {
      scrapeId: message.scanId,
      startedAt: new Date().toISOString()
    };
  }
  ctx.game.rawFeaturesSeen = message.rawFeaturesSeen || message.features?.length || 0;
  ctx.game.tileStats = message.tileStats || [];
  if (message.match) {
    ctx.game.match = {
      ...(ctx.game.match || {}),
      name: `${message.match.home || ""} vs ${message.match.away || ""}`.trim(),
      date: message.match.date || ctx.game.match?.date || "",
      time: message.match.time || ctx.game.match?.time || "",
      venue: message.match.venue || ctx.game.match?.venue || "",
      matchCode: message.match.matchCode || ctx.game.match?.matchCode || ""
    };
  }
  if (aggregateSeatRows.length > 0) {
    for (let index = 0; index < aggregateSeatRows.length; index++) {
      storeSeatRow(ctx.game, ctx.performanceId, ctx.productId, aggregateSeatRows[index], `result-${index}`, { scanId: message.scanId });
    }
  } else {
    for (let index = 0; index < aggregateFeatures.length; index++) {
      storeFeatureSeat(ctx.game, ctx.performanceId, ctx.productId, aggregateFeatures[index], index, { scanId: message.scanId });
    }
  }
  updateParseDiagnostics(ctx.game);
  createVelocity(ctx.game);
  ctx.game.scanProgress = {
    ...(ctx.game.scanProgress || {}),
    status: message.status || ctx.game.scanProgress?.status || "done",
    completed: message.completed ?? ctx.game.scanProgress?.completed ?? null,
    total: message.total ?? ctx.game.scanProgress?.total ?? null,
    found: message.found ?? ctx.game.scanProgress?.found ?? null,
    attemptedTiles: message.attemptedTiles ?? ctx.game.scanProgress?.attemptedTiles ?? null,
    successfulTiles: message.successfulTiles ?? ctx.game.scanProgress?.successfulTiles ?? null,
    blockedTiles: message.blockedTiles ?? ctx.game.scanProgress?.blockedTiles ?? null,
    updatedAt: new Date().toISOString()
  };
  ctx.game.lastUpdatedAt = new Date().toISOString();
  await saveState(ctx.state.games);
  await maybeShareFinishedScan(ctx, message);
}

function createVelocity(game) {
  const currentSeats = Object.values(game.seats || {});
  const previous = game.snapshots?.[game.snapshots.length - 1] || null;
  const scrapeId = game.currentScrape?.scrapeId || game.scanProgress?.scanId || null;
  if (
    previous?.scrapeId &&
    scrapeId &&
    previous.scrapeId === scrapeId &&
    previous.seatCount === currentSeats.length &&
    snapshotSeatFingerprint(previous.seats || []) === snapshotSeatFingerprint(currentSeats)
  ) {
    game.velocity = {
      ...(game.velocity || {}),
      currentSnapshotId: previous.snapshotId,
      capturedAt: previous.capturedAt,
      currentSeatCount: previous.seatCount
    };
    return previous;
  }
  const currentMap = Object.fromEntries(currentSeats.map((seat) => [seat.seatId, seat]));
  const previousMap = Object.fromEntries((previous?.seats || []).map((seat) => [seat.seatId, seat]));
  const newlyListed = [];
  const disappeared = [];
  const repriced = [];
  const stillListed = [];

  for (const seat of currentSeats) {
    const old = previousMap[seat.seatId];
    if (!old) {
      newlyListed.push(seat.seatId);
    } else if (Number(old.sellerListPrice) !== Number(seat.sellerListPrice)) {
      repriced.push({
        seatId: seat.seatId,
        fromSellerList: old.sellerListPrice,
        toSellerList: seat.sellerListPrice
      });
    } else {
      stillListed.push(seat.seatId);
    }
  }
  for (const old of previous?.seats || []) {
    if (!currentMap[old.seatId]) disappeared.push(old.seatId);
  }

  const snapshotCapturedAt = new Date().toISOString();
  const snapshot = {
    snapshotId: `${game.performanceId}-${Date.now()}`,
    scrapeId,
    capturedAt: snapshotCapturedAt,
    seatCount: currentSeats.length,
    rawFeaturesSeen: game.rawFeaturesSeen || 0,
    seats: currentSeats.map((seat) => ({
      seatId: seat.seatId,
      blockName: seat.blockName,
      row: seat.row,
      seatNumber: seat.seatNumber,
      categoryId: seat.categoryId,
      categoryName: seat.categoryName,
      scrapedAt: seat.scrapedAt || seat.capturedAt || snapshotCapturedAt,
      scrapeId: seat.scrapeId || scrapeId,
      sellerListPrice: seat.sellerListPrice,
      buyerAllInPrice: seat.buyerAllInPrice,
      estimatedSellerNet: seat.estimatedSellerNet,
      resaleMovementId: seat.resaleMovementId
    }))
  };
  game.velocity = {
    previousSnapshotId: previous?.snapshotId || null,
    currentSnapshotId: snapshot.snapshotId,
    capturedAt: snapshot.capturedAt,
    currentSeatCount: currentSeats.length,
    previousSeatCount: previous?.seatCount ?? null,
    newlyListedCount: newlyListed.length,
    disappearedCount: disappeared.length,
    repricedCount: repriced.length,
    stillListedCount: stillListed.length,
    newlyListed,
    disappeared,
    repriced
  };
  game.snapshots = [...(game.snapshots || []), snapshot].slice(-MAX_LOCAL_SNAPSHOTS_PER_GAME);
  return snapshot;
}

function parseSeatRowsFromMessage(message) {
  if (!message?.seatsJson) return [];
  try {
    const rows = JSON.parse(message.seatsJson);
    return Array.isArray(rows) ? rows : [];
  } catch {
    return [];
  }
}

function storeSeatRowsPayload(ctx, message, seatRows) {
  if (!ctx || !seatRows.length) return 0;
  const now = new Date().toISOString();
  const batchKey = [
    message.scanId || "",
    message.bbox || "",
    message.tileIndex ?? "",
    message.chunkIndex ?? "",
    message.chunkCount ?? "",
    message.featureCount ?? seatRows.length
  ].join("|");
  ctx.game.tileStats = ctx.game.tileStats || [];
  if (batchKey && ctx.game.tileStats.some((tile) => tile.batchKey === batchKey)) return 0;
  updateParseDiagnostics(ctx.game, {
    apiResponses: (ctx.game.parseDiagnostics?.apiResponses || 0) + 1,
    lastFeaturePayloadCount: seatRows.length,
    lastPayloadAt: now,
    lastFeatureSample: seatRows[0] ? JSON.stringify(seatRows[0]).slice(0, 1200) : null,
    contentVersion: message.contentVersion || ctx.game.parseDiagnostics?.contentVersion || null,
    injectedVersion: message.injectedVersion || ctx.game.parseDiagnostics?.injectedVersion || null
  });
  ctx.game.tileStats.push({
    batchKey,
    scanId: message.scanId || null,
    bbox: message.bbox || null,
    tileIndex: message.tileIndex ?? null,
    chunkIndex: message.chunkIndex ?? null,
    chunkCount: message.chunkCount ?? null,
    featureCount: message.featureCount ?? seatRows.length,
    storedRows: seatRows.length,
    via: message.kind || (message.seatBatch ? "scan-progress" : null),
    capturedAt: now
  });
  for (let index = 0; index < seatRows.length; index++) {
    storeSeatRow(ctx.game, ctx.performanceId, ctx.productId, seatRows[index], `${message.tileIndex ?? "tile"}-${index}`, { scanId: message.scanId });
  }
  ctx.game.rawFeaturesSeen = Object.keys(ctx.game.seats || {}).length;
  updateParseDiagnostics(ctx.game);
  ctx.game.lastUpdatedAt = now;
  return seatRows.length;
}

async function processScanProgress(url, message) {
  const ctx = await ensureGame(url || "", {
    performanceId: message.performanceId,
    productId: message.productId
  });
  if (!ctx) return;
  if (message.status === "started" && message.reset) {
    const startedAt = new Date().toISOString();
    ctx.game.currentScrape = {
      scrapeId: message.scanId || `${ctx.performanceId}-${Date.now()}`,
      startedAt
    };
    ctx.game.seats = {};
    ctx.game.tileStats = [];
    ctx.game.rawFeaturesSeen = 0;
    ctx.game.parseDiagnostics = {
      apiResponses: 0,
      scanResults: 0,
      lastFeaturePayloadCount: 0,
      lastScanResultFeatureCount: 0,
      parsedSeatCount: 0,
      parsedStadiumSectionCount: Object.keys(ctx.game.stadiumSections || {}).length,
      parsedStadiumSeatCount: Object.keys(ctx.game.stadiumSeats || {}).length,
      lastPayloadAt: null,
      lastFeatureSample: null,
      contentVersion: message.contentVersion || null,
      injectedVersion: message.injectedVersion || null
    };
    if (message.match) {
      ctx.game.match = {
        ...(ctx.game.match || {}),
        name: `${message.match.home || ""} vs ${message.match.away || ""}`.trim(),
        date: message.match.date || ctx.game.match?.date || "",
        time: message.match.time || ctx.game.match?.time || "",
        venue: message.match.venue || ctx.game.match?.venue || "",
        matchCode: message.match.matchCode || ctx.game.match?.matchCode || ""
      };
    }
  }
  const seatRows = parseSeatRowsFromMessage(message);
  if (seatRows.length) {
    storeSeatRowsPayload(ctx, message, seatRows);
  }
  ctx.game.scanProgress = {
    status: message.status,
    completed: message.completed ?? null,
    total: message.total ?? null,
    found: message.found ?? null,
    tileSize: message.tileSize ?? ctx.game.scanProgress?.tileSize ?? null,
    tileWidth: message.tileWidth ?? ctx.game.scanProgress?.tileWidth ?? null,
    tileHeight: message.tileHeight ?? ctx.game.scanProgress?.tileHeight ?? null,
    stepX: message.stepX ?? ctx.game.scanProgress?.stepX ?? null,
    stepY: message.stepY ?? ctx.game.scanProgress?.stepY ?? null,
    mapMax: message.mapMax ?? ctx.game.scanProgress?.mapMax ?? null,
    httpStatus: message.httpStatus ?? ctx.game.scanProgress?.httpStatus ?? null,
    bbox: message.bbox ?? ctx.game.scanProgress?.bbox ?? null,
    stage: message.stage ?? ctx.game.scanProgress?.stage ?? null,
    message: message.message ?? ctx.game.scanProgress?.message ?? null,
    stopReason: message.stopReason ?? ctx.game.scanProgress?.stopReason ?? null,
    final: message.final ?? ctx.game.scanProgress?.final ?? null,
    attemptedTiles: message.attemptedTiles ?? ctx.game.scanProgress?.attemptedTiles ?? null,
    successfulTiles: message.successfulTiles ?? ctx.game.scanProgress?.successfulTiles ?? null,
    blockedTiles: message.blockedTiles ?? ctx.game.scanProgress?.blockedTiles ?? null,
    timedOutTiles: message.timedOutTiles ?? ctx.game.scanProgress?.timedOutTiles ?? null,
    errorTiles: message.errorTiles ?? ctx.game.scanProgress?.errorTiles ?? null,
    scanId: message.scanId ?? ctx.game.scanProgress?.scanId ?? null,
    retryAfterMs: message.retryAfterMs ?? null,
    headerDiagnostics: message.headerDiagnostics ?? ctx.game.scanProgress?.headerDiagnostics ?? null,
    contentVersion: message.contentVersion ?? ctx.game.scanProgress?.contentVersion ?? null,
    injectedVersion: message.injectedVersion ?? ctx.game.scanProgress?.injectedVersion ?? null,
    updatedAt: new Date().toISOString()
  };
  await saveState(ctx.state.games);
  await maybeShareFinishedScan(ctx, message);
}

async function processDiscoveredMatches(message) {
  const discoveredMatches = {
    href: message.href,
    site: siteFromUrl(message.href || ""),
    start: message.start,
    end: message.end,
    days: message.days,
    productId: message.productId,
    matches: (message.matches || []).map((match) => ({
      ...match,
      site: match.site || siteFromUrl(message.href || "")
    })),
    capturedAt: new Date().toISOString()
  };
  await saveDiscoveredMatches(discoveredMatches);
}

async function processMultiScanProgress(message) {
  const state = await getState();
  const multiScan = {
    ...(state.multiScan || {}),
    status: message.status,
    multiScanId: message.multiScanId ?? state.multiScan?.multiScanId ?? null,
    completedMatches: message.completedMatches ?? state.multiScan?.completedMatches ?? 0,
    totalMatches: message.totalMatches ?? state.multiScan?.totalMatches ?? 0,
    currentMatch: message.match ?? state.multiScan?.currentMatch ?? null,
    updatedAt: new Date().toISOString()
  };
  await saveMultiScan(multiScan);
}

function isTelemetryMessage(message) {
  return (
    message?.type === "FIFA_SELLER_SCOUT_PAGE_INFO" ||
    message?.type === "FIFA_SELLER_SCOUT_MATCHES_DISCOVERED" ||
    message?.type === "FIFA_SELLER_SCOUT_FIND_SEAT_RESULT" ||
    message?.kind === "api-response" ||
    message?.kind === "seat-batch" ||
    message?.kind === "scan-progress" ||
    message?.kind === "scan-result" ||
    message?.kind === "multi-scan-progress"
  );
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!isTelemetryMessage(message)) return false;
  (async () => {
    const tabUrl = sender.tab?.url || "";
    const url = message.url || tabUrl;
    if (message.type === "FIFA_SELLER_SCOUT_PAGE_INFO") {
      await processPageInfo(message);
    }
    if (message.type === "FIFA_SELLER_SCOUT_MATCHES_DISCOVERED") {
      await processDiscoveredMatches(message);
    }
    if (message.kind === "api-response") {
      const meta = {
        ...(message.meta || {}),
        site: message.meta?.site || siteFromUrl(tabUrl || url),
        productId: message.meta?.productId || extractParam(tabUrl, "productId") || null,
        performanceId: message.meta?.performanceId || String(tabUrl || "").match(/performance\/(\d+)/)?.[1] || null
      };
      if (url.includes("seatmap/availability")) await processAvailability(url, message.body, meta);
      if (url.includes("google-ecommerce-detail")) await processMatch(url, message.body, meta);
      if (url.includes("seatmap/config")) await processSeatmapConfig(url, message.body, meta);
      if (url.includes("/seatmap/") && !url.includes("seatmap/availability") && !url.includes("google-ecommerce-detail") && !url.includes("seatmap/config")) {
        await processSeats(url, message.body, meta);
      }
    }
    if (message.kind === "seat-batch") {
      const seatRows = parseSeatRowsFromMessage(message);
      if (seatRows.length) {
        const ctx = await ensureGame(message.url || url, {
          productId: message.productId,
          performanceId: message.performanceId,
          match: message.match
        });
        if (ctx) {
          storeSeatRowsPayload(ctx, message, seatRows);
          await saveState(ctx.state.games);
          sendResponse({ ok: true });
          return;
        }
      }
      let features = message.features || [];
      if (message.featuresJson) {
        try {
          features = JSON.parse(message.featuresJson);
        } catch {
          features = [];
        }
      }
      await processSeats(message.url || url, { features }, {
        productId: message.productId,
        performanceId: message.performanceId,
        match: message.match,
        scanId: message.scanId,
        multiScanId: message.multiScanId,
        bbox: message.bbox,
        tileIndex: message.tileIndex,
        featureCount: message.featureCount
      });
    }
    if (message.kind === "scan-progress") {
      await processScanProgress(sender.tab?.url || url, message);
    }
    if (message.kind === "scan-result") {
      await processScanResult(message, sender.tab?.url || url);
    }
    if (message.kind === "multi-scan-progress") {
      await processMultiScanProgress(message);
    }
    sendResponse({ ok: true });
  })().catch((error) => {
    sendResponse({ ok: false, error: String(error?.message || error || "message failed") });
  });
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FIFA_SELLER_SCOUT_GET_STATE") {
    (async () => {
      if (message.skipActiveRefresh !== true) await refreshActiveSeatMapState();
      sendResponse(await getState());
    })().catch(async () => {
      sendResponse(await getState());
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_ACTIVE_GAME_CONTEXT") {
    activeSeatMapContext()
      .then((context) => sendResponse(context))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error || "Could not read active game") }));
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_GET_CROWD_SETTINGS") {
    crowdSettings().then((settings) => sendResponse({
      enabled: settings.enabled,
      lastSync: settings.lastSync,
      contributorPass: settings.contributorPass
    }));
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_SET_CROWD_SHARING") {
    chrome.storage.local.set({ [CROWD_SHARE_ENABLED_KEY]: message.enabled === true }, () => {
      sendResponse({ ok: true, enabled: message.enabled === true });
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_SHARE_CROWD_NOW") {
    (async () => {
      const state = await getState();
      const games = Object.values(state.games || {});
      const game = message.performanceId
        ? games.find((item) => String(item.performanceId) === String(message.performanceId))
        : games.sort((a, b) => new Date(b.lastUpdatedAt || 0) - new Date(a.lastUpdatedAt || 0))[0];
      const result = await shareCrowdSnapshot(game, { force: message.force === true });
      if (result && !result.ok && result.skipped) {
        await recordCrowdSkip(result.reason || result.error || "Could not share", game?.snapshots?.[game.snapshots.length - 1]?.snapshotId || null);
      }
      await saveState(state.games);
      sendResponse(result);
    })().catch((error) => {
      const message = String(error?.message || error || "share failed");
      recordCrowdSkip(message).finally(() => sendResponse({ ok: false, error: message }));
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_DIRECT_LISTINGS") {
    (async () => {
      const performanceId = String(message.performanceId || "").trim();
      if (!performanceId) {
        sendResponse({ ok: false, error: "Open a game first" });
        return;
      }
      const url = `${DIRECT_LISTINGS_API_URL}?performanceId=${encodeURIComponent(performanceId)}`;
      sendResponse(await directApi(url, { method: "GET" }));
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error || "Could not load Direct Match") }));
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_DIRECT_POST") {
    (async () => {
      const game = message.game || {};
      const activeContext = await activeSeatMapContext();
      const activeSite = activeContext.site || "fifa_resale";
      const postedSite = game.site || "fifa_resale";
      if (
        !activeContext.ok ||
        String(activeContext.performanceId || "") !== String(game.performanceId || "") ||
        activeSite !== postedSite
      ) {
        sendResponse({ ok: false, error: "You switched games. Check prices on this game, then add the seats again." });
        return;
      }
      const seat = message.seat || {};
      const seats = Array.isArray(message.seats) && message.seats.length ? message.seats : [seat];
      const payload = {
        source: activeSite,
        performanceId: activeContext.performanceId,
        productId: game.productId || activeContext.productId || "",
        sellerEmail: message.sellerEmail,
        askPrice: message.askPrice,
        match: {
          name: crowdMatchName(game.match || {}),
          date: game.match?.date || "",
          time: game.match?.time || "",
          venue: game.match?.venue || game.match?.stadium || "",
          currency: game.match?.currency || "USD"
        },
        seat: directMatchSeatPayload(seat),
        seats: seats.map(directMatchSeatPayload)
      };
      sendResponse(await directApi(DIRECT_LISTINGS_API_URL, {
        method: "POST",
        body: JSON.stringify(payload)
      }));
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error || "Could not post Direct Match seat") }));
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_DIRECT_LEAD") {
    (async () => {
      sendResponse(await directApi(DIRECT_LEADS_API_URL, {
        method: "POST",
        body: JSON.stringify({
          listingId: message.listingId,
          buyerEmail: message.buyerEmail,
          message: message.message || ""
        })
      }));
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error || "Could not send interest") }));
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_DELETE_GAME") {
    (async () => {
      const state = await getState();
      if (message.gameKey && state.games[message.gameKey]) {
        delete state.games[message.gameKey];
      } else if (message.performanceId) {
        for (const [key, game] of Object.entries(state.games || {})) {
          if (String(game.performanceId) === String(message.performanceId)) delete state.games[key];
        }
      }
      await chrome.storage.local.set({ games: state.games });
      sendResponse({ ok: true, games: Object.keys(state.games).length });
    })();
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_SCAN_ACTIVE_TAB") {
    (async () => {
      const tab = await findSeatMapTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "Open a FIFA seat-map page first" });
        return;
      }
      await ensureInjected(tab.id);
      const pageInfo = await chrome.tabs.sendMessage(tab.id, { type: "FIFA_SELLER_SCOUT_READ_PAGE" }).catch(() => null);
      if (pageInfo?.type === "FIFA_SELLER_SCOUT_PAGE_INFO") await processPageInfo(pageInfo);
      const performanceId = String(tab.url || "").match(/performance\/(\d+)/)?.[1];
      const site = siteFromUrl(tab.url || "");
      const state = await getState();
      const matching = Object.values(state.games).find((g) => g.performanceId === performanceId && g.site === site);
      const productId =
        pageInfo?.productId ||
        extractParam(tab.url, "productId") ||
        matching?.productId ||
        message.productId;
      if (!productId || !performanceId) {
        sendResponse({ ok: false, error: "Open a FIFA seat-map page first" });
        return;
      }
      const incomingScanConfig = message.scanConfig || {};
      const testMode = incomingScanConfig.testMode === true;
      chrome.tabs.sendMessage(tab.id, {
        type: "FIFA_SELLER_SCOUT_SCAN_ALL",
        productId,
        performanceId,
        scanConfig: {
          tileWidth: 10000,
          tileHeight: 5000,
          stepX: 10000,
          stepY: 5000,
          mapMax: 60000,
          delayMs: testMode ? 700 : 2000,
          maxConsecutiveBlocks: testMode ? 2 : 1,
          reset: true,
          isExclusive: false,
          ...incomingScanConfig
        }
      });
      sendResponse({ ok: true, productId, performanceId });
    })();
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_OPEN_GAME") {
    (async () => {
      const performanceId = message.performanceId;
      if (!performanceId) {
        sendResponse({ ok: false, error: "No game selected" });
        return;
      }
      const site = message.site || "";
      const productId = message.productId || "";
      let tab = await findSeatMapTabByMarket(performanceId, site);
      if (!tab?.id) {
        tab = await chrome.tabs.create({ url: marketSeatMapUrl(performanceId, site, productId), active: true });
      } else {
        await chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
      }
      sendResponse({ ok: true, performanceId, tabId: tab.id });
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error || "Could not open game") });
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_OPEN_RESALE") {
    (async () => {
      const tabs = await queryTabs({ url: "*://fwc26-resale-usd.tickets.fifa.com/*" });
      const tab = tabs[0];
      if (tab?.id) {
        await chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
        sendResponse({ ok: true, tabId: tab.id, reused: true });
        return;
      }
      const created = await chrome.tabs.create({ url: fifaResaleStartUrl(), active: true });
      sendResponse({ ok: true, tabId: created.id, reused: false });
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error || "Could not open FIFA Resale") });
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_OPEN_PRIMARY") {
    (async () => {
      const tabs = await queryTabs({ url: "*://fwc26-shop-usd.tickets.fifa.com/*" });
      const tab = tabs[0];
      if (tab?.id) {
        await chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
        sendResponse({ ok: true, tabId: tab.id, reused: true });
        return;
      }
      const created = await chrome.tabs.create({ url: fifaPrimaryStartUrl(), active: true });
      sendResponse({ ok: true, tabId: created.id, reused: false });
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error || "Could not open FIFA Primary") });
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_FIND_SEAT_ON_MAP") {
    (async () => {
      const target = message.target || {};
      const performanceId = target.performanceId || message.performanceId;
      if (!performanceId) {
        sendResponse({ ok: false, error: "No game found for this seat" });
        return;
      }
      const site = target.site || message.site || "";
      const productId = target.productId || message.productId || "";
      let tab = await findSeatMapTabByMarket(performanceId, site);
      if (!tab?.id) {
        tab = await chrome.tabs.create({ url: marketSeatMapUrl(performanceId, site, productId), active: true });
      } else {
        await chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
      }
      await ensureInjected(tab.id);
      await chrome.tabs.sendMessage(tab.id, {
        type: "FIFA_SELLER_SCOUT_FIND_SEAT",
        target
      }).catch(() => null);
      sendResponse({ ok: true, performanceId, mode: "guided" });
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error || "Could not find seat") });
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_DISCOVER_ACTIVE_TAB") {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab" });
        return;
      }
      await ensureInjected(tab.id);
      await chrome.tabs.sendMessage(tab.id, {
        type: "FIFA_SELLER_SCOUT_DISCOVER_MATCHES",
        days: message.days || 7
      }).catch(() => {});
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message?.type === "FIFA_SELLER_SCOUT_SCAN_DISCOVERED") {
    (async () => {
      const state = await getState();
      const site = state.discoveredMatches?.site || siteFromUrl(state.discoveredMatches?.href || "");
      const tab = await findSeatMapTab(site);
      if (!tab?.id) {
        sendResponse({ ok: false, error: site === "fifa_primary" ? "Open any FIFA Primary seat-map page first" : "Open any FIFA seat-map page first" });
        return;
      }
      await ensureInjected(tab.id);
      const matches = state.discoveredMatches?.matches || [];
      const productId = state.discoveredMatches?.productId || message.productId;
      if (!productId || matches.length === 0) {
        sendResponse({ ok: false, error: "Discover matches first" });
        return;
      }
      if (!String(tab.url || "").includes("/selection/event/seat/performance/")) {
        sendResponse({ ok: false, error: "Open any FIFA seat-map page first" });
        return;
      }
      await saveMultiScan({
        status: "queued",
        completedMatches: 0,
        totalMatches: matches.length,
        updatedAt: new Date().toISOString()
      });
      const incomingScanConfig = message.scanConfig || {};
      const testMode = incomingScanConfig.testMode === true;
      chrome.tabs.sendMessage(tab.id, {
        type: "FIFA_SELLER_SCOUT_SCAN_MATCHES",
        productId,
        matches,
        scanConfig: {
          tileWidth: 10000,
          tileHeight: 5000,
          stepX: 10000,
          stepY: 5000,
          mapMax: 40000,
          delayMs: testMode ? 700 : 2000,
          matchDelayMs: testMode ? 1500 : 3000,
          maxConsecutiveBlocks: testMode ? 2 : 1,
          reset: true,
          isExclusive: false,
          ...incomingScanConfig
        }
      });
      sendResponse({ ok: true, productId, matches: matches.length });
    })();
    return true;
  }
});
