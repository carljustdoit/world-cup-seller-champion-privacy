{
  const CONTENT_VERSION = "0.4.148";
  window.__fifaSellerScoutContentLoaded = true;
  window.__fifaSellerScoutContentVersion = CONTENT_VERSION;

  let extensionContextAlive = true;
  const MAX_RUNTIME_QUEUE = 500;
  const runtimeQueue = [];
  let runtimeQueueActive = false;

  function pumpRuntimeQueue() {
    if (runtimeQueueActive || !extensionContextAlive) return;
    const message = runtimeQueue.shift();
    if (!message) return;
    runtimeQueueActive = true;
    let settled = false;
    const finish = (retryDelay = null) => {
      if (settled) return;
      settled = true;
      runtimeQueueActive = false;
      setTimeout(pumpRuntimeQueue, retryDelay ?? (message.seatsJson ? 20 : 0));
    };
    try {
      if (!chrome?.runtime?.id) {
        extensionContextAlive = false;
        runtimeQueue.length = 0;
        finish();
        return;
      }
      const watchdog = setTimeout(() => {
        message.__fssAttempts = Number(message.__fssAttempts || 0) + 1;
        runtimeQueue.unshift(message);
        finish(250);
      }, 2500);
      chrome.runtime.sendMessage(message, () => {
        clearTimeout(watchdog);
        const text = String(chrome.runtime.lastError?.message || "");
        if (/Extension context invalidated|context invalidated/i.test(text)) {
          extensionContextAlive = false;
          runtimeQueue.length = 0;
          finish();
          return;
        }
        if (/Receiving end does not exist|message port closed|Could not establish connection/i.test(text)) {
          message.__fssAttempts = Number(message.__fssAttempts || 0) + 1;
          if (message.__fssAttempts <= 8) {
            runtimeQueue.unshift(message);
            finish(Math.min(1500, 150 * message.__fssAttempts));
            return;
          }
        }
        finish();
      });
    } catch {
      extensionContextAlive = false;
      runtimeQueue.length = 0;
      finish();
    }
  }

  function safeRuntimeSend(message) {
    if (!extensionContextAlive) return;
    if (runtimeQueue.length >= MAX_RUNTIME_QUEUE) {
      const progressIndex = runtimeQueue.findIndex((item) => item?.kind === "scan-progress" && !item?.seatsJson);
      if (progressIndex >= 0) {
        runtimeQueue.splice(progressIndex, 1);
      } else {
        runtimeQueue.shift();
      }
    }
    runtimeQueue.push(message);
    pumpRuntimeQueue();
  }

  window.addEventListener("message", (event) => {
    if (window.__fifaSellerScoutContentVersion !== CONTENT_VERSION) return;
    if (event.source !== window) return;
    if (event.data?.type !== "FIFA_SELLER_SCOUT") return;
    safeRuntimeSend({ contentVersion: CONTENT_VERSION, ...event.data });
  });

function readPageInfo() {
  const performanceId =
    String(location.href || "").match(/performance\/(\d+)/)?.[1] ||
    document.querySelector('input[name="performanceId"]')?.value ||
    null;

  const productId =
    document.querySelector('input[name="productId"], #productId')?.value ||
    String(document.documentElement.innerHTML || "").match(/productId:\s*(\d+)/)?.[1] ||
    String(location.href || "").match(/[?&]productId=(\d+)/)?.[1] ||
    null;

  const visible = parseVisibleMatchInfo();
  const selectorName =
    document.querySelector(".semantic-no-styling-no-display.title")?.textContent?.trim() ||
    document.querySelector(".title .main_title")?.textContent?.trim() ||
    "";
  const selectorDate =
    document.querySelector(".semantic-no-styling-no-display.date")?.textContent?.trim() ||
    "";

  return {
    href: location.href,
    productId,
    performanceId,
    match: {
      name: visible.name || selectorName || "",
      matchCode: visible.matchCode || "",
      date: visible.date || selectorDate || "",
      time: visible.time || "",
      venue: visible.venue || "",
      currency: "USD"
    }
  };
}

function parseVisibleMatchInfo() {
  const lines = String(document.body?.innerText || "")
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);
  const vsIndex = lines.findIndex((line) => /^vs$/i.test(line));
  const home = vsIndex > 0 ? lines[vsIndex - 1] : "";
  const away = vsIndex >= 0 && lines[vsIndex + 1] ? lines[vsIndex + 1] : "";
  const matchCodeLine = lines.find((line) => /\bMATCH\s+\d+\b/i.test(line)) || "";
  const matchCode = matchCodeLine.match(/\bMATCH\s+\d+\b/i)?.[0] || "";
  const dateLine = lines.find((line) => /\b\d{1,2}\s+[A-Za-z]+\s+20\d{2}\b/.test(line)) || "";
  const venueIndex = dateLine ? lines.indexOf(dateLine) + 1 : -1;
  const venue = venueIndex > 0 ? (lines[venueIndex] || "") : "";
  const titleMatch = String(document.title || "").match(/\[([^|\]]+)\s*\|\s*([^|\]]+)\s*\|\s*([^\]]+)\]/);
  const fallbackVenue = titleMatch?.[1]?.trim() || "";
  const fallbackDateTime = titleMatch?.[2]?.trim() || "";
  const parsedTitleDate = fallbackDateTime.match(/(\d{1,2})\.(\d{1,2})\.(20\d{2})\s*-\s*(\d{1,2}:\d{2})/);
  const titleDate = parsedTitleDate
    ? `${parsedTitleDate[3]}-${parsedTitleDate[2].padStart(2, "0")}-${parsedTitleDate[1].padStart(2, "0")}`
    : fallbackDateTime;
  return {
    name: home && away ? `${home} vs ${away}` : "",
    matchCode,
    date: dateLine || titleDate,
    time: parsedTitleDate?.[4] || "",
    venue: venue || fallbackVenue
  };
}

function parseFifaDate(text) {
  const match = String(text || "").match(/([A-Za-z]+),\s*(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})\s*-\s*(\d{2}:\d{2})/);
  if (!match) return { date: "", time: "" };
  const months = {
    Jan: "01", January: "01",
    Feb: "02", February: "02",
    Mar: "03", March: "03",
    Apr: "04", April: "04",
    May: "05",
    Jun: "06", June: "06",
    Jul: "07", July: "07",
    Aug: "08", August: "08",
    Sep: "09", September: "09",
    Oct: "10", October: "10",
    Nov: "11", November: "11",
    Dec: "12", December: "12"
  };
  return {
    date: `${match[4]}-${months[match[3]] || match[3]}-${String(match[2]).padStart(2, "0")}`,
    time: match[5]
  };
}

function addDays(date, days) {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
}

function isoDate(date) {
  return date.toISOString().slice(0, 10);
}

function discoverMatches(days = 7) {
  const now = new Date();
  const start = isoDate(now);
  const end = isoDate(addDays(now, days));
  const matches = Array.from(document.querySelectorAll("li.performance")).map((li, index) => {
    const dateText = li.querySelector(".date_time")?.innerText?.trim().replace(/\s+/g, " ") || "";
    const parsedDate = parseFifaDate(dateText);
    const performanceId =
      li.id ||
      (li.querySelector("a[id^='book']")?.id || "").replace(/^book/, "");
    const productId =
      document.querySelector("#productId")?.value ||
      String(location.href || "").match(/product\/(\d+)/)?.[1] ||
      String(location.href || "").match(/[?&]productId=(\d+)/)?.[1] ||
      "10229225515651";
    return {
      index,
      performanceId,
      productId,
      matchCode: li.querySelector(".match_round_code")?.getAttribute("title") || "",
      matchRound: li.querySelector(".match_round_name")?.getAttribute("title") || "",
      date: parsedDate.date,
      time: parsedDate.time,
      dateText,
      venue: li.querySelector(".venue_group_match .site")?.getAttribute("title") || "",
      home: li.querySelector(".teams .team.home .name")?.getAttribute("title") || "",
      away: li.querySelector(".teams .team.opposite .name")?.getAttribute("title") || "",
      availability: li.className.includes("limited") ? "limited" : (li.className.includes("available") ? "available" : "unknown"),
      seatUrl: performanceId ? `${location.origin}/secure/selection/event/seat/performance/${performanceId}/lang/en` : ""
    };
  }).filter((match) => match.performanceId && match.date >= start && match.date <= end);
  return { start, end, days, productId: matches[0]?.productId || readPageInfo().productId, matches };
}

function sendPageInfo() {
  safeRuntimeSend({
    type: "FIFA_SELLER_SCOUT_PAGE_INFO",
    contentVersion: CONTENT_VERSION,
    ...readPageInfo()
  });
}

function normalizeFindText(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function guideEscape(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function seatFindLabel(target = {}) {
  const seats = target.seatFrom && target.seatTo && String(target.seatFrom) !== String(target.seatTo)
    ? `${target.seatFrom}-${target.seatTo}`
    : (target.seatNumber || target.seatFrom || "");
  return [
    target.blockName ? `Section ${target.blockName}` : "",
    target.row ? `Row ${target.row}` : "",
    seats ? `Seat ${seats}` : ""
  ].filter(Boolean).join(" · ");
}

function seatMapPosition(target = {}) {
  const x = Number(target.mapPointX);
  const y = Number(target.mapPointY);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  const max = Math.max(1, Number(target.mapMax) || 40000);
  return {
    x,
    y,
    px: Math.min(94, Math.max(6, (x / max) * 100)),
    py: Math.min(90, Math.max(10, (y / max) * 100))
  };
}

function seatDirectionLabel(target = {}) {
  const point = seatMapPosition(target);
  if (!point) return "";
  const horizontal = point.px < 38 ? "left side" : (point.px > 62 ? "right side" : "middle");
  const vertical = point.py < 38 ? "upper" : (point.py > 62 ? "lower" : "central");
  if (horizontal === "middle" && vertical === "central") return "around midfield";
  if (horizontal === "middle") return `${vertical} middle`;
  if (vertical === "central") return `${horizontal}`;
  return `${vertical} ${horizontal}`;
}

function miniMapHtml(target = {}) {
  const point = seatMapPosition(target);
  if (!point) {
    return `<div class="fss-mini-map empty"><i></i><span>Map hint appears after a fresh scan captures seat coordinates.</span></div>`;
  }
  return `
    <div class="fss-mini-map" aria-label="Rough stadium location">
      <i></i>
      <b style="left:${point.px}%;top:${point.py}%"></b>
      <small>roughly ${guideEscape(seatDirectionLabel(target))}</small>
    </div>
  `;
}

function showFindSeatGuide(target = {}, status = "Looking for this seat on the map...") {
  const existing = document.getElementById("fifa-seller-scout-find-guide");
  if (existing) existing.remove();
  const guide = document.createElement("div");
  guide.id = "fifa-seller-scout-find-guide";
  guide.innerHTML = `
    <button type="button" aria-label="Close">×</button>
    <strong>Find on map</strong>
    <span>${guideEscape(seatFindLabel(target))}</span>
    ${miniMapHtml(target)}
    ${target.rowHint ? `<p class="fss-row-hint">${guideEscape(target.rowHint)}</p>` : ""}
    <em>${guideEscape(status)}</em>
  `;
  Object.assign(guide.style, {
    position: "fixed",
    zIndex: "2147483647",
    top: "18px",
    right: "18px",
    maxWidth: "330px",
    padding: "14px 42px 14px 16px",
    border: "1px solid rgba(214, 184, 89, .75)",
    borderRadius: "14px",
    background: "linear-gradient(135deg, #111722, #252112)",
    color: "#fff",
    boxShadow: "0 18px 48px rgba(0,0,0,.28)",
    font: "14px/1.35 system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif"
  });
  const styleMap = {
    strong: { display: "block", fontWeight: "800", letterSpacing: ".02em", textTransform: "uppercase" },
    span: { display: "block", marginTop: "5px", fontSize: "16px", fontWeight: "650" },
    em: { display: "block", marginTop: "6px", color: "#d9dde5", fontStyle: "normal", fontSize: "13px" },
    ".fss-mini-map": {
      position: "relative",
      height: "94px",
      marginTop: "12px",
      border: "1px solid rgba(255,255,255,.18)",
      borderRadius: "999px",
      background: "radial-gradient(ellipse at center, rgba(255,255,255,.12), rgba(255,255,255,.04) 58%, rgba(255,255,255,.02) 59%)",
      overflow: "hidden"
    },
    ".fss-mini-map i": {
      position: "absolute",
      left: "29%",
      right: "29%",
      top: "27%",
      bottom: "27%",
      border: "1px solid rgba(255,255,255,.22)",
      borderRadius: "8px"
    },
    ".fss-mini-map b": {
      position: "absolute",
      width: "13px",
      height: "13px",
      margin: "-6px 0 0 -6px",
      border: "2px solid #fff",
      borderRadius: "999px",
      background: "#d6a63d",
      boxShadow: "0 0 0 7px rgba(214,166,61,.24), 0 0 20px rgba(214,166,61,.8)"
    },
    ".fss-mini-map small": {
      position: "absolute",
      left: "12px",
      right: "12px",
      bottom: "7px",
      color: "#f7e8b2",
      fontSize: "12px",
      fontWeight: "650",
      textAlign: "center"
    },
    ".fss-mini-map.empty": {
      borderRadius: "12px",
      height: "54px",
      background: "rgba(255,255,255,.07)"
    },
    ".fss-mini-map.empty span": {
      display: "block",
      margin: "9px 12px 0",
      color: "#d9dde5",
      fontSize: "12px",
      fontWeight: "500"
    },
    ".fss-row-hint": {
      margin: "9px 0 0",
      padding: "8px 10px",
      borderRadius: "10px",
      background: "rgba(255,255,255,.08)",
      color: "#f4f6fa",
      fontSize: "13px",
      fontWeight: "600"
    },
    button: {
      position: "absolute",
      top: "8px",
      right: "8px",
      width: "28px",
      height: "28px",
      border: "0",
      borderRadius: "999px",
      background: "rgba(255,255,255,.12)",
      color: "#fff",
      cursor: "pointer",
      fontSize: "18px",
      lineHeight: "1"
    }
  };
  for (const [selector, styles] of Object.entries(styleMap)) {
    guide.querySelectorAll(selector).forEach((node) => Object.assign(node.style, styles));
  }
  guide.querySelector("button")?.addEventListener("click", () => guide.remove());
  document.documentElement.appendChild(guide);
  return guide;
}

function candidateText(element) {
  return [
    element.textContent,
    element.getAttribute?.("title"),
    element.getAttribute?.("aria-label"),
    element.getAttribute?.("data-tooltip"),
    element.getAttribute?.("data-block"),
    element.getAttribute?.("data-section"),
    element.getAttribute?.("data-row"),
    element.getAttribute?.("data-seat")
  ].filter(Boolean).join(" ");
}

function clickableAncestor(element) {
  return element?.closest?.("button,a,[role='button'],[tabindex],svg g,svg path,svg polygon,svg rect") || element;
}

function markSeatElement(element, target, message) {
  const clickable = clickableAncestor(element);
  clickable.scrollIntoView?.({ block: "center", inline: "center", behavior: "smooth" });
  const oldOutline = clickable.style.outline;
  const oldFilter = clickable.style.filter;
  clickable.style.outline = "4px solid #d6a63d";
  clickable.style.filter = "drop-shadow(0 0 8px rgba(214,166,61,.9))";
  setTimeout(() => {
    clickable.style.outline = oldOutline;
    clickable.style.filter = oldFilter;
  }, 8000);
  showFindSeatGuide(target, message);
  return true;
}

function findCandidateElement(target = {}, exact = false) {
  const block = normalizeFindText(target.blockName);
  const row = normalizeFindText(target.row);
  const seat = normalizeFindText(target.seatNumber || target.seatFrom);
  const candidates = Array.from(document.querySelectorAll("button,a,[role='button'],[title],[aria-label],svg text,svg g,svg path,svg polygon,svg rect,[data-block],[data-section],[data-row],[data-seat]"))
    .slice(0, 5000);
  return candidates.find((element) => {
    const text = normalizeFindText(candidateText(element));
    if (!text) return false;
    if (exact) return (!block || text.includes(block)) && (!row || text.includes(row)) && (!seat || text.includes(seat));
    return block && text.includes(block);
  }) || null;
}

function clickSectionCandidate(element) {
  const clickable = clickableAncestor(element);
  clickable.dispatchEvent(new MouseEvent("mouseover", { bubbles: true, cancelable: true, view: window }));
  clickable.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, cancelable: true, view: window }));
  clickable.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
}

async function findSeatOnMap(target = {}) {
  showFindSeatGuide(target);
  const exact = findCandidateElement(target, true);
  if (exact) {
    markSeatElement(exact, target, "Found the seat. Please select it manually if you want to continue.");
    return { ok: true, mode: "exact" };
  }
  const section = findCandidateElement(target, false);
  if (section) {
    markSeatElement(section, target, "Opening the section. Please choose the seat manually.");
    clickSectionCandidate(section);
    setTimeout(() => {
      const exactAfterZoom = findCandidateElement(target, true);
      if (exactAfterZoom) markSeatElement(exactAfterZoom, target, "Seat is visible. Final selection is manual.");
    }, 900);
    return { ok: true, mode: "section" };
  }
  showFindSeatGuide(target, "I could not drive the map directly. Use this section, row, and seat as your guide.");
  return { ok: false, mode: "guide-only" };
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", sendPageInfo, { once: true });
} else {
  sendPageInfo();
}

try {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (window.__fifaSellerScoutContentVersion !== CONTENT_VERSION) return;
    if (!extensionContextAlive) return;
    if (message?.type === "FIFA_SELLER_SCOUT_READ_PAGE") {
      const pageInfo = {
        type: "FIFA_SELLER_SCOUT_PAGE_INFO",
        contentVersion: CONTENT_VERSION,
        ...readPageInfo()
      };
      safeRuntimeSend(pageInfo);
      sendResponse?.(pageInfo);
      return true;
    }

    if (message?.type === "FIFA_SELLER_SCOUT_DISCOVER_MATCHES") {
      safeRuntimeSend({
        type: "FIFA_SELLER_SCOUT_MATCHES_DISCOVERED",
        contentVersion: CONTENT_VERSION,
        href: location.href,
        ...discoverMatches(message.days || 7)
      });
    }

    if (message?.type === "FIFA_SELLER_SCOUT_SCAN_ALL") {
      window.postMessage(message, "*");
    }

    if (message?.type === "FIFA_SELLER_SCOUT_SCAN_MATCHES") {
      window.postMessage(message, "*");
    }

    if (message?.type === "FIFA_SELLER_SCOUT_FIND_SEAT") {
      findSeatOnMap(message.target || {}).then((result) => {
        safeRuntimeSend({
          type: "FIFA_SELLER_SCOUT_FIND_SEAT_RESULT",
          contentVersion: CONTENT_VERSION,
          href: location.href,
          result
        });
      });
    }
  });
} catch {
  extensionContextAlive = false;
}
}
